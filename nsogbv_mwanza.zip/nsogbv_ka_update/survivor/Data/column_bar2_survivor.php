<!DOCTYPE html>

<?php include("dbconnect.php"); ?>
	<script src="dist/apexcharts/dist/apexcharts.js"></script>
<html lang="en">
  <head>

 
 

  </head>


  <body>
     <div id="chart3Nmhgii"></div>

    <script>
      
        var options = {
          series: [{
          name: 'TA Kilupula',
          data: [
		  		  <?php
$query  = "select case when A5_T_A ='10201' then 'TA Kilupula' when A5_T_A ='10202' then 'TA Mwakaboko' 
when A5_T_A ='10203' then 'TA Kyungu' when A5_T_A ='10204' then 'TA Wasambo' 
when A5_T_A ='10205' then 'TA Mwirangombe' end village, sum(case when A5_T_A ='10201' then 1 end) Kilupula, 
sum(case when A5_T_A ='10203' then 1 end) Kyungu, sum(case when A5_T_A ='10202' then 1 end) Mwakaboko, sum(case when A5_T_A ='10204' then 1 end) Wasambo,
 sum(case when A5_T_A ='10205' then 1 end) Mwirangombe from sgbv.gbv_cases2 where A4_DISTRICT ='102' group by A5_T_A";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"'$Kilupula',"; 
}

?> 
		  
		  
		  
		  ]
        }, 

		{
          name: 'TA Kyungu',
          data: [
		  
		  <?php
$query  = "select case when A5_T_A ='10201' then 'TA Kilupula' when A5_T_A ='10202' then 'TA Mwakaboko' 
when A5_T_A ='10203' then 'TA Kyungu' when A5_T_A ='10204' then 'TA Wasambo' 
when A5_T_A ='10205' then 'TA Mwirangombe' end village, sum(case when A5_T_A ='10201' then 1 end) Kilupula, 
sum(case when A5_T_A ='10203' then 1 end) Kyungu, sum(case when A5_T_A ='10202' then 1 end) Mwakaboko, sum(case when A5_T_A ='10204' then 1 end) Wasambo,
 sum(case when A5_T_A ='10205' then 1 end) Mwirangombe from sgbv.gbv_cases2 where A4_DISTRICT ='102' group by A5_T_A";


$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"'$Kyungu',"; 
}

?> 
		  
		  ]
        },
		{
          name: 'TA Wasambo',
          data: [
		  
		  <?php
$query  = "select case when A5_T_A ='10201' then 'TA Kilupula' when A5_T_A ='10202' then 'TA Mwakaboko' 
when A5_T_A ='10203' then 'TA Kyungu' when A5_T_A ='10204' then 'TA Wasambo' 
when A5_T_A ='10205' then 'TA Mwirangombe' end village, sum(case when A5_T_A ='10201' then 1 end) Kilupula, 
sum(case when A5_T_A ='10203' then 1 end) Kyungu, sum(case when A5_T_A ='10202' then 1 end) Mwakaboko, sum(case when A5_T_A ='10204' then 1 end) Wasambo,
 sum(case when A5_T_A ='10205' then 1 end) Mwirangombe from sgbv.gbv_cases2 where A4_DISTRICT ='102' group by A5_T_A";


$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"'$Wasambo',"; 
}

?> 
		  
		  ]
        },	{
          name: 'TA Mwakaboko',
          data: [
		  
		  <?php
$query  = "select case when A5_T_A ='10201' then 'TA Kilupula' when A5_T_A ='10202' then 'TA Mwakaboko' 
when A5_T_A ='10203' then 'TA Kyungu' when A5_T_A ='10204' then 'TA Wasambo' 
when A5_T_A ='10205' then 'TA Mwirangombe' end village, sum(case when A5_T_A ='10201' then 1 end) Kilupula, 
sum(case when A5_T_A ='10203' then 1 end) Kyungu, sum(case when A5_T_A ='10202' then 1 end) Mwakaboko, sum(case when A5_T_A ='10204' then 1 end) Wasambo,
 sum(case when A5_T_A ='10205' then 1 end) Mwirangombe from sgbv.gbv_cases2 where A4_DISTRICT ='102' group by A5_T_A";


$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"'$Mwakaboko',"; 
}

?> 
		  
		  ]
        },
{
          name: 'TA Mwirangombe',
          data: [
		  
		  <?php
$query  = "select case when A5_T_A ='10201' then 'TA Kilupula' when A5_T_A ='10202' then 'TA Mwakaboko' 
when A5_T_A ='10203' then 'TA Kyungu' when A5_T_A ='10204' then 'TA Wasambo' 
when A5_T_A ='10205' then 'TA Mwirangombe' end village, sum(case when A5_T_A ='10201' then 1 end) Kilupula, 
sum(case when A5_T_A ='10203' then 1 end) Kyungu, sum(case when A5_T_A ='10202' then 1 end) Mwakaboko, sum(case when A5_T_A ='10204' then 1 end) Wasambo,
 sum(case when A5_T_A ='10205' then 1 end) Mwirangombe from sgbv.gbv_cases2 where A4_DISTRICT ='102' group by A5_T_A";


$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"'$Mwirangombe',"; 
}

?> 
		  
		  ]
        },		/* {
          name: 'Free Cash Flow',
          data: [35, 41, 36, 26, 45, 48, 52, 53, 41]
        } */],
          chart: {
          type: 'bar',
          height: 350
        },
        plotOptions: {
          bar: {
            horizontal: false,
            columnWidth: '55%',
         //   endingShape: 'rounded'
          },
        },
        dataLabels: {
          enabled: false
        },
        stroke: {
          show: true,
          width: -6,
          colors: ['transparent']
        },
        xaxis: {
          categories: [
		  
		  		  <?php
$query  = "select case when A5_T_A ='10201' then 'TA Kilupula' when A5_T_A ='10202' then 'TA Mwakaboko' 
when A5_T_A ='10203' then 'TA Kyungu' when A5_T_A ='10204' then 'TA Wasambo' 
when A5_T_A ='10205' then 'TA Mwirangombe' end village, sum(case when A5_T_A ='10201' then 1 end) Kilupula, 
sum(case when A5_T_A ='10203' then 1 end) Kyungu, sum(case when A5_T_A ='10202' then 1 end) Mwakaboko, sum(case when A5_T_A ='10204' then 1 end) Wasambo,
 sum(case when A5_T_A ='10205' then 1 end) Mwirangombe from sgbv.gbv_cases2 where A4_DISTRICT ='102' group by A5_T_A";


$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
//$village=mysql_escape_string($village);
//echo"'\$village',"; 
echo "'$village',";
//echo '$village';
}

?> 
		  
		  ],
        },
        yaxis: {
          title: {
            text: '# of cases'
          }
        },
		
        fill: {
          opacity: 1
        },
        tooltip: {
          y: {
            formatter: function (val) {
             // return "$ " + val + " thousands"
			   return val 
            }
          }
        }
        };

        var chart = new ApexCharts(document.querySelector("#chart3Nmhgii"), options);
        chart.render();
      
      
    </script>

    
  </body>
</html>
