
	 



<!----end--->

  
     <div id="chartuni"></div>

    <script>
        var options = {
          series: [{name:'Cases',
          data: [
		  <?php
$query  = "select A4_DISTRICT, count(*) total
  from sgbv.gbv_cases2  group by A4_DISTRICT";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"$total,"; 
}

?>  
		  
		  ]
        }],
          chart: {
          type: 'bar',
          height: 350,

        },
        plotOptions: {
          bar: {
            horizontal: false,
          }
        },
        dataLabels: {
          enabled: true,
        },
        xaxis: {
          categories: [
		  
				
			<?php
				$query  = "select A4_DISTRICT, count(*) total
  from sgbv.gbv_cases2  group by A4_DISTRICT";

				$results = mysqli_query($link, $query);
				$nrows = mysqli_num_rows($results);
				$row = mysqli_num_rows($results);

				for ($i=0;$i<$nrows;$i++)

				{
				$n = $i + 1;
				$row = mysqli_fetch_array($results);
				extract($row);
				echo"'$A4_DISTRICT',"; 
				}

				?>  
			
			
          ],
        }
        };

        var chart = new ApexCharts(document.querySelector("#chartuni"), options);
        chart.render();
      
      
    </script>


    
  </body>
</html>



