 <?php include("../../../dbconnect.php"); ?>
 <?php
			//MySQLi Procedural
			//$query=mysqli_query($conn,"select * from `login`");
			//while($row=mysqli_fetch_array($query)){
			/*	?>
				<tr>
					<td><?php echo $row['logid']; ?></td>
					<td><?php echo $row['username']; ?></td>
					<td><?php echo $row['login_date']; ?></td>
				</tr>
				<?php */
			//}
 $Total_harmful=0;
			//MySQLi Object-oriented
			$query1=$conn->query("DROP TABLE IF EXISTS me2");
			$query=$conn->query("create table me2 as select gbv_cases2.*,  str_to_date(concat(f5_year,'-',f5_month,'-',f5_day), '%Y-%m-%d') F5_DATEE from sgbv.gbv_cases2");
		//	$query=$conn->query("select A2_SEX,D1_CHILD_ABUSE, F5_DATE from me2");
		/*	while($row = $query->fetch_array()) {
				?>
				<tr>
					<td><?php echo $row['A2_SEX']; ?></td>
					<td><?php echo $row['D1_CHILD_ABUSE']; ?></td>
					<td><?php echo $row['F5_DATE']; ?></td>
				</tr>
				<?php 
			} */
		?>
<?php
			if (isset($_POST['submit'])){
				$from=date('Y-m-d',strtotime($_POST['from']));
				$to=date('Y-m-d',strtotime($_POST['to']));
				
				//MySQLi Procedural
				//$oquery=mysqli_query($conn,"select * from `login` where login_date between '$from' and '$to'");
				//while($orow=mysqli_fetch_array($oquery)){
				/*	?>
					<tr>
						<td><?php echo $orow['logid']?></td>
						<td><?php echo $orow['username']?></td>
						<td><?php echo $orow['login_date']?></td>
					</tr>
					<?php */
				//}
 
				//MySQLi Object-oriented
				$oquery1=$conn->query("DROP TABLE IF EXISTS sgbv.searcher");
				$oquery=$conn->query("CREATE TABLE sgbv.searcher as select me2.*, F5_DATEE F5_DATEEe from sgbv.me2 where F5_DATEE between '$from' and '$to'");
			/*	$oquery=$conn->query("select * FROM sgbv.searcher");
				while($orow = $oquery->fetch_array()){
					?>
					<tr>
						<td><?php echo $orow['A2_SEX']?></td>
						<td><?php echo $orow['D1_CHILD_ABUSE']?></td>
						<td><?php echo $orow['F5_DATE']?></td>
					</tr>
					<?php 
				} */
			}
		?>
<!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="row page-titles">
                <div class="col-md-5 col-12 align-self-center">
                    <h3 class="text-themecolor mb-0"><?php echo $_GET["d"];?> SGBV Dashboard</h3>
                    <ol class="breadcrumb mb-0">
                        <li class="breadcrumb-item"><a href="../../../">Home</a></li>
                        <li class="breadcrumb-item active"><a href="../../">Survivors</a></li>
                        <li class="breadcrumb-item active"><a href="../?d=<?php echo $_GET["d"];?>"><?php echo $_GET["d"];?></a></li>
                        <li class="breadcrumb-item"><b class=" "><?php echo date('d M Y',strtotime($from))." To ".date('d M Y',strtotime($to)). " Report";?></b></li>
                    </ol>
                </div>
                <div class="col-md-7 col-12 align-self-center d-none d-md-block">
                    <div class="d-flex mt-2 justify-content-end">
                        <div class="d-flex mr-3 ml-2">
                            <div class="chart-text mr-2">
									<?php
										$District=$_GET["d"];
										$query  = "select sum(b5) Total_harmful FROM sgbv.searcher WHERE b5 = 1 and a4_district = '$District' group by b5";

										$results = mysqli_query($link, $query);
										$nrows = mysqli_num_rows($results);
										$row = mysqli_num_rows($results);

										for ($i=0;$i<$nrows;$i++)

										{
										$n = $i + 1;
										$row = mysqli_fetch_array($results);
										extract($row);



										//echo"'$Total_harmful',"; 
										}

										?>

										<?php
										$query  = "select count(*) all_violence from sgbv.searcher where a4_district ='$District'";

										$results = mysqli_query($link, $query);
										$nrows = mysqli_num_rows($results);
										$row = mysqli_num_rows($results);

										for ($i=0;$i<$nrows;$i++)

										{
										$n = $i + 1;
										$row = mysqli_fetch_array($results);
										extract($row);



										//echo"'$Total_harmful',"; 
										}

									?>
                                <h6 class="mb-0"><small>HARMFUL PRACTICE(S)</small></h6>
                                <h4 class="mt-0 text-info"><?php 
								
								 if ($Total_harmful < "1") {
                                             echo "0";
                                            }
									else{
										echo"$Total_harmful";
									}
								
								?></h4>
                            </div>
                        </div>
                        <div class="d-flex ml-2">
                            <div class="chart-text mr-2">
                                <h6 class="mb-0"><small>TOTAL SGBV CASES</small></h6>
                                <h4 class="mt-0 text-primary"><?php echo"$all_violence";?></h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- Row -->
                <div class="row">
                    <!-- Column -->
                    <div class="col-lg-6 col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-12">
                                       
                                            <div>
                                                <h3 class="card-title" style="text-align:center">Cases by TA</h3>
                                             <!--   <h6 class="card-subtitle">Pie Chart</h6> -->
                                            </div>
                                            
                                            <?php include("Data/barindex.php"); ?>
                                          
                                        
                                    </div>
                                   
                                </div>
                            </div>
                        </div>
                    </div>
					
					
                    <div class="col-lg-6 col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <h3 class="card-title" style="text-align:center">SGBV Cases aggregated by GVH </h3>
                             <!--   <h6 class="card-subtitle">Now Bar Visual</h6> -->
                                 <div class="col-12">   
                                            <?php include("Data/gvh.php"); ?> 
                                    </div>
                            </div>
                        </div>
                    </div>
					
					
					
                </div>
                <!-- Row -->
                <!-- Row -->
                <div class="row">
                    <!-- Column -->
                    <div class="col-lg-6 col-md-12">
                        <div class="card blog-widget">
                            <div class="card-body">
							<div>
                                        <h3 class="card-title" style="text-align:center">GBV Cases by Type</h3>
                                      <!--  <h6 class="card-subtitle">Overview of Newsletter Campaign</h6> -->
                                    </div>
                                <div class="ml-auto align-self-center">
										<?php include("Data/violence_type.php"); ?>
										</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12">
                        <div class="card blog-widget">
                            <div class="card-body">
                                    <div>
                                        <h3 class="card-title" style="text-align:center"> Survivors age groups </h3>
                                      <!--  <h6 class="card-subtitle">Overview of Newsletter Campaign</h6> -->
                                    </div>
                                    <div class="ml-auto align-self-center">
                                        <?php include("Data/ages_groups.php"); ?>
                                    </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Row -->
				                <div class="row">
                    <!-- Column -->
                    <div class="col-lg-6 col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-12">
                                       
                                            <div>
                                                <h3 class="card-title" style="text-align:center">Survivors by Sex</h3>
                                             <!--   <h6 class="card-subtitle">Pie Chart</h6> -->
                                            </div>
                                            
                                            <?php include("Data/survivor_sex.php"); ?>
                                          
                                        
                                    </div>
                                   
                                </div>
                            </div>
                        </div>
                    </div>
					
					
                    <div class="col-lg-6 col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <h3 class="card-title" style="text-align:center">Disability Status Survivors </h3>
                             <!--   <h6 class="card-subtitle">Now Bar Visual</h6> -->
                                 <div class="col-12">   
                                            <?php include("Data/disability.php"); ?> 
                                    </div>
                            </div>
                        </div>
                    </div>	
                </div>
                <div class="row">
                    <!-- Column -->
                    <div class="col-lg-4 col-md-12">
					<div>
                                        
                                      <!--  <h6 class="card-subtitle">Overview of Newsletter Campaign</h6> -->
                                    </div>
                        <div class="card">
                            <div class="card-body">
									<h3 class="card-title" style="text-align:center"> Survivors' Marital Status </h3>
                                    <div class="ml-auto align-self-center">
                                        <?php include("Data/marry.php"); ?>
                                    </div
								
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                    <!-- Column -->
                    <div class="col-lg-4 col-md-12">
					<div>
					
                                   <!--     <h3 class="card-title text-white">Education Level of SGBV Survivors</h3>
                                   <!--     <h6 class="card-subtitle text-white op-5">March 2020</h6> -->
                                    </div>
                        <div class="card">

                            <div class="card-body">
								<h3 class="card-title" style="text-align:center"> Education Level of Survivors </h3>
                                <div class="ml-auto align-self-center">
                                   <?php include("Data/edu_survivor.php"); ?>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                    <!-- Column -->
                    <div class="col-lg-4 col-md-12">
					<div>
					
                       </div>
						<div class="card">

                            <div class="card-body">
								<h3 class="card-title" style="text-align:center"> Occupation </h3>
                                <div class="ml-auto align-self-center">
                                   <?php include("Data/occupation.php"); ?>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                </div>
                <!-- Row -->
                <!-- Row -->
                <div class="row">
                    <!-- Column -->
                </div>
            </div>