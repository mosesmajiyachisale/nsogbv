
	<script src="../../../dist/apexcharts/dist/apexcharts.js"></script>


<!----end--->

  
     <div id="chartunibny"></div>

    <script>
        var options = {
          series: [{name:'Cases',
          data: [
		  <?php
		  $District=$_GET["d"];
$query  = "select Traditional, count(*) total from (select * from (SELECT a5_t_a Traditional,floor(DATEDIFF(CURDATE(), str_to_date(concat(a3_day,'/',a3_month,'/',a3_year),'%d/%m/%Y'))/365) years, A8 Marry from gbv_cases2 where a8 in(2,3) and a4_district ='$District' ) as mee where years<18)  marriages group by Traditional;";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"$total,"; 
}

?>  
		  
		  ]
        }],
          chart: {
          type: 'bar',
          height: 350,

        },
        plotOptions: {
          bar: {
            horizontal: false,
          }
        },
        dataLabels: {
          enabled: false,
        },
        xaxis: {
          categories: [
		  
				
			<?php
			$District=$_GET["d"];
$query  = "select Traditional, count(*) total from (select * from (SELECT a5_t_a Traditional,floor(DATEDIFF(CURDATE(), str_to_date(concat(a3_day,'/',a3_month,'/',a3_year),'%d/%m/%Y'))/365) years, A8 Marry from gbv_cases2 where a8 in(2,3) and a4_district ='$District' ) as mee where years<18)  marriages group by Traditional;";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"\"$Traditional\","; 
}

?>  
			
			
          ],
        }
        };

        var chart = new ApexCharts(document.querySelector("#chartunibny"), options);
        chart.render();
      
      
    </script>

  </body>
</html>