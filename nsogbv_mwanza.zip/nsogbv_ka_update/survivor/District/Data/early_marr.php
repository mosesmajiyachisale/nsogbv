<!DOCTYPE html>

	<script src="dist/apexcharts/dist/apexcharts.js"></script>
<html lang="en">
  <head>

  </head>

  <body>
     <div id="chartagemarruu" class="Piechart"></div>

    <script>
      
        var options = {
          series: [
		  
		  <?php
		  $District=$_GET["d"];
$query  = "select district, count(*) total from (select * from 
(SELECT a4_district district,floor(DATEDIFF(CURDATE(), str_to_date(concat(a3_day,'/',a3_month,'/',a3_year),'%d/%m/%Y'))/365) years, A8 Marry 
from gbv_cases2 where a8 in(2,3) and a4_district = '$District') as mee where years<18)  marriages group by district";



$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"$total,"; 
}

?>  	  
		  ],
          chart: {
          width: 320,
          type: 'donut',
        },
		legend: {
              position: 'bottom',
            },
        labels: [
		
		
		
		<?php
	$District=$_GET["d"];
$query  = "select district, count(*) total from 
(select * from (SELECT a4_district district,floor(DATEDIFF(CURDATE(), str_to_date(concat(a3_day,'/',a3_month,'/',a3_year),'%d/%m/%Y'))/365) years, A8 Marry
 from gbv_cases2 where a8 in(2,3) and a4_district ='$District' ) as mee where years<18)  marriages group by district";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);



echo"'$district',"; 
}

?>
		
		],
        responsive: [{
          breakpoint: 380,
          options: {
            chart: {
              width: 380,
            },
          }
        }],
        dataLabels: {
          formatter(val, opts) {
            const name = opts.w.globals.labels[opts.seriesIndex]
            return [name, val.toFixed(1) + '%']
          }
        },
        legend: {
          show: false
        },
        plotOptions: {
          pie: {
            dataLabels: {
              offset: -0
            }
          }
		}
        };

        var chart = new ApexCharts(document.querySelector("#chartagemarruu"), options);
        chart.render();
      
    </script>
  </body>
</html>