<!DOCTYPE html>

<?php $District=$_GET['d'];?>
	<script src="dist/apexcharts/dist/apexcharts.js"></script>
<html lang="en">
  <head>

  </head>


  <body>
     <div id="chart3mhgxyi"></div>

    <script>
      
        var options = {
          series: [{
          name: 'Sexual',
          data: [
		  		  <?php
$query  = "SELECT a5_t_a, count(CASE WHEN b1 = 1 THEN 'Sexual' END) sexual,count(CASE WHEN b2 = 1 THEN 'Physical' END) physical,COUNT(CASE WHEN b3 = 1 THEN 'Economic' END) economic,count(CASE WHEN b4= 1 THEN 'Psychological' END) pys,count(CASE WHEN b5= 1 THEN 'Harmful Practices' END) harm FROM sgbv.gbv_cases2 where b1 = 1 and a4_district = '$District' group by a5_t_a";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"'$sexual',"; 
}

?>   
		  ]
        },
        
        {
          name: 'Physical',
          data: [
		  
		  <?php
$query  = "SELECT a5_t_a, count(CASE WHEN b1 = 1 THEN 'Sexual' END) sexual,count(CASE WHEN b2 = 1 THEN 'Physical' END) physical,COUNT(CASE WHEN b3 = 1 THEN 'Economic' END) economic,count(CASE WHEN b4= 1 THEN 'Psychological' END) pys,count(CASE WHEN b5= 1 THEN 'Harmful Practices' END) harm FROM sgbv.gbv_cases2 where b1 = 1 and a4_district = '$District' group by a5_t_a";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"'$physical',"; 
}

?> 
		  
		  ]
        }
    
        , {
          name: 'Economic',
          data: [
		  
		  <?php
$query  = "SELECT a5_t_a, count(CASE WHEN b1 = 1 THEN 'Sexual' END) sexual,count(CASE WHEN b2 = 1 THEN 'Physical' END) physical,COUNT(CASE WHEN b3 = 1 THEN 'Economic' END) economic,count(CASE WHEN b4= 1 THEN 'Psychological' END) pys,count(CASE WHEN b5= 1 THEN 'Harmful Practices' END) harm FROM sgbv.gbv_cases2 where b1 = 1 and a4_district = '$District' group by a5_t_a";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"'$economic',"; 
}

?> 
		  
		  ]
        },


         {
          name: 'Psychological',
          data: [
		  
		  <?php
$query  = "SELECT a5_t_a, count(CASE WHEN b1 = 1 THEN 'Sexual' END) sexual,count(CASE WHEN b2 = 1 THEN 'Physical' END) physical,COUNT(CASE WHEN b3 = 1 THEN 'Economic' END) economic,count(CASE WHEN b4= 1 THEN 'Psychological' END) pys,count(CASE WHEN b5= 1 THEN 'Harmful Practices' END) harm FROM sgbv.gbv_cases2 where b1 = 1 and a4_district = '$District' group by a5_t_a";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"'$pys',"; 
}

?> 
		  
		  ]
        },
        
         {
          name: 'Harmful Practices',
          data: [
		  
		  <?php
$query  = "SELECT a5_t_a, count(CASE WHEN b1 = 1 THEN 'Sexual' END) sexual,count(CASE WHEN b2 = 1 THEN 'Physical' END) physical,COUNT(CASE WHEN b3 = 1 THEN 'Economic' END) economic,count(CASE WHEN b4= 1 THEN 'Psychological' END) pys,count(CASE WHEN b5= 1 THEN 'Harmful Practices' END) harm FROM sgbv.gbv_cases2 where b1 = 1 and a4_district = '$District' group by a5_t_a";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"'$harm',"; 
}

?> 
		  
		  ]
        }, /* {
          name: 'Free Cash Flow',
          data: [35, 41, 36, 26, 45, 48, 52, 53, 41]
        } */],
          chart: {
          type: 'bar',
          height: 350
        },
        plotOptions: {
          bar: {
            horizontal: true,
            columnWidth: '90%',
            endingShape: 'rounded'
          },
        },
        dataLabels: {
          enabled: false
        },
        stroke: {
          show: true,
          width: 8,
          colors: ['transparent']
        },
        xaxis: {
          categories: [
		  
		  		  <?php
$query  = "SELECT a5_t_a, count(CASE WHEN b1 = 1 THEN 'Sexual' END) sexual,count(CASE WHEN b2 = 1 THEN 'Physical' END) physical,COUNT(CASE WHEN b3 = 1 THEN 'Economic' END) economic,count(CASE WHEN b4= 1 THEN 'Psychological' END) pys,count(CASE WHEN b5= 1 THEN 'Harmful Practices' END) harm FROM sgbv.gbv_cases2 where b1 = 1 and a4_district = '$District' group by a5_t_a";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"\"$a5_t_a\","; 
}

?> 
		  
		  ],
        },
        yaxis: {
          title: {
            text: 'Number of cases' 
          }
        },
        fill: {
          opacity: 1
        },
        tooltip: {
          y: {
            formatter: function (val) {
             // return "$ " + val + " thousands"
			   return val 
            }
          }
        }
        };

        var chart = new ApexCharts(document.querySelector("#chart3mhgxyi"), options);
        chart.render();
      
      
    </script>
  </body>
</html>