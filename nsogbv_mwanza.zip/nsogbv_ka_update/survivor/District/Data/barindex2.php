

<?php //include("dbconnect.php"); 
$d = $_GET['d'];
?>
	 

<!----end--->

  
     <div id="chartuniyyk"></div>

    <script>
        var options = {
          series: [{name:'Number of Cases',
          data: [
		  <?php
$query  = "select f5_year, count(*) counted from gbv_cases2 where a4_district ='$d' group by f5_year";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"$counted,"; 
}

?>  
		  
		  ]
        }],
          chart: {
          type: 'line',
          height: 350,

        },
        plotOptions: {
          bar: {
            horizontal: false,
          }
	},
        dataLabels: {
          enabled: true,
	},

        xaxis: {
          categories: [
		  
				
			<?php
				$query  = "select f5_year, count(*) counted from gbv_cases2  where a4_district ='$d' group by f5_year ";

				$results = mysqli_query($link, $query);
				$nrows = mysqli_num_rows($results);
				$row = mysqli_num_rows($results);

				for ($i=0;$i<$nrows;$i++)

				{
				$n = $i + 1;
				$row = mysqli_fetch_array($results);
				extract($row);
				echo"'$f5_year',"; 
				}

				?>  
					
	  ],

          

              title: {
                        text: 'Year',
                
                    },	     
       

	}

        };

        var chart = new ApexCharts(document.querySelector("#chartuniyyk"), options);
        chart.render();
      
      
    </script>


    
  </body>
</html>



