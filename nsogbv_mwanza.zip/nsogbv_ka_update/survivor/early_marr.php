<!DOCTYPE html>

	<script src="dist/apexcharts/dist/apexcharts.js"></script>
<html lang="en">
  <head>

  </head>

  <body>
     <div id="chartagemarruu" class="Piechart"></div>

    <script>
      
        var options = {
          series: [
		  
		  <?php
		  //$District=$_GET["d"];
$query  = "select A5_T_A, count(*) total from (select * from (SELECT case when a4_district='102' then 'Karonga' end district, case 
when A5_T_A ='10201' then 'TA Kilupula' 
when A5_T_A ='10205' then 'TA Mwirangombe' when A5_T_A ='10202' then 'TA Mwakaboko' when A5_T_A ='10203' then 'TA Kyungu' 
when A5_T_A ='10204' then 'TA Wasambo' end A5_T_A, 
floor(DATEDIFF(CURDATE(), str_to_date(concat(a3_day,'/',a3_month,'/',a3_year),'%d/%m/%Y'))/365) years, A8 Marry 
from gbv_cases2 where a8 in(2,3) ) as mee where years<18 group by A5_T_A) marriages GROUP by A5_T_A";


$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"$total,"; 
}

?>  	  
		  ],
          chart: {
          width: 320,
          type: 'pie',
        },
		legend: {
              position: 'bottom',
            },
        labels: [
		
		
		
		<?php
	//	$District=$_GET["d"];
$query  = "select A5_T_A, count(*) total from (select * from (SELECT case when a4_district='102' then 'Karonga' end district, case 
when A5_T_A ='10201' then 'TA Kilupula' 
when A5_T_A ='10205' then 'TA Mwirangombe' when A5_T_A ='10202' then 'TA Mwakaboko' when A5_T_A ='10203' then 'TA Kyungu' 
when A5_T_A ='10204' then 'TA Wasambo' end A5_T_A, 
floor(DATEDIFF(CURDATE(), str_to_date(concat(a3_day,'/',a3_month,'/',a3_year),'%d/%m/%Y'))/365) years, A8 Marry 
from gbv_cases2 where a8 in(2,3) ) as mee where years<18 group by A5_T_A) marriages GROUP by A5_T_A";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);



echo"'$A5_T_A',"; 
}

?>
		
		],
        responsive: [{
          breakpoint: 380,
          options: {
            chart: {
              width: 380,
            },
          }
        }],
        dataLabels: {
          formatter(val, opts) {
            const name = opts.w.globals.labels[opts.seriesIndex]
            return [name, val.toFixed(1) + '%']
          }
        },
        legend: {
          show: false
        },
        plotOptions: {
          pie: {
            dataLabels: {
              offset: -0
            }
          }
		}
        };

        var chart = new ApexCharts(document.querySelector("#chartagemarruu"), options);
        chart.render();
      
      
    </script>

    
  </body>
</html>