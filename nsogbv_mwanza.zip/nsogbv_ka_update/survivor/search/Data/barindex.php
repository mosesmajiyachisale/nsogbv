
	<script src="../dist/apexcharts/dist/apexcharts.js"></script>



<!----end--->

  
     <div id="chartuni"></div>

    <script>
        var options = {
          series: [{name:'cases',
          data: [
		  <?php
$query  = "select a4_district, count(*) total
  from sgbv.searcher  group by a4_district";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"$total,"; 
}

?>  
		  
		  ]
        }],
          chart: {
          type: 'bar',
          height: 350,

        },
        plotOptions: {
          bar: {
            horizontal: false,
          }
        },
        dataLabels: {
          enabled: true,
        },
        xaxis: {
          categories: [
		  
				
			<?php
$query  = "select a4_district, count(*) total
  from sgbv.searcher  group by a4_district";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"'$a4_district',"; 
}

?>  
			
			
          ],
        }
        };

        var chart = new ApexCharts(document.querySelector("#chartuni"), options);
        chart.render();
      
      
    </script>


    
  </body>
</html>



