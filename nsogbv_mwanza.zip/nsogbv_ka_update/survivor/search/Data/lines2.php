

<?php //include("dbconnect.php"); ?>
	 

<!----end--->

  
     <div id="chartuniyyl"></div>

    <script>
                var options = {
          series: [
          {
            name: "2021",
            data: [<?php
			//	$query  = "select f5_month,f5_year, count(*) counted from gbv_cases2 where f5_year='2021' group by f5_month";
        $query    ="select f5_month,f5_year, count(*) counted from searcher where f5_year='2021' group by f5_month order by f5_month asc";
				$results = mysqli_query($link, $query);
				$nrows = mysqli_num_rows($results);
				$row = mysqli_num_rows($results);

				for ($i=0;$i<$nrows;$i++)

				{
				$n = $i + 1;
				$row = mysqli_fetch_array($results);
				extract($row);
				echo"'$counted',"; 
				}

				?>]
          },
          {
            name: "2022",
            data: [<?php
			//	$query  = "select f5_month,f5_year, count(*) counted from gbv_cases2 where f5_year='2022' group by f5_month";
        $query    ="select f5_month,f5_year, count(*) counted from searcher where f5_year='2022' group by f5_month order by f5_month asc";
				$results = mysqli_query($link, $query);
				$nrows = mysqli_num_rows($results);
				$row = mysqli_num_rows($results);

				for ($i=0;$i<$nrows;$i++)

				{
				$n = $i + 1;
				$row = mysqli_fetch_array($results);
				extract($row);
				echo"'$counted',"; 
				}

				?>]
	  }

,
          {
            name: "2023",
            data: [<?php
                                $query  = "select f5_month,f5_year, count(*) counted from searcher where f5_year='2023' group by f5_month order by f5_month asc";

                                $results = mysqli_query($link, $query);
                                $nrows = mysqli_num_rows($results);
                                $row = mysqli_num_rows($results);

                                for ($i=0;$i<$nrows;$i++)

                                {
                                $n = $i + 1;
                                $row = mysqli_fetch_array($results);
                                extract($row);
                                echo"'$counted',";
                                }

                                ?>]
          },
          {
            name: "2024",
            data: [<?php
			//	$query  = "select f5_month,f5_year, count(*) counted from gbv_cases2 where f5_year='2024' group by f5_month";
      $query    ="select f5_month,f5_year, count(*) counted from searcher where f5_year='2024' group by f5_month order by f5_month asc";
				$results = mysqli_query($link, $query);
				$nrows = mysqli_num_rows($results);
				$row = mysqli_num_rows($results);

				for ($i=0;$i<$nrows;$i++)

				{
				$n = $i + 1;
				$row = mysqli_fetch_array($results);
				extract($row);
				echo"'$counted',"; 
				}

				?>]
	  },
        ],
        
          chart: {
          height: 600,
          type: 'line',
          dropShadow: {
            enabled: true,
            color: '#000',
           top: 18,
           left: 7,
            blur: 10,
            opacity: 0.2
          },
          toolbar: {
            show: false
          }
        },
        colors: ['#77B6EA', '#545454','#008080','#42e9f5'],
        dataLabels: {
          enabled: true,
        },
        stroke: {
          curve: 'smooth'
        },
        title: {
        //  text: 'Numbers of cases',
        //  align: 'center'
        },
        grid: {
          borderColor: '#e7e7e7',
          row: {
            colors: ['#f3f3f3', 'transparent'], // takes an array which will be repeated on columns
            opacity: 0.5
          },
        },
        markers: {
          size: 1
        },
        xaxis: {
          categories: [<?php
				$query  = "select case when f5_month ='1' then 'Jan' when f5_month ='2' then 'Feb' when f5_month ='3' then 'Mar' when f5_month ='4' then 'Apr' when f5_month ='5' then 'May' when f5_month ='6' then 'Jun' when f5_month ='7' then 'Jul' when f5_month ='8' then 'Aug' when f5_month ='9' then 'Sep' when f5_month ='10' then 'Oct' when f5_month ='11' then 'Nov' when f5_month ='12' then 'Dec' else 'Jul' end as months from searcher group by f5_month";

				$results = mysqli_query($link, $query);
				$nrows = mysqli_num_rows($results);
				$row = mysqli_num_rows($results);

				for ($i=0;$i<$nrows;$i++)

				{
				$n = $i + 1;
				$row = mysqli_fetch_array($results);
				extract($row);
				//echo"'$months',";
				echo"'Jan','Feb','Mar','Apr','May','June','Jul','Aug','Sep','Oct','Nov','Dec',"; 
				}

				?>],
          title: {
            text: 'Month'
          }
        },
        yaxis: {
          title: {
            text: '# of cases'
          },
          min: 0,
          max: 500
        },
        legend: {
          position: 'top',
          horizontalAlign: 'right',
          floating: true,
          offsetY: -25,
          offsetX: -5
        }
        };

        var chart = new ApexCharts(document.querySelector("#chartuniyyl"), options);
        chart.render();
      
      
    </script>


    
  </body>
</html>




