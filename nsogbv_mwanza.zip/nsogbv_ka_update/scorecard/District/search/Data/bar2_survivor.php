<!DOCTYPE html>

	<script src= "../../dist/apexcharts/dist/apexcharts.js"></script>
<html lang="en">
  <head>

 
 

  </head>


  <body>
     <div id="chart3mz1"></div>

    <script>
      
        var options = {
          series: [{
          name: 'Chinali',
          data: [
		  		  <?php
$query  = "select A5_T_A, A6_VILLAGE, sum(case when A5_T_A ='CHINALI' then 1 end) Chinali,
sum(case when A5_T_A ='CHINDI' then 1 end) Chindi,
sum(case when A5_T_A ='JARAVIKUBA' then 1 end) Jaravikuba,
sum(case when A5_T_A ='MZIKUBOLA' then 1 end) Mzikubola
  from sgbv.searcher where A4_DISTRICT ='Machinga' group by A5_T_A, A6_VILLAGE";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"'$Chinali',"; 
}

?> 
		  
		  
		  
		  ]
        }, {
          name: 'Chindi',
          data: [
		  
		  <?php
$query  = "select A5_T_A, A6_VILLAGE, sum(case when A5_T_A ='CHINALI' then 1 end) Chinali,
sum(case when A5_T_A ='CHINDI' then 1 end) Chindi,
sum(case when A5_T_A ='JARAVIKUBA' then 1 end) Jaravikuba,
sum(case when A5_T_A ='MZIKUBOLA' then 1 end) Mzikubola
  from sgbv.searcher where A4_DISTRICT ='Machinga' group by A5_T_A, A6_VILLAGE";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"'$Chindi',"; 
}

?> 
		  
		  ]
        },  
		
		{
          name: 'Jaravikuba',
          data: [<?php
$query  = "select A5_T_A, A6_VILLAGE, sum(case when A5_T_A ='CHINALI' then 1 end) Chinali,
sum(case when A5_T_A ='CHINDI' then 1 end) Chindi,
sum(case when A5_T_A ='JARAVIKUBA' then 1 end) Jaravikuba,
sum(case when A5_T_A ='MZIKUBOLA' then 1 end) Mzikubola
  from sgbv.searcher where A4_DISTRICT ='Machinga' group by A5_T_A, A6_VILLAGE";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"'$Jaravikuba',"; 
}

?>]
        } ,  
		
		{
          name: 'Mzikubola',
          data: [<?php
$query  = "select A5_T_A, A6_VILLAGE, sum(case when A5_T_A ='CHINALI' then 1 end) Chinali,
sum(case when A5_T_A ='CHINDI' then 1 end) Chindi,
sum(case when A5_T_A ='JARAVIKUBA' then 1 end) Jaravikuba,
sum(case when A5_T_A ='MZIKUBOLA' then 1 end) Mzikubola
  from sgbv.searcher where A4_DISTRICT ='Machinga' group by A5_T_A, A6_VILLAGE";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"'$Mzikubola',"; 
}

?>]
        } 
		
		
		],
          chart: {
          type: 'bar',
          height: 350
        },
        plotOptions: {
          bar: {
            horizontal: false,
            columnWidth: '55%',
            endingShape: 'rounded'
          },
        },
        dataLabels: {
          enabled: false
        },
        stroke: {
          show: true,
          width: 2,
          colors: ['transparent']
        },
        xaxis: {
          categories: [
		  
		  		  <?php
$query  = "select A5_T_A, A6_VILLAGE, sum(case when A5_T_A ='CHINALI' then 1 end) Chinali,
sum(case when A5_T_A ='CHINDI' then 1 end) Chindi,
sum(case when A5_T_A ='JARAVIKUBA' then 1 end) Jaravikuba,
sum(case when A5_T_A ='MZIKUBOLA' then 1 end) Mzikubola
  from sgbv.searcher where A4_DISTRICT ='Machinga' group by A5_T_A, A6_VILLAGE";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"'$A6_VILLAGE',"; 
}

?> 
		  
		  ],
        },
        yaxis: {
          title: {
            text: 'Number of cases'
          }
        },
        fill: {
          opacity: 1
        },
        tooltip: {
          y: {
            formatter: function (val) {
             // return "$ " + val + " thousands"
			   return val 
            }
          }
        }
        };

        var chart = new ApexCharts(document.querySelector("#chart3mz1"), options);
        chart.render();
      
      
    </script>

    
  </body>
</html>
