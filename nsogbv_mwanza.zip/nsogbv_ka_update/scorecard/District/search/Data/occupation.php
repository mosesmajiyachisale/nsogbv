<!DOCTYPE html>

<?php $District=$_GET['d'];?>
<html lang="en">
  <head>

 
 

  </head>

  <body>
     <div id="chartomzz" class="Piechart"></div>

    <script>
      
        var options = {
          series: [
		  
		  <?php
$query  = "SELECT a4_district,  case 
when a10 = 1 then 'Formal Employment' 
when a10 = 2 then 'Business' 
when a10 = 3 then 'Farmer' 
when a10 = 4 then 'Casual Labour' 
when a10 = 5 then 'Student'
end occupation, count(*) total FROM sgbv.searcher where a4_district = '$District' group by a10";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"$total,"; 
}

?>  	  
		  ],
          chart: {
          width: 320,
          type: 'pie',
        },
		legend: {
              position: 'bottom',
            },
        labels: [
		
		
		
		<?php
$query  = "SELECT a4_district,  case 
when a10 = 1 then 'Formal Employment' 
when a10 = 2 then 'Business' 
when a10 = 3 then 'Farmer' 
when a10 = 4 then 'Casual Labour' 
when a10 = 5 then 'Student'
end occupation, count(*) total FROM sgbv.searcher where a4_district = '$District' group by a10 ";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);



echo"'$occupation',"; 
}

?>
		
		],
        responsive: [{
          breakpoint: 1600,
          options: {
            chart: {
              width: 240
            },
            legend: {
              position: 'bottom'
            }
          }
        }],
        dataLabels: {
          formatter(val, opts) {
            const name = opts.w.globals.labels[opts.seriesIndex]
            return [name, val.toFixed(1) + '%']
          }
        },
        legend: {
          show: false
        },
        plotOptions: {
          pie: {
            dataLabels: {
              offset: -0
            }
          }
		}
        };

        var chart = new ApexCharts(document.querySelector("#chartomzz"), options);
        chart.render();
      
      
    </script>

    
  </body>
</html>