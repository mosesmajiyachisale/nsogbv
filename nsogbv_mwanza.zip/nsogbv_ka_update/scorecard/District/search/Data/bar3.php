

	<script src="../../dist/apexcharts/dist/apexcharts.js"></script>



<!----end--->

  
     <div id="chartun"></div>

    <script>
      
        var options = {
          series: [{
          data: [
		  <?php
$query  = "select A5_T_A, count(*) total
  from sgbv.searcher where A4_DISTRICT ='Machinga' group by A5_T_A";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"$total,"; 
}

?>  
		  
		  ]
        }],
          chart: {
          type: 'bar',
          height: 350,

        },
        plotOptions: {
          bar: {
            horizontal: false,
          }
        },
        dataLabels: {
          enabled: false,
        },
        xaxis: {
          categories: [
		  
				
			<?php
$query  = "select A5_T_A, count(*) total
  from sgbv.searcher where A4_DISTRICT ='Machinga' group by A5_T_A ";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"'$A5_T_A',"; 
}

?>  
			
			
          ],
        }
        };

        var chart = new ApexCharts(document.querySelector("#chartun"), options);
        chart.render();
      
      
    </script>


    
  </body>
</html>



