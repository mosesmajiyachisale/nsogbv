

<?php $District=$_GET['d'];?>
<!----end--->

  
     <div id="chart2uyu"></div>

    <script>
      
        var options = {
          series: [{name:'cases',
          data: [
		  
		
		  
		  
		  <?php
			$District=$_GET['d'];
			$query  = "select * from (select distinct  A5_T_A,A6_VILLAGE, count(*) total
			  from sgbv.searcher where a4_district ='$District'  group by A5_T_A,A6_VILLAGE order by total desc) as aaa where total>1 and A6_VILLAGE is not null limit 20";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"$total,"; 
}

?>  
		  
		  ]
        }],
          chart: {
          type: 'bar',
          height: 350
        },
		fill: {
  colors: ['#7ddc1f', '#E91E63', '#9C27B0']
},
        plotOptions: {
          bar: {
            horizontal: true,
          }
        },
        dataLabels: {
          enabled: false
        },
        xaxis: {
          categories: [
		  
		  
		 
			
			
			
			<?php
			$District=$_GET['d'];
			$query  = "select * from (select distinct  A5_T_A,A6_VILLAGE, count(*) total
			  from sgbv.searcher where a4_district ='$District'  group by A5_T_A,A6_VILLAGE order by total desc) as aaa where total>1 and A6_VILLAGE is not null limit 20";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"\"$A6_VILLAGE\","; 
}

?>  
			
			
          ],
        }
        };

        var chart = new ApexCharts(document.querySelector("#chart2uyu"), options);
        chart.render();
      
      
    </script>


    
  </body>
</html>



