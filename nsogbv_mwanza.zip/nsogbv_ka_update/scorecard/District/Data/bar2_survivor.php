<!DOCTYPE html>
	<script src="dist/apexcharts/dist/apexcharts.js"></script>
<html lang="en">
  <head>

 
 

  </head>


  <body>
     <div id="chart3Nmhg"></div>

    <script>
      
        var options = {
          series: [{
          name: 'Chiwalo',
          data: [
		  		  <?php
$query  = "select A6_VILLAGE, sum(case when A5_T_A ='CHIWALO' then 1 end) Chiwalo,
sum(case when A5_T_A ='CHIKWEWO' then 1 end) Chikwewo
  from sgbv.gbv_cases2 where A4_DISTRICT ='Machinga' group by A5_T_A, A6_VILLAGE";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"'$Chiwalo',"; 
}

?> 
		  
		  
		  
		  ]
        }, 

		{
          name: 'Chikwewo',
          data: [
		  
		  <?php
$query  = "select A6_VILLAGE, sum(case when A5_T_A ='CHIWALO' then 1 end) Chiwalo,
sum(case when A5_T_A ='CHIKWEWO' then 1 end) Chikwewo
  from sgbv.gbv_cases2 where A4_DISTRICT ='Machinga' group by A5_T_A, A6_VILLAGE";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"'$Chikwewo',"; 
}

?> 
		  
		  ]
        }, /* {
          name: 'Free Cash Flow',
          data: [35, 41, 36, 26, 45, 48, 52, 53, 41]
        } */],
          chart: {
          type: 'bar',
          height: 350
        },
        plotOptions: {
          bar: {
            horizontal: false,
            columnWidth: '55%',
         //   endingShape: 'rounded'
          },
        },
        dataLabels: {
          enabled: false
        },
        stroke: {
          show: true,
          width: -6,
          colors: ['transparent']
        },
        xaxis: {
          categories: [
		  
		  		  <?php
$query  = "select A6_VILLAGE village, sum(case when A5_T_A ='CHIWALO' then 1 end) Chiwalo,
sum(case when A5_T_A ='CHIKWEWO' then 1 end) Chikwewo
  from sgbv.gbv_cases2 where A4_DISTRICT ='Machinga' group by A5_T_A, A6_VILLAGE";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"'$village',"; 
}

?> 
		  
		  ],
        },
        yaxis: {
          title: {
            text: '# of cases'
          }
        },
		
        fill: {
          opacity: 1
        },
        tooltip: {
          y: {
            formatter: function (val) {
             // return "$ " + val + " thousands"
			   return val 
            }
          }
        }
        };

        var chart = new ApexCharts(document.querySelector("#chart3Nmhg"), options);
        chart.render();
      
      
    </script>

    
  </body>
</html>
