<!DOCTYPE html>

	<script src="dist/apexcharts/dist/apexcharts.js"></script>
<html lang="en">
  <head>

 
 

  </head>

  <body>
     <div id="chartmhg2" class="Piechart"></div>

    <script>
      
        var options = {
          series: [
		  
		  <?php
		  $District=$_GET["d"];
$query  = "select * from (SELECT (CASE WHEN b1 = 1 THEN 'Sexual'  END) type_of_violence, sum(b1) violence FROM sgbv.gbv_cases2 where b1 = 1 and A4_DISTRICT ='$District'
union
SELECT (CASE WHEN b2 = 1 THEN 'Physical'  END) type_of_violence, sum(b2) violence FROM sgbv.gbv_cases2 where b2 = 1 and A4_DISTRICT ='$District'
union
SELECT (CASE WHEN b3 = 1 THEN 'Economic'  END) type_of_violence,  sum(b3) violence FROM sgbv.gbv_cases2 where b3 = 1 and A4_DISTRICT ='$District'
union
SELECT (CASE WHEN b4= 1 THEN 'Psychological'  END) type_of_violence, sum(b4) violence FROM sgbv.gbv_cases2 where b4 = 1 and A4_DISTRICT ='$District'
union
SELECT (CASE WHEN b5= 1 THEN 'Harmful Practices'  END) type_of_violence, sum(b5) violence FROM sgbv.gbv_cases2 where b5 = 1 and A4_DISTRICT ='$District'
) as tyt where type_of_violence is not null";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"$violence,"; 
}

?>  	  
		  ],
          chart: {
          width: 320,
          type: 'pie',
        },
		legend: {
              position: 'bottom',
            },
        labels: [
		
		
		
		<?php
		$District=$_GET["d"];
$query  = "select * from (SELECT (CASE WHEN b1 = 1 THEN 'Sexual'  END) type_of_violence, sum(b1) violence FROM sgbv.gbv_cases2 where b1 = 1 and A4_DISTRICT ='$District'
union
SELECT (CASE WHEN b2 = 1 THEN 'Physical'  END) type_of_violence, sum(b2) violence FROM sgbv.gbv_cases2 where b2 = 1 and A4_DISTRICT ='$District'
union
SELECT (CASE WHEN b3 = 1 THEN 'Economic'  END) type_of_violence,  sum(b3) violence FROM sgbv.gbv_cases2 where b3 = 1 and A4_DISTRICT ='$District'
union
SELECT (CASE WHEN b4= 1 THEN 'Psychological'  END) type_of_violence, sum(b4) violence FROM sgbv.gbv_cases2 where b4 = 1 and A4_DISTRICT ='$District'
union
SELECT (CASE WHEN b5= 1 THEN 'Harmful Practices'  END) type_of_violence, sum(b5) violence FROM sgbv.gbv_cases2 where b5 = 1 and A4_DISTRICT ='$District'
) as tyt where type_of_violence is not null";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);



echo"'$type_of_violence',"; 
}

?>
		
		],
        responsive: [{
          breakpoint: 380,
          options: {
            chart: {
              width: 380
            },
            legend: {
              position: 'bottom'
            }
          }
        }],
        dataLabels: {
          formatter(val, opts) {
            const name = opts.w.globals.labels[opts.seriesIndex]
            return [name, val.toFixed(1) + '%']
          }
        },
        legend: {
          show: false
        },
        plotOptions: {
          pie: {
            dataLabels: {
              offset: -15
            }
          }
		}
        };

        var chart = new ApexCharts(document.querySelector("#chartmhg2"), options);
        chart.render();
      
      
    </script>

    
  </body>
</html>