
	<script src="dist/apexcharts/dist/apexcharts.js"></script>



<!----end--->

  
     <div id="chartumhg"></div>

    <script>
      
        var options = {
          series: [{name:'Cases',
          data: [
		  <?php
		  $District=$_GET["d"];
$query  = "SELECT * from 
(SELECT A4_DISTRICT, (CASE WHEN a7_1 = 1 THEN 'Blindeness'  END) disability, sum(a7_1) total FROM sgbv.gbv_cases2 where a7_1 = 1  AND a4_district='$District'
union
SELECT  A4_DISTRICT, (CASE WHEN a7_2 = 1 THEN 'Hearing'  END) disability, sum(a7_2) total FROM sgbv.gbv_cases2 where a7_2 = 1  AND a4_district='$District'
union
SELECT  A4_DISTRICT, (CASE WHEN a7_3 = 1 THEN 'Walking'  END) disability,  sum(a7_3) total FROM sgbv.gbv_cases2 where a7_3 = 1  AND a4_district='$District'
union
SELECT  A4_DISTRICT, (CASE WHEN  a7_4= 1 THEN 'Speaking'  END) disability, sum(a7_4) total FROM sgbv.gbv_cases2 where a7_4 = 1  AND a4_district='$District'
union
SELECT  A4_DISTRICT, (CASE WHEN  a7_5= 1 THEN 'Intellectual'  END) disability, sum(a7_5) total FROM sgbv.gbv_cases2 where a7_5 = 1  AND a4_district='$District'
union
SELECT  A4_DISTRICT, (CASE WHEN  a7_6= 1 THEN 'Self Care'  END) disability, sum(a7_6) total FROM sgbv.gbv_cases2 where a7_6 = 1  AND a4_district='$District'
union
SELECT  A4_DISTRICT, (CASE WHEN  a7_7= 1 THEN 'Albinism'  END) disability, sum(a7_7) total FROM sgbv.gbv_cases2 where a7_7 = 1  AND a4_district='$District'
union
SELECT  A4_DISTRICT, (CASE WHEN  a7_8= 1 THEN 'Epilepsy'  END) disability, sum(a7_8) total FROM sgbv.gbv_cases2 where  a7_8 = 1  AND a4_district='$District'
)as temp1 where A4_DISTRICT = '$District' and disability is not null";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"$total,"; 
}

?>  
		  
		  ]
        }],
          chart: {
          type: 'bar',
          height: 350
        },
        plotOptions: {
          bar: {
            horizontal: false,
			
          }
        },
        dataLabels: {
          enabled: false
        },
        xaxis: {
          categories: [
		  
				
			<?php
			$District=$_GET["d"];
$query  = "SELECT * from 
(SELECT A4_DISTRICT, (CASE WHEN a7_1 = 1 THEN 'Blindeness'  END) disability, sum(a7_1) total FROM sgbv.gbv_cases2 where a7_1 = 1  AND a4_district='$District'
union
SELECT  A4_DISTRICT, (CASE WHEN a7_2 = 1 THEN 'Hearing'  END) disability, sum(a7_2) total FROM sgbv.gbv_cases2 where a7_2 = 1  AND a4_district='$District'
union
SELECT  A4_DISTRICT, (CASE WHEN a7_3 = 1 THEN 'Walking'  END) disability,  sum(a7_3) total FROM sgbv.gbv_cases2 where a7_3 = 1  AND a4_district='$District'
union
SELECT  A4_DISTRICT, (CASE WHEN  a7_4= 1 THEN 'Speaking'  END) disability, sum(a7_4) total FROM sgbv.gbv_cases2 where a7_4 = 1  AND a4_district='$District'
union
SELECT  A4_DISTRICT, (CASE WHEN  a7_5= 1 THEN 'Intellectual'  END) disability, sum(a7_5) total FROM sgbv.gbv_cases2 where a7_5 = 1  AND a4_district='$District'
union
SELECT  A4_DISTRICT, (CASE WHEN  a7_6= 1 THEN 'Self Care'  END) disability, sum(a7_6) total FROM sgbv.gbv_cases2 where a7_6 = 1  AND a4_district='$District'
union
SELECT  A4_DISTRICT, (CASE WHEN  a7_7= 1 THEN 'Albinism'  END) disability, sum(a7_7) total FROM sgbv.gbv_cases2 where a7_7 = 1  AND a4_district='$District'
union
SELECT  A4_DISTRICT, (CASE WHEN  a7_8= 1 THEN 'Epilepsy'  END) disability, sum(a7_8) total FROM sgbv.gbv_cases2 where  a7_8 = 1  AND a4_district='$District'
)as temp1 where A4_DISTRICT = '$District' and disability is not null";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"'$disability',"; 
}

?>  
			
			
          ],
        }
        };

        var chart = new ApexCharts(document.querySelector("#chartumhg"), options);
        chart.render();
      
      
    </script>


    
  </body>
</html>



