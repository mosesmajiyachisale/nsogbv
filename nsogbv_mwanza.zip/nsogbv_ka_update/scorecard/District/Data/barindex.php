
	<script src="../../../dist/apexcharts/dist/apexcharts.js"></script>


<!----end--->

  
     <div id="chartuni"></div>

    <script>
        var options = {
          series: [{name:'Cases',
          data: [
		  <?php
		  $District=$_GET["d"];
$query  = "select A5_T_A, count(*) total from sgbv.gbv_cases2 where A4_DISTRICT = '$District'  group by A5_T_A order by total desc";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"$total,"; 
}

?>  
		  
		  ]
        }],
          chart: {
          type: 'bar',
          height: 350,

        },
        plotOptions: {
          bar: {
            horizontal: false,
          }
        },
        dataLabels: {
          enabled: false,
        },
        xaxis: {
          categories: [
		  
				
			<?php
			$District=$_GET["d"];
$query  = "select A5_T_A, count(*) total from sgbv.gbv_cases2 where A4_DISTRICT = '$District'  group by A5_T_A order by total desc";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"\"$A5_T_A\","; 
}

?>  
			
			
          ],
        }
        };

        var chart = new ApexCharts(document.querySelector("#chartuni"), options);
        chart.render();
      
      
    </script>


    
  </body>
</html>



