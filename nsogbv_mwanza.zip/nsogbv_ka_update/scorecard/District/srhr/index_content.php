<?php include("../../dbconnect.php"); ?>


          <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="row page-titles">
                <div class="col-md-5 col-12 align-self-center">
                    <h3 class="text-themecolor mb-0">National SGBV Dashboard</h3>
                    <ol class="breadcrumb mb-0">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                        <li class="breadcrumb-item active">Dashboard</li>
                        <li class="breadcrumb-item active">Sexual Reproductive and Human Rights</li>
                    </ol>
                </div>
                <div class="col-md-7 col-12 align-self-center d-none d-md-block">
                    <div class="d-flex mt-2 justify-content-end">
                        <div class="d-flex mr-3 ml-2">
                            <div class="chart-text mr-2">
									<?php
										$query  = "select sum(b5) Total_harmful FROM sgbv.gbv_cases2 WHERE b5 = 1 group by b5 ";

										$results = mysqli_query($link, $query);
										$nrows = mysqli_num_rows($results);
										$row = mysqli_num_rows($results);

										for ($i=0;$i<$nrows;$i++)

										{
										$n = $i + 1;
										$row = mysqli_fetch_array($results);
										extract($row);



										//echo"'$Total_harmful',"; 
										}

										?>

										<?php
										$query  = "select count(*) all_violence from sgbv.gbv_cases2";

										$results = mysqli_query($link, $query);
										$nrows = mysqli_num_rows($results);
										$row = mysqli_num_rows($results);

										for ($i=0;$i<$nrows;$i++)

										{
										$n = $i + 1;
										$row = mysqli_fetch_array($results);
										extract($row);



										//echo"'$Total_harmful',"; 
										}

									?>
                                <h6 class="mb-0"><small>HARMFUL PRACTICE(S)</small></h6>
                               <h4 class="mt-0 text-info"><?php 
								 if ($Total_harmful < "1") {
                                             echo "0";
                                            }
									else{
										echo"$Total_harmful";
									}
								
								?></h4>
                            </div>
                            <div class="spark-chart">
                                <div id="monthchart"></div>
                            </div>
                        </div>
                        <div class="d-flex ml-2">
                            <div class="chart-text mr-2">
                                <h6 class="mb-0"><small>TOTAL SGBV CASES</small></h6>
                                <h4 class="mt-0 text-primary"><?php echo"$all_violence";?></h4>
                            </div>
                            <div class="spark-chart">
                                <div id="lastmonthchart"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- Row -->
                <div class="row">
                    <!-- Column -->
                    <div class="col-lg-8 col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-12">
                                       
                                            <div>
                                                <h3 class="card-title">Sexual Reproductive and Human Rights</h3>
                                           <!--     <h6 class="card-subtitle">PP Pie Chart</h6>  -->
                                            </div>
                                            
                                            <?php include("Data/srhr.php"); ?>
                                          
                                        
                                    </div>
                                   
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <h3 class="card-title">Child Abuse </h3>
                             <!--   <h6 class="card-subtitle">Now Bar Visual</h6> -->
                                 <div class="col-10">   
                                            <?php include("Data/child_abuse.php"); ?> 
                                    </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->