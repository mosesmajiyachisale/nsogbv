<!DOCTYPE html>

<?php include("../../dbconnect.php"); ?>
	<script src="../dist/apexcharts/dist/apexcharts.js"></script>
<html lang="en">
  <head>

 
 

  </head>

  <body>
     <div id="chartchild"></div>

    <script>
      
        var options = {
          series: [
		  
		  <?php
$query  = "select case when A2_SEX = 1 then 'Male'
			when A2_SEX = 2 then 'Female'
	end
sex , count(C1_CHILD_ABUSE) total from sgbv.gbv_cases2 where C1_CHILD_ABUSE=1 group by A2_SEX";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"$total,"; 
}

?>  	  
		  ],
          chart: {
          width: 350,
          type: 'donut',
        },
        labels: [
		
		
		
		<?php
$query  = "select case when A2_SEX = 1 then 'Male'
			when A2_SEX = 2 then 'Female'
	end
sex , count(C1_CHILD_ABUSE) total from sgbv.gbv_cases2 where C1_CHILD_ABUSE=1 group by A2_SEX";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);



echo"'$sex',"; 
}

?>
		
		],
        responsive: [{
          breakpoint: 380,
          options: {
            chart: {
              width: 380
            },
            legend: {
              position: 'bottom'
            }
          }
        }]
        };

        var chart = new ApexCharts(document.querySelector("#chartchild"), options);
        chart.render();
      
      
    </script>

    
  </body>
</html>