

<?php include("../../dbconnect.php"); ?>
	<script src="../dist/apexcharts/dist/apexcharts.js"></script>



<!----end--->

  
     <div id="chartab"></div>

    <script>
      
        var options = {
          series: [{
          data: [  
		  <?php
$query  = "SELECT * from 
(SELECT (CASE WHEN C1_CHILD_ABUSE = 1 THEN 'Child abuse '  END) srhr, sum(C1_CHILD_ABUSE ) total FROM sgbv.gbv_cases2 where C1_CHILD_ABUSE  = 1
union
SELECT (CASE WHEN C2_CHILD_NEGLECT = 1 THEN 'Child neglect'  END) srhr, sum(C2_CHILD_NEGLECT) total FROM sgbv.gbv_cases2 where C2_CHILD_NEGLECT = 1
union
SELECT (CASE WHEN C3_FORCED_TO_HAVE_MANY_CHILDREN = 1 THEN 'Forced to have children'  END) srhr,  sum(C3_FORCED_TO_HAVE_MANY_CHILDREN) total FROM sgbv.gbv_cases2 where C3_FORCED_TO_HAVE_MANY_CHILDREN = 1
union
SELECT (CASE WHEN  C4_FORCED_TO_ABORT = 1 THEN 'Forced to abort'  END) srhr, sum(C4_FORCED_TO_ABORT) total FROM sgbv.gbv_cases2 where C4_FORCED_TO_ABORT = 1
union
SELECT (CASE WHEN  C5_INFECTED_WITH_STIS_HIV_DELIBERATELY = 1 THEN 'Infected with STIs/HIV deliberately'  END) srhr, sum(C5_INFECTED_WITH_STIS_HIV_DELIBERATELY) total FROM sgbv.gbv_cases2 where C5_INFECTED_WITH_STIS_HIV_DELIBERATELY = 1
union
SELECT (CASE WHEN  C6_REFUSED_TO_USE_FAMILY_PLANNING_METHODS = 1 THEN 'Refused to use family planning methods'  END) srhr, sum(C6_REFUSED_TO_USE_FAMILY_PLANNING_METHODS ) total FROM sgbv.gbv_cases2 where C6_REFUSED_TO_USE_FAMILY_PLANNING_METHODS  = 1
union
SELECT (CASE WHEN  C7_REFUSED_CONJUGAL_RIGHTS = 1 THEN 'Refused conjugal rights'  END) srhr, sum(C7_REFUSED_CONJUGAL_RIGHTS) total FROM sgbv.gbv_cases2 where C7_REFUSED_CONJUGAL_RIGHTS = 1

)as temp2 where srhr is not null";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"$total,"; 
}

?>  
		  
		  ]
        }],
          chart: {
          type: 'bar',
          height: 350,
		   
        },
		
        plotOptions: {
          bar: {
            horizontal: true,
			responsive: true,
          }
        },
        dataLabels: {
          enabled: false
        },
        xaxis: {
          categories: [
		  
			<?php
$query  = "SELECT * from 
(SELECT (CASE WHEN C1_CHILD_ABUSE = 1 THEN 'Child abuse '  END) srhr, sum(C1_CHILD_ABUSE ) total FROM sgbv.gbv_cases2 where C1_CHILD_ABUSE  = 1
union
SELECT (CASE WHEN C2_CHILD_NEGLECT = 1 THEN 'Child neglect'  END) srhr, sum(C2_CHILD_NEGLECT) total FROM sgbv.gbv_cases2 where C2_CHILD_NEGLECT = 1
union
SELECT (CASE WHEN C3_FORCED_TO_HAVE_MANY_CHILDREN = 1 THEN 'Forced to have children'  END) srhr,  sum(C3_FORCED_TO_HAVE_MANY_CHILDREN) total FROM sgbv.gbv_cases2 where C3_FORCED_TO_HAVE_MANY_CHILDREN = 1
union
SELECT (CASE WHEN  C4_FORCED_TO_ABORT = 1 THEN 'Forced to abort'  END) srhr, sum(C4_FORCED_TO_ABORT) total FROM sgbv.gbv_cases2 where C4_FORCED_TO_ABORT = 1
union
SELECT (CASE WHEN  C5_INFECTED_WITH_STIS_HIV_DELIBERATELY = 1 THEN 'Infected with STIs/HIV deliberately'  END) srhr, sum(C5_INFECTED_WITH_STIS_HIV_DELIBERATELY) total FROM sgbv.gbv_cases2 where C5_INFECTED_WITH_STIS_HIV_DELIBERATELY = 1
union
SELECT (CASE WHEN  C6_REFUSED_TO_USE_FAMILY_PLANNING_METHODS = 1 THEN 'Refused to use family planning methods'  END) srhr, sum(C6_REFUSED_TO_USE_FAMILY_PLANNING_METHODS ) total FROM sgbv.gbv_cases2 where C6_REFUSED_TO_USE_FAMILY_PLANNING_METHODS  = 1
union
SELECT (CASE WHEN  C7_REFUSED_CONJUGAL_RIGHTS = 1 THEN 'Refused conjugal rights'  END) srhr, sum(C7_REFUSED_CONJUGAL_RIGHTS) total FROM sgbv.gbv_cases2 where C7_REFUSED_CONJUGAL_RIGHTS = 1

)as temp2 where srhr is not null";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"'$srhr',"; 
}

?>  
			
			
          ],
        }
        };

        var chart = new ApexCharts(document.querySelector("#chartab"), options);
        chart.render();
      
      
    </script>


    
  </body>
</html>



