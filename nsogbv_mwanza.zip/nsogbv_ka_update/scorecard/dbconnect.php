<?php

 // this will avoid mysql_connect() deprecation error.
 error_reporting( ~E_DEPRECATED & ~E_NOTICE );
 // but I strongly suggest you to use PDO or MySQLi.

  define('DBHOST', 'localhost');
 define('DBUSER', 'undpAdmin');
 define('DBPASS', 'Malawi128');
 define('DBNAME', 'sgbv');

 $conn = mysqli_connect(DBHOST,DBUSER,DBPASS,DBNAME);
 //$dbcon = mysql_select_db(DBNAME);

 if ( !$conn ) {
  die("Connection failed : " . mysql_error());
 }

 if ( !$conn ) {
  die("Database Connection failed : " . mysql_error());
 }
 
 ini_set('max_execution_time', 12000);
 
 ?>
 
 <?php
/* Database credentials. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
 
/* Attempt to connect to MySQL database */
//$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
$link = mysqli_connect(DBHOST, DBUSER, DBPASS, DBNAME);
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

if(!function_exists("mysql_query")){

 function mysql_query($link,$query){
  return mysqli_query($link,$query);
 }

 function mysql_fetch_array($obj){
  return mysqli_fetch_array($obj);
 }

 function mysql_num_rows($obj){
  return mysqli_num_rows($obj);
 }
 function mysql_connect($p,$x,$y,$z){
  return mysqli_connect($p, $x, $y, $z);
 }
}
?>