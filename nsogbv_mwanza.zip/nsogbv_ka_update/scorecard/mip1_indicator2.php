    <?php
    /**$sql =mysqli_query($link, "select * from gbv_cases2 limit 1 ");
    while($row = mysqli_fetch_array($sql))
    {
        $district = $row['a4_district'];
     */
//include("dbconnect.php");
//    Indicators save
    if (isset($_POST["indicator_ids"])) {
        $link->autocommit(FALSE);
        $ids = $_POST["indicator_ids"];
        $query ="UPDATE scorecard SET Baseline2019=?, Progress2020 =?, Progress2021 =?, Progress2022 =? WHERE id=?";
        $stmt = $link->prepare($query);
        $stmt->bind_param("ddddi", $Baseline2019, $Progress2020, $Progress2021, $Progress2022, $ind_id);
        foreach( $ids as $key => $value ) {
            $Baseline2019 = $_POST['Baseline2019_'.$value];
            $Progress2020 = $_POST['Progress2020_'.$value];
            $Progress2021 = $_POST['Progress2021_'.$value];
            $Progress2022 = $_POST['Progress2022_'.$value];
            $ind_id = $value;
            $stmt->execute();
        }
        if ($link->commit()) {
            echo "<div class='container-fluid' style='min-height: unset;'>";
                echo "<div class='alert alert-success' role='alert' style='margin-bottom: unset'>Indicators updated successfully.</div>";
            echo "</div>";
        } else {
            echo "<div class='container-fluid' style='min-height: unset;'>";
            echo "<div class='alert alert-danger' role='alert' style='margin-bottom: unset'>An error has occurred while truing to update indicators!</div>";
            echo "</div>";
        }
    }
//    get all indicators
    $f_area = isset($_POST['PriorityArea'])? $_POST['PriorityArea'] : 0;
    $sql =mysqli_query($link, "select * from scorecard WHERE PriorityArea =".$f_area);
    $indicators =[];
    if($sql) {
        while($row = mysqli_fetch_assoc($sql))
        {
            $indicators[] = $row;
        }
    } 
    ?>

    <!-- Row -->
    <!-- Row -->
    <div class="row">
        <!-- Column -->
        <!-- <div class="col-lg-12 col-md-12"> -->

        <div class="card">
            <!-- Tab panes -->
            <div class="tab-content">
                <div class="tab-pane" id="list" role="tabpanel">

                </div>
                <!-- Progress Bar -->
                <h4>Indicators</h4>
                <hr>
                <!-- End Progress Bar -->
                <?php
                                 //   $PriorityAreas = range(2016, date("Y"));
									    $sql22 =mysqli_query($link, "select * from scorecard group by areaId ASC");
										
                                    ?>
                <form name="PriorityArea_form" class="form-horizontal r-separator form-material"
                    action="mip1_indicator2.php" method="POST">
                    <div class="form-group row card-body">
                        <label for="Baseline2019" class="col-sm-2 col-form-label">Priority Area</label>
                        <div class="col-sm-10">
                            <select class="form-control input-height" required name="PriorityArea"
                                onchange="PriorityArea_form.submit();">
                                <option value="0">Select...----------------------</option>
                                <?php while ($row = mysql_fetch_array($sql22)) 
                                      {
                                      echo '<option value="'. $row['PriorityArea'] .'">' . $row['PriorityArea'] .'</option>';
                                      }
                                ?>
                            </select>
                        </div>
                    </div>
                </form>
                <form class="form-horizontal r-separator form-material" action="mip1_indicator2.php" method="POST">
                    <div class="card-body">
                        <input type="hidden" name="PriorityArea"
                            value="<?php if (isset($_POST['PriorityArea'])) {echo $_POST['PriorityArea'];}?>">
                        <?php
                                            foreach ($indicators as $indicator ) {
                                            ?>
                        <input type="hidden" name="indicator_ids[]" value="<?php echo $indicator["id"];?>">
                        <fieldset>
                            <legend>
                                <h5><?php echo $indicator["SDGIndicator"];?></h5>
                            </legend>
                            <div class="form-group row">
                                <label for="Baseline2019_<?php echo $indicator["id"];?>"
                                    class="col-sm-2 col-form-label">Baseline2019</label>
                                <div class="col-sm-10">
                                    <input name="Baseline2019_<?php echo $indicator["id"];?>" type="number"
                                        class="form-control input-height" id="rural_<?php echo $indicator["id"]?>"
                                        value="<?php echo $indicator["Baseline2019"];?>">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="Progress2020_<?php echo $indicator["id"];?>"
                                    class="col-sm-2 col-form-label">Progress2020</label>
                                <div class="col-sm-10">
                                    <input name="urban_<?php echo $indicator["id"];?>" type="number"
                                        class="form-control input-height"
                                        id="Progress2020_<?php echo $indicator["id"];?>"
                                        value="<?php echo $indicator["Progress2020"];?>">
                                </div>
                            </div>


                            <!--start -->
                            <div class="form-group row">
                                <label for="Progress2021_<?php echo $indicator["id"];?>"
                                    class="col-sm-2 col-form-label">Progress2021</label>
                                <div class="col-sm-10">
                                    <input name="Progress2021_<?php echo $indicator["id"];?>" type="number"
                                        class="form-control input-height"
                                        id="Progress2021_<?php echo $indicator["id"];?>"
                                        value="<?php echo $indicator["Progress2021"];?>">
                                </div>

                            </div>


                            <div class="form-group row">
                                <label for="Progress2022_<?php echo $indicator["id"];?>"
                                    class="col-sm-2 col-form-label">Progress2022</label>
                                <div class="col-sm-10">
                                    <input name="Progress2022_<?php echo $indicator["id"];?>" type="number"
                                        class="form-control input-height"
                                        id="Progress2022_<?php echo $indicator["id"];?>"
                                        value="<?php echo $indicator["Progress2022"];?>">
                                </div>

                            </div>

                            <!-- end here-->
                        </fieldset>
                        <hr>
                        <?php
                                            }
                                            ?>

                        <?php if (isset($f_area) && $f_area !=0) { ?>
                        <div class="form-group row">
                            <label for="update_btn" class="col-sm-2 col-form-label"></label>
                            <div class="col-sm-10">
                                <button type="submit" class="btn btn-info waves-effect waves-light" id="update_btn">Save
                                    data >></button>
                            </div>
                        </div>
                        <?php } ?>


                    </div>






                </form>

            </div>



            <!--  </div>-->
        </div>

        <!-- ============================================================== -->
        <!-- End Container fluid  -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- footer -->
        <!-- ============================================================== -->
        <?php //include("footer.php"); ?>
        <!-- ============================================================== -->
        <!-- End footer -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- End Page wrapper  -->
    <!-- ============================================================== -->

    <!-- ============================================================== -->
    <!-- End Wrapper -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- customizer Panel -->
    <!-- ============================================================== -->
    <?php // require_once "customizer.php";?>
    <!-- ============================================================== -->
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="../assets1/libs/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="../assets1/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="../assets1/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- apps -->
    <script src="../dist/js/app.min.js"></script>
    <script src="../dist/js/app.init.js"></script>
    <script src="../dist/js/app-style-switcher.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="../assets1/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
    <script src="../assets1/extra-libs/sparkline/sparkline.js"></script>
    <!--Wave Effects -->
    <script src="../dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="../dist/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="../dist/js/custom.min.js"></script>
    <!--This page plugins -->
    <script src="../assets1/libs/datatables/media/js/jquery.dataTables.min.js"></script>
    <script src="../dist/js/pages/datatable/custom-datatable.js"></script>
    <!-- start - This is for export functionality only -->
    <script src="https://cdn.datatables.net/buttons/1.5.1/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.flash.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.print.min.js"></script>
    <script src="../dist/js/pages/datatable/datatable-advanced.init.js"></script>
    </body>

    </html>