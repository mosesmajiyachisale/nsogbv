<?php include("../dbconnect.php"); 

$conn = mysqli_connect("localhost", "root", "","sgbv");
/*
for($year=2019; $year<=2030; $year++){
    
    $get = mysqli_query($conn,"SELECT * FROM scorecard");
    
    while($res = mysqli_fetch_array($get)){
        $id = $res['id'];
        $insert = mysqli_query($conn,"INSERT INTO `scoreyear` (`id`, `scorecard_id`, `target`, `year`, `stamp`, `score`) VALUES (NULL, '$id', '0', '$year', current_timestamp(), '0')");
        if($insert) echo 1;
        else echo 2;
    }
    
    
    
}
*/

?>
<style>
.anychart-ui-support {
    height: 100vh !important;
}
</style>
<!-- ============================================================== -->
<!-- Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<div class="row page-titles">
    <div class="col-md-5 col-12 align-self-center">
        <h3 class="text-themecolor mb-0">Gender Scorecard</h3>
        <ol class="breadcrumb mb-0">
            <li class="breadcrumb-item"><a href="../">Home</a></li>
            <!--   <li class="breadcrumb-item active">Survivors</li>-->
        </ol>
    </div>
    <div class="col-md-7 col-12 align-self-center d-none d-md-block">
        <div class="d-flex mt-2 justify-content-end">
            <div class="d-flex mr-3 ml-2">
                <div class="chart-text mr-2">
                    <?php
										$query  = "select sum(b5) Total_harmful FROM sgbv.gbv_cases2 WHERE b5 = 1 group by b5";

										$results = mysqli_query($link, $query);
										$nrows = mysqli_num_rows($results);
										$row = mysqli_num_rows($results);

										for ($i=0;$i<$nrows;$i++)

										{
										$n = $i + 1;
										$row = mysqli_fetch_array($results);
										extract($row);



										//echo"'$Total_harmful',"; 
										}

										?>

                    <?php
										$query  = "select count(*) all_violence from sgbv.gbv_cases2";

										$results = mysqli_query($link, $query);
										$nrows = mysqli_num_rows($results);
										$row = mysqli_num_rows($results);

										for ($i=0;$i<$nrows;$i++)

										{
										$n = $i + 1;
										$row = mysqli_fetch_array($results);
										extract($row);



										//echo"'$Total_harmful',"; 
										}

										?>
                    <h6 class="mb-0"><small>HARMFUL PRACTICE(S)</small></h6>
                    <h4 class="mt-0 text-info"><?php 
								 if ($Total_harmful < "1") {
                                             echo "0";
                                            }
									else{
										echo"$Total_harmful";
									}
								
								?></h4>
                </div>
            </div>
            <div class="d-flex ml-2">
                <div class="chart-text mr-2">
                    <h6 class="mb-0"><small>TOTAL SGBV CASES</small></h6>
                    <h4 class="mt-0 text-primary"><?php echo"$all_violence";?></h4>
                </div>
            </div>
        </div>
    </div>
</div>


<!-- ============================================================== -->
<!-- End Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- Container fluid  -->
<!-- ============================================================== -->
<div class="container-fluid">
    <!-- Row -->
    <div class="row">
        <!-- Column -->
        <div class="col-lg-12 col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-12">

                            <div>
                                <h6 class="card-title" style="text-align:center">GENDER SCORE CARD FOR SDG INDICATORS
                                    FOR MALAWI </h6>
                                <!--   <h6 class="card-subtitle">Pie Chart</h6> -->
                            </div>

                            <div class="uk-container">
                                <div class="form-group row card-body">
                                    <label for="Baseline2019" class="col-sm-2 col-form-label">Priority Area</label>
                                    <div class="col-sm-10">
                                        <select class="form-control input-height" required id="PriorityArea"
                                            onchange="updatePriority()">
                                            <option value="0">Select...</option>
                                            <?php
												$area = mysqli_query($conn, "SELECT * FROM scorecard group by areaId ");
												while($row = mysqli_fetch_array($area)){
													?>
                                            <option value="<?php echo $row['areaId'] ?>">
                                                <?php echo $row['PriorityArea'] ?></option>
                                            <?php
													
												}
											?>
                                        </select>
                                    </div>
                                </div>

                            </div>

                            <div class="uk-container" id="results">

                            </div>

                        </div>

                    </div>
                </div>
            </div>
        </div>
        <?php
        if(isset($_GET['area'])){
            $areaId = $_GET['area'];
            $getarea = mysqli_query($conn,"SELECT * FROM scorecard WHERE areaId=$areaId");
            $name = mysqli_fetch_array($getarea);
            $sId = $name['id'];
            ?>
        <div class="col-lg-12 col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-12">

                            <h2>Showing Results for priority area: <?php echo $name['PriorityArea'] ?></h2>

                            <div class="uk-overflow-auto">
                                <table class="uk-table uk-table-divider">
                                    <thead>
                                        <tr>
                                            <th>MGDSGoal</th>
                                            <th>Goal and Target</th>
                                            <th>Indicator</th>
                                            <th>Perfomance indicator</th>
                                            <th>Verification & sector</th>
                                            <?php 
                                            
                                            $years = mysqli_query($conn,"SELECT * FROM scoreyear WHERE scorecard_id='$sId'");
                                            
                                            while ($row = mysqli_fetch_array($years)){
                                                echo "<th> Progress ".$row['year']."</th>";
                                            }
                                        ?>

                                        </tr>
                                    </thead>
                                    <tbody id="responseData">
                                        <?php
                                    $get = mysqli_query($conn,"SELECT * FROM scorecard WHERE areaId = '$areaId'");

	
                                    while($row = mysqli_fetch_array($get)){
                                        ?>
                                        <tr id="row_<?php echo $row['areaId'] ?>">

                                            <td><?php echo $row['MGDSGoal'] ?></td>
                                            <td><?php echo $row['LinkedSDGGoalandTargets'] ?></td>
                                            <td><?php echo $row['SDGIndicator'] ?></td>
                                            <td><?php echo $row['RelatedMGDSKeyperformanceIndicator'] ?></td>
                                            <td><?php echo $row['MeansofVerificationandResponsibleSector'] ?></td>

                                            <?php 
                                            $theID = $row['id'];
                                            $years = mysqli_query($conn,"SELECT * FROM scoreyear WHERE scorecard_id='$theID'");
                                            
                                            while ($res = mysqli_fetch_array($years)){
                                                $target = $res['target'];
                                                $score = $res['score'];
        
                                                $percent = ($score/100)*$target;
                                                ?>
                                                <td style=" background-color:<?php
                                                //bg color based on %
                                                if($percent==0) echo "#333";
                                                else if($percent>=0 && $percent<=25) echo "#c00000";
                                                else if($percent>25 && $percent<=50) echo "#ffff00";
                                                else if($percent>50 && $percent<=75) echo "#92d050";
                                                else if($percent>75) echo "#00b050";
                                                ?>">
                                                <?php echo $score; ?>
                                                </td>
                                                <?php
                                                
                                                
                                            }
                                            if(!$years){
                                                echo "<td></td>";
                                            }
                                        ?>


                                        </tr>
                                        <?php
                                    }
                                    
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <?php
        }
        
        ?>


    </div>
    <!-- Row -->



</div>
<script>
function updatePriority() {
    var id = $("#PriorityArea").val();

    window.location.href = "?area=" + id;
}
</script>