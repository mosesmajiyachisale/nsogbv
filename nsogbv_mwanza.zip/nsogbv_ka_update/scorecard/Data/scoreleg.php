<html>
<head>
<!--<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.4.4/jquery.js"></script> -->
<script type="text/javascript">

$(document).ready(function(){
    $('#table_id td.y_n').each(function(){
        if ($(this).text() == 'G') {
            $(this).css('background-color','#008000');
        }
		if ($(this).text() == 'LG') {
            $(this).css('background-color','#6aa84f');
        }
		
		if ($(this).text() == 'Y') {
            $(this).css('background-color','#FFFF00');
        }
		
		if ($(this).text() == 'R') {
            $(this).css('background-color','#FF0000');
        }
		
		if ($(this).text() == 'B') {
            $(this).css('background-color','#000000');
        }
    });
});

</script>

</head>
<body>

<table id="table_id">
 <tr><th>Progress</th><th>Color</th></tr>
 
 <tr><td>Already met</td><td class="y_n">G</td> </tr>
 <tr><td>Likely to be met </td><td class="y_n">LG</td> </tr>
 <tr><td>Moderate Progress</td><td class="y_n">Y</td> </tr>
 <tr><td>Insufficient progress</td><td class="y_n">R</td> </tr>
 <tr><td>No data available)</td><td class="y_n">B</td> </tr>
</table> 

</body>
</html>