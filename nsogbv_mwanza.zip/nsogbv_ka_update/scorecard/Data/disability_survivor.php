

	 



<!----end--->

  
     <div id="chartu"></div>

    <script>
      
        var options = {
          series: [{name:'Cases',
          data: [
		  <?php
$query  = "SELECT * from 
(SELECT (CASE WHEN a7_1 = 1 THEN 'Blindeness'  END) disability, sum(a7_1) total FROM sgbv.gbv_cases2 where a7_1 = 1
union
SELECT (CASE WHEN a7_2 = 1 THEN 'Hearing'  END) disability, sum(a7_2) total FROM sgbv.gbv_cases2 where a7_2 = 1
union
SELECT (CASE WHEN a7_3 = 1 THEN 'Walking'  END) disability,  sum(a7_3) total FROM sgbv.gbv_cases2 where a7_3 = 1
union
SELECT (CASE WHEN  a7_4= 1 THEN 'Speaking'  END) disability, sum(a7_4) total FROM sgbv.gbv_cases2 where a7_4 = 1
union
SELECT (CASE WHEN  a7_5= 1 THEN 'Intellectual'  END) disability, sum(a7_5) total FROM sgbv.gbv_cases2 where a7_5 = 1
union
SELECT (CASE WHEN  a7_7 = 1 THEN 'Albinism'  END) disability, sum(a7_7) total FROM sgbv.gbv_cases2 where a7_7 = 1
union
SELECT (CASE WHEN  a7_8= 1 THEN 'Epilepsy'  END) disability, sum(a7_4) total FROM sgbv.gbv_cases2 where a7_8 = 1
)as temp1 where disability is not null ";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"$total,"; 
}

?>  
		  
		  ]
        }],
          chart: {
          type: 'bar',
          height: 350,

        },
        plotOptions: {
          bar: {
            horizontal: false,
          }
        },
        dataLabels: {
          enabled: true,
        },
        xaxis: {
          categories: [
		  
				
			<?php
$query  = "SELECT * from 
(SELECT (CASE WHEN a7_1 = 1 THEN 'Blindeness'  END) disability, sum(a7_1) total FROM sgbv.gbv_cases2 where a7_1 = 1
union
SELECT (CASE WHEN a7_2 = 1 THEN 'Hearing'  END) disability, sum(a7_2) total FROM sgbv.gbv_cases2 where a7_2 = 1
union
SELECT (CASE WHEN a7_3 = 1 THEN 'Walking'  END) disability,  sum(a7_3) total FROM sgbv.gbv_cases2 where a7_3 = 1
union
SELECT (CASE WHEN  a7_4= 1 THEN 'Speaking'  END) disability, sum(a7_4) total FROM sgbv.gbv_cases2 where a7_4 = 1
union
SELECT (CASE WHEN  a7_5= 1 THEN 'Intellectual'  END) disability, sum(a7_5) total FROM sgbv.gbv_cases2 where a7_5 = 1
union
SELECT (CASE WHEN  a7_7= 1 THEN 'Albinism'  END) disability, sum(a7_7) total FROM sgbv.gbv_cases2 where a7_7 = 1
union
SELECT (CASE WHEN  a7_8= 1 THEN 'Epilepsy'  END) disability, sum(a7_8) total FROM sgbv.gbv_cases2 where a7_8 = 1
)as temp1 where disability is not null ";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"'$disability',"; 
}

?>  
			
			
          ],
        }
        };

        var chart = new ApexCharts(document.querySelector("#chartu"), options);
        chart.render();
      
      
    </script>


    
  </body>
</html>