<html>
<head>
<!--<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.4.4/jquery.js"></script> -->
<script type="text/javascript">

$(document).ready(function(){
    $('#table_id td.y_n').each(function(){
        if ($(this).text() == 'Y') {
            $(this).css('background-color','#f00');
        }
		if ($(this).text() == 'N') {
            $(this).css('background-color','#200cff');
        }
    });
});

</script>

</head>
<body>

<!--<table id="table_id">
 <tr><th>Sector</th><th>Indicator</th><th>Year</th></tr>
 
 <tr><td>I am me.</td><td class="y_n">Y</td> <td class="y_n">N</td> </tr>
 <tr><td>I am him.</td><td class="y_n">N</td> <td class="y_n">N</td></tr>
 <tr><td>I am not sure.</td><td class="y_n">Y</td> <td class="y_n">N</td></tr>
 <tr><td>This is a table.</td><td class="y_n">Y</td> <td class="y_n">Y</td></tr>
</table>-->
<table>
    <tr>
        <td>Priority Area</td>
        <td>Malawi Growth and Development Strategy (MGDS) Goal</td>
        <td>Linked SDG Goal and targets</td>
        <td>SDG Indicator</td>
        <td>Related MGDS Key performance  Indicator</td>
        <td>Means of Verification and Responsible Sector</td>
        <td>Baseline: 2019</td>
        <td>Progress: 2020</td>
        <td>Progress: 2021</td>
        <td>Progress: 2022</td>
        <td>Progress: 2023</td>
        <td>Progress: 2024</td>
        <td>Progress: 2025</td>
        <td>Progress: 2026</td>
        <td>Progress: 2027</td>
        <td>Progress: 2028</td>
        <td>Progress: 2029</td>
        <td>Progress: 2030</td>
    </tr>
    <tr>
        <td>Agriculture and access to land</td>
        <td>MGDS Goal 1: To achieve sustainable agricultural transformation that is adaptive to climate change</td>
        <td>"SDG Goal 2.</td>
        <td>End hunger, achieve food security and improved nutrition and promote sustainable agriculture"</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td>MGDS Expected Outcome: Increased agricultural production and productivity</td>
        <td>SDG Target: 2.3 -By 2030, double the agricultural productivity and incomes of small-scale food producers, in particular women, indigenous peoples, family farmers, pastoralists and fishers, including through secure and equal access to land, other productive resources and inputs, knowledge, financial services, markets and opportunities for value addition and non-farm employment</td>
        <td>Indicator 2.3.2 Average income of small-scale food producers, by sex and indigenous status (by residence - rural and urban)</td>
        <td>Proportion of farm households (disaggregated by age and sex) using recommended agricultural technologies </td>
        <td>Ministry of Agriculture Reports</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td>SDG Target 5.a Undertake reforms to give women equal rights to economic resources, as well as access to ownership and control over land and other forms of property, financial services, inheritance and natural resources, in accordance with national laws    </td>
        <td>5.a.1  (a) Proportion of total agricultural population with ownership or secure rights over agricultural land, by sex; and (b) share of women among owners or rights-bearers of agricultural land, by type of tenure     </td>
        <td></td>
        <td>Min of Lands Reports (To check with ministry of lands if there is info on this--move the highlighted roll to lands)</td>
        <td>1</td>
        <td>2</td>
        <td>3</td>
        <td>5</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td>11.7 By 2030, provide universal access to safe, inclusive and accessible, green and public spaces, in particular for women and children, older persons and persons with disabilities </td>
        <td>11.7.1.Average share of build up area of cities that is open space for public use for all, by sex, age and persons with disabilities] </td>
        <td></td>
        <td>Min of Lands Reports </td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td>Nutrition</td>
        <td>MGDS Expected Outcome: Improved nutrition and food security</td>
        <td>"SDG Target 2.1 -By 2030, end hunger and ensure access by all people, in particular the poor and people in vulnerable situations, including infants, to safe, nutritious and sufficient food all year round</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td>"</td>
        <td>Indicator 2.1.1 Prevalence of undernourishment disaggregated by sex and age                                                  </td>
        <td>Percentage of food insecure households (Disaggregated by sex and age)</td>
        <td>WHO and Ministry of Health reports [ to check -collecting information - Min of health? we can use that--see if they capture sex]</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td>Indicator 2.1.2 Prevalence of moderate or severe food insecurity in the population, based on the Food Insecurity Experience Scale (FIES) disaggregated by sex and age</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td>SDG Target 2.2 -By 2030, end all forms of malnutrition, including achieving, by 2025, the internationally agreed targets on stunting and wasting in children under 5 years of age, and address the nutritional needs of adolescent girls, pregnant and lactating women and older persons</td>
        <td>Indicator 2.2.1 Prevalence of stunting (height for age &lt;-2 standard deviation from the median of the World Health Organization (WHO) Child Growth Standards) among children under 5 years of age by sex.                                                                   </td>
        <td>Percentage of population with food consumption below minimum dietary requirement - prevalence of undernourishment by sex and age</td>
        <td>WHO reports and UNICEF reports, GoM MGDS review </td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td>Indicator 2.2.2 Prevalence of malnutrition (weight for height &gt;+2 or &lt;-2 standard deviation from the median of the WHO Child Growth Standards) among children under 5 years of age, by type (wasting and overweight) by sex</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td>Climate Change and resilience</td>
        <td>MGDS Expected Outcome: Enhanced community resilience to climate change impacts</td>
        <td>Goal 13 -Take urgent action to combat climate change and its impacts</td>
        <td></td>
        <td></td>
        <td>Ministry of Disaster Relief and Public Events Reports</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td>"SDG Target 13.b</td>
        <td> Promote mechanisms for raising capacity for effective climate change-related planning and management..., including focusing on women, youth and local and marginalized communities"</td>
        <td>Indicator 13.b.1 ...Amount of support, including finance, technology and capacity-building, for mechanisms for raising capacities for effective climate change-related planning and management, including focusing on women, youth and local and marginalized communities</td>
        <td>Percentage of vulnerable population experiencing the impacts of droughts and floods by sex, age and disability</td>
        <td>[Check with RSG on means of verification]</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td>Acess to water</td>
        <td>MGDS Expected Outcome: Increased access to water resources</td>
        <td>Goal 6. Ensure availability and sustainable management of water and sanitation for all</td>
        <td>"6.1.1  Proportion of population using safely managed drinking water services </td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td>by sex, age and disability"</td>
        <td>Proportion of population (households) using safely managed water by sex, age and disability</td>
        <td>Ministry of Irrigation and Water Development reports [Check with this ministry if it can disaggregate by sex- eg female headed households</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td>MGDS Expected outcome: Enhanced integrated water resources management at all levels</td>
        <td>"SDG Target 6.1</td>
        <td>By 2030, achieve universal and equitable access to safe and affordable drinking water for all</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td>"</td>
        <td>6.2.1  Proportion of population using safely managed sanitation services, including a hand-washing facility with soap and water disaggregated by sex, age and disability                           </td>
        <td>Households with portable water within 500 meters/ 30 minute walk disaggregated by sex, age and disability</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td>6.3.1  Proportion of wastewater safely treated</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td>"SDG Target 6.2</td>
        <td>By 2030, achieve access to adequate and equitable sanitation and hygiene for all and end open defecation, paying special attention to the needs of women and girls and those in vulnerable situations"</td>
        <td>6.3.2  Proportion of bodies of water with good ambient water quality  </td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td>6.b.1  Proportion of local administrative units with established and operational policies and procedures for participation of local communities in water and sanitation management </td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td>Education</td>
        <td>MGDS Goal 2: Improve Quality and relevant education and skills for all</td>
        <td>Goal 4. Ensure inclusive and equitable quality education and promote lifelong learning opportunities for all</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td>MGDS Expected outcome: Improved access and equity to basic education</td>
        <td>"SDG Target 4.1: By 2030, ensure that all girls and boys complete free, equitable and quality primary and secondary education leading to relevant and effective learning outcomes </td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td>"</td>
        <td>4.1.1  Proportion of children and young people: (a) in grades 2/3; (b) at the end of primary; and (c) at the end of lower secondary achieving at least a minimum proficiency level in (i) reading and (ii) mathematics, by sex</td>
        <td>Equitable access to Education at all levels. Gender parity index in primary school - disaggregated by sex, age and disability</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td>MGDS Expected outcome: Increased access to secondary education for both boys and girls and those with special needs</td>
        <td>SDG Target 4.2: By 2030, ensure that all girls and boys have access to quality early childhood development, care and  pre-primary education so that they are ready for primary education</td>
        <td>4.2.1  Proportion of children under 5 years of age who are developmentally on track in health, learning and psychosocial well-being, by sex                                             </td>
        <td>Gender parity index for secondary    percentatge of special needs education students in secondary schools by sex</td>
        <td>EP &amp; D Reports, ECD reports [Check with Epn D if there is gender parity index -also check with Early Childhood Development with Min of Gender if there is means of verification]</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td>4.2.2  Participation rate in organized learning (one year before the official primary entry age), by sex </td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td>MGDS Expected outcome: Improved access and equity to higher  education</td>
        <td>4.3 By 2030, ensure equal access for all women and men to affordable and quality technical, vocational and tertiary education, including university</td>
        <td>4.3.1  Participation rate of youth and adults in formal and non-formal education and training in the previous 12 months, by sex </td>
        <td>University Enrollment capacity                   Gender parity index - Teacher training enrolment</td>
        <td>IHS [Check IHS -integrated household survey)which gives poverty rate reports - check with ministry of Education on means of verification]</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td>Employment</td>
        <td>Improved quality of labour force</td>
        <td>Goal 8. Promote sustained, inclusive and sustainable economic growth, full and productive employment and decent work for all </td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td>8.3 Promote development-oriented policies that support productive activities, decent job creation, entrepreneurship, creativity and innovation, and encourage the formalization and growth of micro-, small- and medium-sized enterprises, including through access to financial services </td>
        <td>8.3.1  Proportion of informal employment in non-agriculture employment, by sex </td>
        <td>Unemployment rate- percentage by sex and age </td>
        <td>ILO reports, [to check if data is by age and sex]</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td>8.5 By 2030, achieve full and productive employment and decent work for all women and men, including for young people and persons with disabilities, and equal pay for work of equal value </td>
        <td>8.5.2  Unemployment rate, by sex, age and persons with disabilities</td>
        <td>Unemployment rate- percentage by sex, age and diasbility</td>
        <td>ILO reports [to check data availability]</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td>8.5.1  Average hourly earnings of female and male employees, by occupation, age and persons with disabilities   </td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td>8.6 By 2020, substantially reduce the proportion of youth not in employment, education or trainin</td>
        <td>8.6.1  Proportion of youth (aged 15-24 years) not in education, employment or training disaggregated by sex, age and disability [Related SI outcome indicator 4.1.1 on access to education on integration of HP, SGBV and SRHR]</td>
        <td>proportion of youth not in employment </td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td>8.7 Take immediate and effective measures to eradicate forced labour, end modern slavery and human trafficking and secure the prohibition and elimination of the worst forms of child labour, including recruitment and use of child soldiers, and by 2025 end child labour in all its forms  </td>
        <td>8.7.1  Proportion and number of children aged 5-17 years engaged in child labour, by sex and age</td>
        <td>proportion and number of children aged 5-17 in child labour disaggregated by sex, age and disability</td>
        <td>ILO reports</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td>SDG Target 8.8  Protect labour rights and promote safe and secure working environments for all workers, including migrant workers, in particular women migrants, and those in precarious employment </td>
        <td>8.8.1  Frequency rates of fatal and non-fatal occupational injuries, by sex and migrant status                                                              </td>
        <td></td>
        <td>Private sector, Parliament, ILO [women caucus can also oversee this [also check with ILO if we can measure 8.8.1 and 8.8.2 or one of them</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td>8.8.2  Increase in national compliance of labour rights (freedom of association and collective bargaining) based on International Labour Organization (ILO) textual sources and national legislation, by sex and migrant status</td>
        <td></td>
        <td>ILO reports</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td>Health</td>
        <td>MGDS Goal 5: To improve health and quality of the population for sustainable socio-economic development</td>
        <td>SDG Goal 3. Ensure healthy lives and promote well-being for all at all ages </td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td>MGDS Expected Outcome: Reduced incidence and prevalence of diseases</td>
        <td>SDG Target 3.1 By 2030, reduce the global maternal mortality ratio to less than 70 per 100,000 live births</td>
        <td>3.3.1 Maternal mortality ratio                  </td>
        <td> Maternal mortality ratio/100,000 live births</td>
        <td>Malawi Demographic and Health Survey (MDHS) </td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td>3.1.2 Proportion of births attended by skilled health personnel</td>
        <td></td>
        <td>MDHS</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td>SDG Target 3.2 By 2030, end preventable deaths of newborns and children under 5 years of age, with all countries aiming to reduce neonatal mortality to at least as low as 12 per 1,000 live births and under-5 mortality to at least as low as 25 per 1,000 live births </td>
        <td>3.2.1 Under-five mortality rate                       </td>
        <td>Under-5 mortality rate (U5MR)/1000 live births  Neonatal mortality rate/1000 live births </td>
        <td>MDHS</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td>3.2.2 Neonatal mortality rate </td>
        <td></td>
        <td>MDHS</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td>Improved welfare and health status for persons with disability and the elderly</td>
        <td>SDG Target 3.3 By 2030, end the epidemics of AIDS, tuberculosis, malaria and neglected tropical diseases and combat hepatitis, water-borne diseases and other communicable disease</td>
        <td>3.3.1 Number of new HIV infections per 1,000 uninfected population, by sex, age and key populations </td>
        <td>HIV and AIDS Incidence Rate                   -Proportion of Women, Elderly and persons with diasbilities living below 1.25USD per person/day</td>
        <td>Min of Health reports [Check with Ministry of Health on means of verification]</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td>MGDS Expected Outcome: Effective population and development planning at all levels</td>
        <td>SDG Target 3.7 By 2030, ensure universal access to sexual and reproductive health-care services, including for family planning, information and education, and the integration of reproductive health into national strategies and programmes </td>
        <td>3.7.1 Proportion of women of reproductive age (aged 15-49 years) who have their need for family planning satisfied with modern methods [Related SI outcome indicator 6.1.1]</td>
        <td>Proportion of women of reproductive (aged 15 - 49 years) who have their need for family planning satisfied with modern methods</td>
        <td>UNFPA, Min of Health reports [Check with UNFPA on means of verification and Ministry fo Health if data on these indicators is collected]</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td>3.7.2 Adolescent birth rate (aged 10-14 years; aged 15-19 years) per 1,000 women in that age group </td>
        <td>adolescent birthrate (aged 15-49 years) per 1000 women</td>
        <td>Min of Health Reports [Check min of health if that data is vailable]</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td>proportion of women aged 1- -49 years who make their own informed decisions regarding sexual relations, contraceptive use and reproductive care</td>
        <td>DHS [Check DHS if this data is available in DHS report]</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td>modern contraceptive prevalence rate</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td>married women #</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td>unmarried women #</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td>Gender Equality</td>
        <td>MGDS Goal 6.3: Gender, social welfare, and youth development goal: to build an equitable society where opportunity is defined by sex, age, disability and other vulnerabilities</td>
        <td>Goal 5. Achieve gender equality and empower all women and girls  </td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td>MGDS Expected Outcome: Increased women and youth representation in decision making structures and politics</td>
        <td>SDG Target 5.5 Ensure women’s full and effective participation and equal opportunities for leadership at all levels of decision-making in political, economic and public life</td>
        <td>5.5.1  Proportion of seats held by women in national parliaments and local governments [Related SI Outcome indicator 1.1.2 on strengthened capacity] </td>
        <td>Percentage of youth participating in leadership activities by sex</td>
        <td> Parliament Reports, Min of Gender Reports [To verify]</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td>5.5.2  Proportion of women in managerial positions </td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td>Equitable access to social services among persons with disabilities</td>
        <td>SDG Target 11.2 By 2030, provide access to safe, affordable, accessible and sustainable transport systems for all, improving road safety, notably by expanding public transport, with special attention to the needs of those in vulnerable situations, women, children, persons with disabilities and older persons </td>
        <td>11.2.1 Proportion of population that has convenient access to public transport, by sex, age and persons with disabilities</td>
        <td>Proportion of students with disabilities attending school</td>
        <td>IHS and DHS reports [Cross check]</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td>Non-discrimination</td>
        <td></td>
        <td>SDG Target 5.1 End all forms of discrimination against all women and girls everywhere </td>
        <td>5.1.1  Whether or not legal frameworks are in place to promote, enforce and monitor equality and non-discrimination on the basis of sex [SI Outcome Indicator 2.1.2)</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td>Elimination of VAWG SGBV HP</td>
        <td></td>
        <td>SDG Target 5.2 Eliminate all forms of violence against all women and girls in the public and private spheres, including trafficking and sexual and other types of exploitation</td>
        <td>5.2.1  Proportion of ever-partnered women and girls aged 15 years and older subjected to physical, sexual or psychological violence by a current or former intimate partner in the previous 12 months, by form of violence and by age                                                         [same SI Indicator]                                                    </td>
        <td></td>
        <td>UNFPA Reports [Cross check]</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td>5.2.2  Proportion of women and girls aged 15 years and older subjected to sexual violence by persons other than an intimate partner in the previous 12 months, by age and place of occurrence                                [same SI Indicator]</td>
        <td></td>
        <td>UNFPA Reports [Cross check]</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td>SDG Target 5.3 Eliminate all harmful practices, such as child, early and forced marriage and female genital mutilation [sexual initiation and death cleansing]</td>
        <td> 5.3.2  Proportion of girls and women aged 15-49 years who have undergone harmful practice by age and sex eg sexual initiation and death cleansing                                        [same SI Indicator]      </td>
        <td></td>
        <td>NSO, SI reports, UNICEF [cross check]</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td>5.3.1  Proportion of women aged 20-24 years who were married or in a union before age 15 and before age 18                 [same SI Indicator] </td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td>11.7.2 Proportion of persons victim of physical or sexual harassment, by sex, age, disability status and place of occurrence, in the previous 12 months [Related SI Indicator 4.2.a]</td>
        <td></td>
        <td>DHS</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
    </tr>
</table>
</body>
</html>