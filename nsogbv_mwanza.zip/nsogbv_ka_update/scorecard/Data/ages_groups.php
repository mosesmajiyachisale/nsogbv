<!DOCTYPE html>

	 
<html lang="en">
  <head>
<style> 
#chartage {
}

#chartage div {
  margin:auto;
} 
</style>
  </head>

  <body>
     <div id="chartage"></div>

    <script>
      
        var options = {
          series: [
		  
		  <?php
				$query  = "select case when years<16 then '0-15'
				when years between 16 and 24 then '16-24'
				when years between 25 and 34 then '25-34'
				when years between 35 and 49 then '35-49'
				when years>49 then '49+'
				else 'Unkhown'
				end as category, count(*) total from
				(SELECT floor(DATEDIFF(CURDATE(), str_to_date(concat(a3_day,'/',a3_month,'/',a3_year),'%d/%m/%Y'))/365) years from gbv_cases2)
				as agegroups group by category";



				$results = mysqli_query($link, $query);
				$nrows = mysqli_num_rows($results);
				$row = mysqli_num_rows($results);

				for ($i=0;$i<$nrows;$i++)

				{
				$n = $i + 1;
				$row = mysqli_fetch_array($results);
				extract($row);
				echo"$total,"; 
				}

?>  	  
		  ],
          chart: {
          width: 320,
          type: 'donut',
        },
		legend: {
              position: 'bottom',display: false,
            },
        labels: [
		
		
		
		<?php
			$query  = "select case when years<16 then '0-15'
			when years between 16 and 24 then '16-24'
			when years between 25 and 34 then '25-34'
			when years between 35 and 49 then '35-49'
			when years>49 then '49+'
			else 'Unkhown'
			end as category, count(*) total from
			(SELECT floor(DATEDIFF(CURDATE(), str_to_date(concat(a3_day,'/',a3_month,'/',a3_year),'%d/%m/%Y'))/365) years from gbv_cases2)
			as agegroups group by category";

			$results = mysqli_query($link, $query);
			$nrows = mysqli_num_rows($results);
			$row = mysqli_num_rows($results);

			for ($i=0;$i<$nrows;$i++)

			{
			$n = $i + 1;
			$row = mysqli_fetch_array($results);
			extract($row);



			echo"'$category',"; 
			}

			?>
		
		],
        dataLabels: {
          formatter(val, opts) {
            const name = opts.w.globals.labels[opts.seriesIndex]
            return [name, val.toFixed(1) + '%']
          }
        },
        legend: {
          show: false
        },
        plotOptions: {
          pie: {
            dataLabels: {
              offset: -0
            }
          }
		}
        };

        var chart = new ApexCharts(document.querySelector("#chartage"), options);
        chart.render();
      
      
    </script>

    
  </body>
</html>