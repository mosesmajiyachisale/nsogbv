<!DOCTYPE html>
	<script src="../dist/apexcharts/dist/apexcharts.js"></script>
<html lang="en">
  <head>

 
 

  </head>


  <body>
     <div id="chart3Nyyyy2"></div>

    <script>
      
        var options = {
          series: [{
          name: 'Machinga',
          data: [
		  		  <?php
$query  = "SELECT A4_DISTRICT, A5_T_A village, 
sum(CASE WHEN A4_DISTRICT = 'Mzimba' THEN 1  END) Mzimba,
sum(CASE WHEN A4_DISTRICT = 'Machinga' THEN 1  END) Machinga,
sum(CASE WHEN A4_DISTRICT = 'Ntchisi' THEN 1  END) Ntchisi,
sum(CASE WHEN A4_DISTRICT = 'Dowa' THEN 1  END) Dowa,
sum(CASE WHEN A4_DISTRICT = 'Nkhatabay' THEN 1  END) Nkhatabay,
sum(CASE WHEN A4_DISTRICT = 'Nsanje' THEN 1  END) Nsanje
FROM sgbv.searcher 
  group by A4_DISTRICT, A5_T_A";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"\"$Machinga\","; 
}

?> 
		  
		  
		  
		  ]
        }, {
          name: 'Mzimba',
          data: [
		  
		  <?php
$query  = "SELECT A4_DISTRICT, A5_T_A village, 
sum(CASE WHEN A4_DISTRICT = 'Mzimba' THEN 1  END) Mzimba,
sum(CASE WHEN A4_DISTRICT = 'Machinga' THEN 1  END) Machinga,
sum(CASE WHEN A4_DISTRICT = 'Ntchisi' THEN 1  END) Ntchisi,
sum(CASE WHEN A4_DISTRICT = 'Dowa' THEN 1  END) Dowa,
sum(CASE WHEN A4_DISTRICT = 'Nkhatabay' THEN 1  END) Nkhatabay,
sum(CASE WHEN A4_DISTRICT = 'Nsanje' THEN 1  END) Nsanje
FROM sgbv.searcher 
  group by A4_DISTRICT, A5_T_A";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"\"$Mzimba\","; 
}

?> 
		  
		  ]
        }, {
          name: 'Ntchisi',
          data: [
		  
		  <?php
$query  = "SELECT A4_DISTRICT, A5_T_A village, 
sum(CASE WHEN A4_DISTRICT = 'Mzimba' THEN 1  END) Mzimba,
sum(CASE WHEN A4_DISTRICT = 'Machinga' THEN 1  END) Machinga,
sum(CASE WHEN A4_DISTRICT = 'Ntchisi' THEN 1  END) Ntchisi,
sum(CASE WHEN A4_DISTRICT = 'Dowa' THEN 1  END) Dowa,
sum(CASE WHEN A4_DISTRICT = 'Nkhatabay' THEN 1  END) Nkhatabay,
sum(CASE WHEN A4_DISTRICT = 'Nsanje' THEN 1  END) Nsanje
FROM sgbv.searcher 
  group by A4_DISTRICT, A5_T_A";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"\"$Ntchisi\","; 
}

?> 
		  
		  ]
        }, {
          name: 'Dowa',
          data: [
		  
		  <?php
$query  = "SELECT A4_DISTRICT, A5_T_A village, 
sum(CASE WHEN A4_DISTRICT = 'Mzimba' THEN 1  END) Mzimba,
sum(CASE WHEN A4_DISTRICT = 'Machinga' THEN 1  END) Machinga,
sum(CASE WHEN A4_DISTRICT = 'Ntchisi' THEN 1  END) Ntchisi,
sum(CASE WHEN A4_DISTRICT = 'Dowa' THEN 1  END) Dowa,
sum(CASE WHEN A4_DISTRICT = 'Nkhatabay' THEN 1  END) Nkhatabay,
sum(CASE WHEN A4_DISTRICT = 'Nsanje' THEN 1  END) Nsanje
FROM sgbv.searcher 
  group by A4_DISTRICT, A5_T_A";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"\"$Dowa\","; 
}

?> 
		  
		  ]
        },
{
          name: 'Nkhatabay',
          data: [
		  
		  <?php
$query  = "SELECT A4_DISTRICT, A5_T_A village, 
sum(CASE WHEN A4_DISTRICT = 'Mzimba' THEN 1  END) Mzimba,
sum(CASE WHEN A4_DISTRICT = 'Machinga' THEN 1  END) Machinga,
sum(CASE WHEN A4_DISTRICT = 'Ntchisi' THEN 1  END) Ntchisi,
sum(CASE WHEN A4_DISTRICT = 'Dowa' THEN 1  END) Dowa,
sum(CASE WHEN A4_DISTRICT = 'Nkhatabay' THEN 1  END) Nkhatabay,
sum(CASE WHEN A4_DISTRICT = 'Nsanje' THEN 1  END) Nsanje
FROM sgbv.searcher 
  group by A4_DISTRICT, A5_T_A";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"\"$Nkhatabay\","; 
}

?> 
		  
		  ]
        },{
          name: 'Nsanje',
          data: [
		  
		  <?php
$query  = "SELECT A4_DISTRICT, A5_T_A village, 
sum(CASE WHEN A4_DISTRICT = 'Mzimba' THEN 1  END) Mzimba,
sum(CASE WHEN A4_DISTRICT = 'Machinga' THEN 1  END) Machinga,
sum(CASE WHEN A4_DISTRICT = 'Ntchisi' THEN 1  END) Ntchisi,
sum(CASE WHEN A4_DISTRICT = 'Dowa' THEN 1  END) Dowa,
sum(CASE WHEN A4_DISTRICT = 'Nkhatabay' THEN 1  END) Nkhatabay,
sum(CASE WHEN A4_DISTRICT = 'Nsanje' THEN 1  END) Nsanje
FROM sgbv.searcher 
  group by A4_DISTRICT, A5_T_A";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"\"$Nsanje\","; 
}

?> 
		  
		  ]
        },		
		

		
		],
          chart: {
          type: 'bar',
          height: 350
        },
        plotOptions: {
          bar: {
            horizontal: false,
            columnWidth: '55%',
         //   endingShape: 'rounded'
          },
        },
        dataLabels: {
          enabled: true
        },
        stroke: {
          show: true,
          width: -6,
          colors: ['transparent']
        },
        xaxis: {
          categories: [
		  
		  		  <?php
$query  = "SELECT A4_DISTRICT, A5_T_A village, 
sum(CASE WHEN A4_DISTRICT = 'Mzimba' THEN 1  END) Mzimba,
sum(CASE WHEN A4_DISTRICT = 'Machinga' THEN 1  END) Machinga,
sum(CASE WHEN A4_DISTRICT = 'Ntchisi' THEN 1  END) Ntchisi,
sum(CASE WHEN A4_DISTRICT = 'Dowa' THEN 1  END) Dowa,
sum(CASE WHEN A4_DISTRICT = 'Nkhatabay' THEN 1  END) Nkhatabay,
sum(CASE WHEN A4_DISTRICT = 'Nsanje' THEN 1  END) Nsanje
FROM sgbv.searcher 
  group by A4_DISTRICT, A5_T_A";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"\"$village\","; 
}

?> 
		  
		  ],
        },
        yaxis: {
          title: {
            text: '# of cases'
          }
        },
		
        fill: {
          opacity: 1
        },
        tooltip: {
          y: {
            formatter: function (val) {
             // return "$ " + val + " thousands"
			   return val 
            }
          }
        }
        };

        var chart = new ApexCharts(document.querySelector("#chart3Nyyyy2"), options);
        chart.render();
      
      
    </script>

    
  </body>
</html>
