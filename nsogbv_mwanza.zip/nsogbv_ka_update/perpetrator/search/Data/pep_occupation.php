
     <div id="chartab_pep"></div>

    <script>
      
        var options = {
          series: [{name:'cases',
          data: [
		  
		
		  
		  
		  <?php
$query  = "SELECT  case 
when d10 = 1 then 'Formal Employment' 
when d10 = 2 then 'Business' 
when d10 = 3 then 'Farmer' 
when d10 = 4 then 'Casual Labour' 
when d10 = 5 then 'Student'
else 'Unknown'
end occupation, count(*) total FROM sgbv.searcher group by d10 ";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"$total,"; 
}

?>  
		  
		  ]
        }],
          chart: {
          type: 'bar',
          height: 250
        },
        plotOptions: {
          bar: {
            horizontal: true,
          }
        },
        dataLabels: {
          enabled: false
        },
        xaxis: {
          categories: [
		  
		  
		 
			
			
			
			<?php
$query  = "SELECT  case 
when d10 = 1 then 'Formal Employment' 
when d10 = 2 then 'Business' 
when d10 = 3 then 'Farmer' 
when d10 = 4 then 'Casual Labour' 
when d10 = 5 then 'Student'
else 'Unknown'
end occupation, count(*) total FROM sgbv.searcher group by d10 ";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"'$occupation',"; 
}

?>  
			
			
          ],
        },
        responsive: [{
          breakpoint: 1600,
          options: {
            chart: {
              height: 197
            },
            legend: {
              position: 'bottom'
            }
          }
        }],
        };

        var chart = new ApexCharts(document.querySelector("#chartab_pep"), options);
        chart.render();
      
      
    </script>


    
  </body>
</html>



