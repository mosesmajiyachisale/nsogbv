
  <body>
     <div id="chart3"></div>

    <script>
      
        var options = {
          series: [{
          name: 'Male',
          data: [
		  		  <?php
$query  = "SELECT A4_DISTRICT, sum(CASE WHEN A2_SEX = 1 THEN 1  END) male, sum(CASE WHEN A2_SEX = 2 THEN 1  END) Female  FROM sgbv.searcher
group by A4_DISTRICT";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"'$male',"; 
}

?> 
		  
		  
		  
		  ]
        }, {
          name: 'Female',
          data: [
		  
		  <?php
$query  = "SELECT A4_DISTRICT, sum(CASE WHEN A2_SEX = 1 THEN 1  END) male, sum(CASE WHEN A2_SEX = 2 THEN 1  END) Female  FROM sgbv.searcher
group by A4_DISTRICT";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"'$Female',"; 
}

?> 
		  
		  ]
        }, /* {
          name: 'Free Cash Flow',
          data: [35, 41, 36, 26, 45, 48, 52, 53, 41]
        } */],
          chart: {
          type: 'bar',
          height: 350
        },
        plotOptions: {
          bar: {
            horizontal: false,
            columnWidth: '55%',
            endingShape: 'rounded'
          },
        },
        dataLabels: {
          enabled: false
        },
        stroke: {
          show: true,
          width: 2,
          colors: ['transparent']
        },
        xaxis: {
          categories: [
		  
		  		  <?php
$query  = "SELECT A4_DISTRICT district, sum(CASE WHEN A2_SEX = 1 THEN 1  END) male, sum(CASE WHEN A2_SEX = 2 THEN 1  END) Female  FROM sgbv.searcher
group by A4_DISTRICT";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"'$district',"; 
}

?> 
		  
		  ],
        },
        yaxis: {
          title: {
            text: 'Number of cases'
          }
        },
        fill: {
          opacity: 1
        },
        tooltip: {
          y: {
            formatter: function (val) {
             // return "$ " + val + " thousands"
			   return val 
            }
          }
        }
        };

        var chart = new ApexCharts(document.querySelector("#chart3"), options);
        chart.render();
      
      
    </script>

    
  </body>
</html>
