
     <div id="chartpu"></div>

    <script>
      
        var options = {
          series: [{name:'cases',
          data: [
		  <?php
$query  = "SELECT * from 
(SELECT (CASE WHEN d7_1 = 1 THEN 'Blindeness'  END) disability, sum(d7_2) total FROM sgbv.searcher  where d7_1 = 1
union
SELECT (CASE WHEN d7_2 = 1 THEN 'Hearing'  END) disability, sum(d7_2) total FROM sgbv.searcher  where d7_2 = 1
union
SELECT (CASE WHEN d7_3 = 1 THEN 'Walking'  END) disability,  sum(d7_3) total FROM sgbv.searcher  where d7_3 = 1
union
SELECT (CASE WHEN  d7_4= 1 THEN 'Speaking'  END) disability, sum(d7_4) total FROM sgbv.searcher  where d7_4 = 1
union
SELECT (CASE WHEN  d7_5= 1 THEN 'Intellectual'  END) disability, sum(d7_5) total FROM sgbv.searcher  where d7_5 = 1
union
SELECT (CASE WHEN  d7_6= 1 THEN 'Self Care'  END) disability, sum(d7_6) total FROM sgbv.searcher  where d7_6 = 1
union
SELECT (CASE WHEN  d7_7= 1 THEN 'Albinism'  END) disability, sum(d7_7) total FROM sgbv.searcher  where d7_7 = 1
union
SELECT (CASE WHEN  d7_8= 1 THEN 'Epilepsy'  END) disability, sum(d7_8) total FROM sgbv.searcher  where d7_8 = 1
union
SELECT (CASE WHEN  d7_9= 1 THEN 'No Disability'  END) disability, sum(d7_9) total FROM sgbv.searcher  where d7_9 = 1
)as temp1 where disability is not null ";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"$total,"; 
}

?>  
		  
		  ]
        }],
          chart: {
          type: 'bar',
          height: 350
        },
        plotOptions: {
          bar: {
            horizontal: false,
			
          }
        },
        dataLabels: {
          enabled: false
        },
        xaxis: {
          categories: [
		  
				
			<?php
$query  = "SELECT * from 
(SELECT (CASE WHEN d7_1 = 1 THEN 'Blindeness'  END) disability, sum(d7_2) total FROM sgbv.searcher  where d7_1 = 1
union
SELECT (CASE WHEN d7_2 = 1 THEN 'Hearing'  END) disability, sum(d7_2) total FROM sgbv.searcher  where d7_2 = 1
union
SELECT (CASE WHEN d7_3 = 1 THEN 'Walking'  END) disability,  sum(d7_3) total FROM sgbv.searcher  where d7_3 = 1
union
SELECT (CASE WHEN  d7_4= 1 THEN 'Speaking'  END) disability, sum(d7_4) total FROM sgbv.searcher  where d7_4 = 1
union
SELECT (CASE WHEN  d7_5= 1 THEN 'Intellectual'  END) disability, sum(d7_5) total FROM sgbv.searcher  where d7_5 = 1
union
SELECT (CASE WHEN  d7_6= 1 THEN 'Self Care'  END) disability, sum(d7_6) total FROM sgbv.searcher  where d7_6 = 1
union
SELECT (CASE WHEN  d7_7= 1 THEN 'Albinism'  END) disability, sum(d7_7) total FROM sgbv.searcher  where d7_7 = 1
union
SELECT (CASE WHEN  d7_8= 1 THEN 'Epilepsy'  END) disability, sum(d7_8) total FROM sgbv.searcher  where d7_8 = 1
union
SELECT (CASE WHEN  d7_9= 1 THEN 'No Disability'  END) disability, sum(d7_9) total FROM sgbv.searcher  where d7_9 = 1
)as temp1 where disability is not null ";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"'$disability',"; 
}

?>  
			
			
          ],
        }
        };

        var chart = new ApexCharts(document.querySelector("#chartpu"), options);
        chart.render();
      
      
    </script>


    
  </body>
</html>



