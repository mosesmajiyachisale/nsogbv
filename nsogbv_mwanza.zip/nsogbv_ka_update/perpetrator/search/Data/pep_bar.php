

     <div id="chart222"></div>

    <script>
      
        var options = {
          series: [{
          data: [
		  
		
		  
		  
		  <?php
$query  = "SELECT B5_T_A village, count(*) Total FROM sgbv.searcher  group by B5_T_A";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"$Total,"; 
}

?>  
		  
		  ]
        }],
          chart: {
          type: 'bar',
          height: 350
        },
        plotOptions: {
          bar: {
            horizontal: true,
          }
        },
        dataLabels: {
          enabled: false
        },
        xaxis: {
          categories: [
		  
		  
		 
			
			
			
			<?php
$query  = "SELECT B5_T_A village, count(*) Total FROM sgbv.searcher  group by B5_T_A ";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"'$village',"; 
}

?>  
			
			
          ],
        }
        };

        var chart = new ApexCharts(document.querySelector("#chart222"), options);
        chart.render();
      
      
    </script>


    
  </body>
</html>



