<!DOCTYPE html>

<?php  $District=$_GET["d"];?>
	<script src="../../dist/apexcharts/dist/apexcharts.js"></script>
<html lang="en">
  <head>

 
 

  </head>

  <body>
     <div id="chartmmhg2mz" class="Piechart"></div>

    <script>
      
        var options = {
          series: [
		  
		  <?php
$query  = "SELECT CASE WHEN d2 = 1 THEN 'Male' 
WHEN d2 = 2 THEN 'Female' 
ELSE 'Unkhown'
end sex,
 count(*) Total FROM sgbv.gbv_cases2 where A4_DISTRICT = '$District' group by d2";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"$Total,"; 
}

?>  	  
		  ],
          chart: {
          width: 320,
          type: 'donut',
        },
		legend: {
              position: 'bottom',
            },
        labels: [
		
		
		
		<?php
$query  = "SELECT CASE WHEN d2 = 1 THEN 'Male' 
WHEN d2 = 2 THEN 'Female' 
ELSE 'Unkhown'
end sex,
 count(*) Total FROM sgbv.gbv_cases2 where A4_DISTRICT = '$District' group by d2";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);



echo"'$sex',"; 
}

?>
		
		],
        responsive: [{
          breakpoint: 380,
          options: {
            chart: {
              width: 380
            },
            legend: {
              position: 'bottom'
            }
          }
        }],
        dataLabels: {
          formatter(val, opts) {
            const name = opts.w.globals.labels[opts.seriesIndex]
            return [name, val.toFixed(1) + '%']
          }
        },
        legend: {
          show: false
        },
        plotOptions: {
          pie: {
            dataLabels: {
              offset: -0
            }
          }
		}
        };

        var chart = new ApexCharts(document.querySelector("#chartmmhg2mz"), options);
        chart.render();
      
      
    </script>

    
  </body>
</html>