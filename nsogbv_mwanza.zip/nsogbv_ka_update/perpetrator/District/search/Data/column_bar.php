<?php $District=$_GET['d'];?>
  <body>
     <div id="chart3mhgz"></div>

    <script>
      
        var options = {
          series: [{
          name: 'Male',
          data: [
		  		  <?php
$query  = "select * from (SELECT a4_district, sum(CASE WHEN d2 = 1 THEN 1  END) male, sum(CASE WHEN d2 = 2 THEN 1  END) Female  FROM sgbv.searcher
group by a4_district) as der where a4_district ='$District' ";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"'$male',"; 
}

?> 
		  
		  
		  
		  ]
        }, {
          name: 'Female',
          data: [
		  
		  <?php
$query  = "select * from (SELECT a4_district, sum(CASE WHEN d2 = 1 THEN 1  END) male, sum(CASE WHEN d2 = 2 THEN 1  END) Female  FROM sgbv.searcher
group by a4_district) as der where a4_district ='$District'";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"'$Female',"; 
}

?> 
		  
		  ]
        }, /* {
          name: 'Free Cash Flow',
          data: [35, 41, 36, 26, 45, 48, 52, 53, 41]
        } */],
          chart: {
          type: 'bar',
          height: 350
        },
        plotOptions: {
          bar: {
            horizontal: false,
            columnWidth: '55%',
            endingShape: 'rounded'
          },
        },
        dataLabels: {
          enabled: false
        },
        stroke: {
          show: true,
          width: 2,
          colors: ['transparent']
        },
        xaxis: {
          categories: [
		  
		  		  <?php
$query  = "select * from (SELECT a4_district, sum(CASE WHEN A2_SEX = 1 THEN 1  END) male, sum(CASE WHEN A2_SEX = 2 THEN 1  END) Female  FROM sgbv.searcher
group by a4_district) as der where a4_district ='$District'";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"'$a4_district',"; 
}

?> 	  
		  ],
        },
        yaxis: {
          title: {
            text: 'number of perpetrators'
          }
        },
        fill: {
          opacity: 1
        },
        tooltip: {
          y: {
            formatter: function (val) {
             // return "$ " + val + " thousands"
			   return val 
            }
          }
        }
        };

        var chart = new ApexCharts(document.querySelector("#chart3mhgz"), options);
        chart.render();
      
      
    </script>

    
  </body>
</html>
