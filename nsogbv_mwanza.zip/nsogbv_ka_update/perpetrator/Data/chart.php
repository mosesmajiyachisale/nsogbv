<!DOCTYPE html>

	<script src="dist/apexcharts/dist/apexcharts.js"></script>
<html lang="en">
  <head>

 
 

  </head>

  <body>
     <div id="chart"></div>

    <script>
      
        var options = {
          series: [
		  
		  <?php
$query  = "SELECT A5_T_A village, count(*) Total FROM sgbv.sgb_cases group by A5_T_A ";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"$Total,"; 
}

?>  	  
		  ],
          chart: {
          width: 320,
          type: 'donut',
        },
        labels: [
		
		
		
		<?php
$query  = "SELECT A5_T_A village, count(*) Total FROM sgbv.sgb_cases group by A5_T_A ";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);



echo"'$village',"; 
}

?>
		
		],
        responsive: [{
          breakpoint: 380,
          options: {
            chart: {
              width: 380
            },
            legend: {
              position: 'bottom'
            }
          }
        }]
        };

        var chart = new ApexCharts(document.querySelector("#chart"), options);
        chart.render();
      
      
    </script>

    
  </body>
</html>