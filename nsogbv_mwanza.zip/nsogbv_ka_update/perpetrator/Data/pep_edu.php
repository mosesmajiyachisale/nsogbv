<!DOCTYPE html>

	<script src="../dist/apexcharts/dist/apexcharts.js"></script>
<html lang="en">
  <head>

 
 

  </head>

  <body>
     <div id="charte" class="Piechart"></div>

    <script>
      
        var options = {
          series: [
		  
		  <?php
$query  = "SELECT  case 
when d9 = 1 then 'None' 
when d9 = 2 then 'Primary' 
when d9 = 3 then 'Secondary' 
when d9 = 4 then 'Tertiary' 
ELSE 'Unknown'
end education, count(*) total FROM sgbv.gbv_cases2 group by d9";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"$total,"; 
}

?>  	  
		  ],
          chart: {
          width: 320,
          type: 'donut',
        },
		legend: {
              position: 'bottom',
            },
        labels: [
		
		
		
		<?php
$query  = "SELECT  case 
when d9 = 1 then 'None' 
when d9 = 2 then 'Primary' 
when d9 = 3 then 'Secondary' 
when d9 = 4 then 'Tertiary' 
ELSE 'Unknown'
end education, count(*) total FROM sgbv.gbv_cases2 group by d9";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);



echo"'$education',"; 
}

?>
		
		],
        responsive: [{
          breakpoint: 1600,
          options: {
            chart: {
              width: 240
            },
            legend: {
              position: 'bottom'
            }
          }
        }],
        dataLabels: {
          formatter(val, opts) {
            const name = opts.w.globals.labels[opts.seriesIndex]
            return [name, val.toFixed(1) + '%']
          }
        },
        legend: {
          show: false
        },
        plotOptions: {
          pie: {
            dataLabels: {
              offset: -0
            }
          }
		}
        };

        var chart = new ApexCharts(document.querySelector("#charte"), options);
        chart.render();
      
      
    </script>

    
  </body>
</html>