
<head>
<script src="dist/apexcharts/dist/apexcharts.js"></script>
</head>
	     <div id="chart3b"></div>


	
	
	

	
	
	
	    <script>
      
        var options = {
          series: [
		  
<?php

$query  = "SELECT * FROM districts ";
$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);



//echo"$Total,"; 
}

?>

Blantyre,Lilongwe,Mzuzu
		  
		  
		  ],
          chart: {
          width: 350,
          type: 'pie',
        },
        labels: [
		
						  
<?php

$query  = "SELECT * FROM districts ";
$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);



//echo"$district,"; 
}
10,20,30
?>
		
		
		],
        responsive: [{
          breakpoint: 350,
          options: {
            chart: {
              width: 200
            },
            legend: {
              position: 'bottom'
            }
          }
        }]
        };

        var chart = new ApexCharts(document.querySelector("#chart3b"), options);
        chart.render();
      
      
    </script>