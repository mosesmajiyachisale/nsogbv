<!DOCTYPE html>

	<script src="../dist/apexcharts/dist/apexcharts.js"></script>
<html lang="en">
  <head>

 
 

  </head>

  <body>
     <div id="chartmPEP" class="Piechart"></div>

    <script>
      
        var options = {
          series: [
		  
		  <?php
$query  = "SELECT  case 
when d8 = 1 then 'Never married' 
when d8 = 2 then 'Married' 
when d8 = 4 then 'Separated' 
when d8 = 5 then 'Widow(er)' 
ELSE 'Unknown'
end marital, count(*) total FROM sgbv.gbv_cases2 group by d8";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"$total,"; 
}

?>  	  
		  ],
          chart: {
          width: 320,
          type: 'pie',
        },
		legend: {
              position: 'bottom',
            },
        labels: [
		
		
		
		<?php
$query  = "SELECT  case 
when d8 = 1 then 'Never married' 
when d8 = 2 then 'Married' 
when d8 = 4 then 'Separated' 
when d8 = 5 then 'Widow(er)' 
ELSE 'Unknown'
end marital, count(*) total FROM sgbv.gbv_cases2 group by d8 ";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);



echo"'$marital',"; 
}

?>
		
		],
        responsive: [{
          breakpoint: 1600,
          options: {
            chart: {
              width: 240
            },
          }
        }],
        dataLabels: {
          formatter(val, opts) {
            const name = opts.w.globals.labels[opts.seriesIndex]
            return [name, val.toFixed(1) + '%']
          }
        },
        legend: {
          show: false
        },
        plotOptions: {
          pie: {
            dataLabels: {
              offset: -15
            }
          }
		}
        };

        var chart = new ApexCharts(document.querySelector("#chartmPEP"), options);
        chart.render();
      
      
    </script>

    
  </body>
</html>