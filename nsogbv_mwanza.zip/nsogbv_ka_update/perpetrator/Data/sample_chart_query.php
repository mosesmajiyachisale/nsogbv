  <?php  
include("jasondata.php");
	
	?>

	 

	
	
	
	     <div id="chart10"></div>

    <script>
      
        var options = {
          series: [{
          data: [
		  
		 	  	  <?php

                 
				$query  = "SELECT A5_T_A village, count(*) Total FROM sgbv.sgb_cases group by A5_T_A";          
			  $results = mysqli_query($link, $query);
					$nrows = mysqli_num_rows($results);
					$row = mysqli_num_rows($results);

					for ($i=0;$i<$nrows;$i++)

					{
					$n = $i + 1;
					$row = mysqli_fetch_array($results);
					extract($row);
					
						
						echo"$Total,"; 
					}
					
					?>
		  
		  ]
        }],
          chart: {
          type: 'bar',
          height: 420
        },
        plotOptions: {
          bar: {
            horizontal: true,
          }
        },
        dataLabels: {
          enabled: true
        },
        xaxis: {
          categories: [
		  
		 	  	  <?php

                 
				$query  = "SELECT A5_T_A village, count(*) Total FROM sgbv.sgb_cases group by A5_T_A";          
			  $results = mysqli_query($link, $query);
					$nrows = mysqli_num_rows($results);
					$row = mysqli_num_rows($results);

					for ($i=0;$i<$nrows;$i++)

					{
					$n = $i + 1;
					$row = mysqli_fetch_array($results);
					extract($row);
					
						
						echo"$village,"; 
					}
					
					?>
          ],
        }
        };

        var chart = new ApexCharts(document.querySelector("#chart10"), options);
        chart.render();
 
    </script>
