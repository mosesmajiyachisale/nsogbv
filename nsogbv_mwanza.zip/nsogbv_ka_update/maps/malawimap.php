<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Spotlight Initiative</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />
        <!-- <link href="../css/bootstrap-4.4.1.css" rel="stylesheet" /> -->
        <link href="../css/bootstrap-4.3.1.css" rel="stylesheet" type="text/css">
        <style>
			.theme{
				background:#009edb;color: aliceblue;
				border-bottom:solid 2px #576F9E;;
			}
			.fixed-footer{
				   position:fixed;
				   bottom:0;
				   width:100%;
				   height:60px;
				}
			canvas{
			 display: inline-block !important;
			}	

		</style>
</head>
    <body>
        <div class="d-flex" id="wrapper">
            <!-- Sidebar-->
            <div class="" id="sidebar-wrapper" >
                <div class="sidebar-heading theme" style="height: 71px;border-bottom: solid 1px grey;">
				
				</div>
                <div class="list-group list-group-flush" >
                    <b>
					<a class="list-group-item list-group-item-action " href="#!">Home</a>
					<a class="list-group-item list-group-item-action " href="#!">Overview</a>
                    <a class="list-group-item list-group-item-action " href="#!">Dashboard</a>
                    <a class="list-group-item list-group-item-action " href="#!">Contact Us</a>
					<a class="list-group-item list-group-item-action " href="#!">Courts</a><a class="list-group-item list-group-item-action " href="#!">Hospitals</a></b>
          <!--                	<a class="list-group-item list-group-item-action " data-toggle="modal" data-target="#HospitalEntry"><button class="btn btn-primary" id="" style="margin-left:5px;">Hospital Entry</button>
					</a><a class="list-group-item list-group-item-action " data-toggle="modal" data-target="#courtEntry"><button class="btn btn-primary" id="" style="margin-left:5px;">Court entry</button></a>
                  -->  
                </div>
            </div>
            <!-- Page Content-->
            <div id="page-content-wrapper">
                <nav class="navbar navbar-expand-lg navbar-light border-bottom theme" style="">
                    <button class="btn btn-success" id="menu-toggle">Menu</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<h3 style="text-align: center;">SGBV DASHBOBOARD</h3>
                    
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
                            <li class="nav-item"><a class="nav-link" href="#!"><form class="form-inline my-2 my-lg-0">
			  				<input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
			  				<button class="btn btn-success my-2 my-sm-0" type="submit">Search</button>
							</form></a></li>
                        </ul>
                    </div>
                </nav>
                <div class="container-fluid border">
                    <div class="" style="width: 65%;float: left;">
					  <div id="carouselExampleIndicators1" class="carousel slide" data-ride="carousel" style="background-color:aliceblue;">
						  <ol class="carousel-indicators">
						    <li data-target="#carouselExampleIndicators1" data-slide-to="0" class="active"></li>
						    <li data-target="#carouselExampleIndicators1" data-slide-to="1"></li>
						    <li data-target="#carouselExampleIndicators1" data-slide-to="2"></li>
					    </ol>
						 <!-- <div class="carousel-inner" role="listbox">
						    <!-- <div class="carousel-item active"> <img class="d-block mx-auto" src="images/statistics.png" alt="First slide">
						      <div class="carousel-caption">
						        <h5>First slide Heading</h5>
						        <p>First slide Caption</p>
					          </div>
					        </div> -->
						    <!-- <div class="carousel-item"> <img class="d-block mx-auto" src="images/statistics.png" alt="Second slide">
						      <div class="carousel-caption">
						        <h5>Second slide Heading</h5>
						        <p>Second slide Caption</p>
					          </div>
					        </div>  --> 
					  <!--  </div>
						  <a class="carousel-control-prev" href="#carouselExampleIndicators1" role="button" data-slide="prev"> <span class="carousel-control-prev-icon" aria-hidden="true"></span> <span class="sr-only">Previous</span> </a> <a class="carousel-control-next" href="#carouselExampleIndicators1" role="button" data-slide="next"> <span class="carousel-control-next-icon" aria-hidden="true"></span> <span class="sr-only">Next</span> </a> </div>
					<!--<p><b>This system aims at collecting, analysing and use of disaggregated data for evidence-based decision making on SGBV cases in Malawi.  The system also aims at addressing challenges that require data/system integrated to avoid fragmentation and improve coordination amongst data producers. It ensures that data ecosystem involves non-state actors, both as users and suppliers of data. The national Observatory Hub allows monitoring trends and patterns of VAWG, SGBV, HP, and SRHR at national level; mapping of all existing SRHR, SGBV, HP, CP national and district level; linking national level gender data management system, national observatory hub, to district level management systems; producing harmonized data collection tools and distribute to 6 districts councils, traditional authorities and communities and strengthening institutions for data management, both software and hardware.</b>
							  </p> -->
					
							  
							  
					</div>
					<div class="" style="width: 20%;float: left;text-align:center;">
						<iframe src="maps/index.html" style="border: 0px;height: 670px;">
						</iframe>
					</div>
						
					</div>
					
            </div>
        </div>
	<!--	<div class="fixed-footer" id="footer" style="margin-top: 800px;height: 200px;background-color: ;text-align: center;">
		<img src="assets/image001.png" style="height: 90px">
		</div> -->
		
		<div class="fixed-footer">
 <div class="container"><center>Copyright &copy; <img src="assets/image001.png" style="height: 90px"></center></div> 
</div>
		
    <!-- Bootstrap core JS-->
        <!-- <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script> -->
   <!--  f     <script src="../js/jquery-3.3.1.min.js"></script>
    <!-- f  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <!--<script src="js/scripts.js"></script> -->
	<!--  f	<script src="../js/popper.min.js"></script>
     <!--  f   <script src="../js/bootstrap-4.3.1.js"></script> -->

<script type = "text/javascript" src="jsme\jquery.min.js"></script>

<script type = "text/javascript" src="jsme/chart.min.js"></script>

<script type = "text/javascript" src="jsme\app.js"></script>
    </body>
</html>
