<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Map</title>
	<script src="anychart-core.min.js"></script>
    <script src="anychart-map.min.js"></script>
    <script src="proj4.js"></script>
	<script src="malawi.js"></script>
	<style>
		.anychart-credits-text{display:none;}
	</style>
</head>

<body>
	<div style="width: 100%; height: 95vh;" id="container">
	
</div>
	<script>
		<?php
			function Value($Query){
							$conn = new mysqli("localhost", "root", "", "spotlight");
							$ThisValue=0;
							$result = $conn->query($Query);
							if ($result->num_rows > 0) {
								// output data of each row
								while($row = $result->fetch_assoc()) {
									$ThisValue= $row["value"];
									if($ThisValue=="")$ThisValue=0;
								}
							}
							return $ThisValue;
							$conn->close();
						}
			function cases($ThisDistrict){
				$PeriodID=Value('SELECT PeriodID as value FROM `period` GROUP BY Year ORDER BY Year DESC LIMIT 1');
				$cases=Value("select count(*) as value from sgbv.gbv_cases2 where A4_DISTRICT_Name ='$ThisDistrict'");
				return $cases;
			}
			function color($Cases){
				$fill="'fill':'white'";
				if($Cases>0)$fill="'fill':'#33ff33'";
				if($Cases>20)$fill="'fill':'#ffff33'";
				if($Cases>50)$fill="'fill':'#ff9933'";
				if($Cases>100)$fill="'fill':'#ff3333'";
				echo $fill;
			}
		?>
    	
		anychart.onDocumentReady(function() {
		var data = [ {'id': 'MW.MZ', 'value': <?php echo cases('Mzimba');?>,<?php color(cases('Mzimba'));?>},{'id': 'MW.NA', 'value': <?php echo cases('Nkhatabay');?>,<?php color(cases('Nkhatabay'));?>},{'id': 'MW.MA', 'value': <?php echo cases('Machinga');?>,<?php color(cases('Machinga'));?>},{'id': 'MW.DO', 'value': <?php echo cases('Dowa');?>,<?php color(cases('Dowa'));?>},{'id': 'MW.NI', 'value': <?php echo cases('Ntchisi');?>,<?php color(cases('Ntchisi'));?>},{'id': 'MW.NS', 'value': <?php echo cases('Nsanje');?>,<?php color(cases('Nsanje'));?>}, 
  		  ];
      	// set the map chart
      	var map = anychart.map();
      	// set the global geodata
      	map.geoData('anychart.maps.malawi');
      	// set the map title
      	//map.title( 'SpotLight');
		
		// set the marker series
		//var series2 = map.marker(anychart.data.set(data));
		var series = map.choropleth(data);
		//series.color("#ffc2b3","#ffd9b3","#fff0b3","#d9ffb3");
		//map.legend(true);
  
		// disable labels to not show latitude and longitude for each point
		map.labels(true);
		// set the containter
		map.container('container');
		// draw the map
		map.draw();
		
		});</script>
		
  		
	
</body>
</html>
