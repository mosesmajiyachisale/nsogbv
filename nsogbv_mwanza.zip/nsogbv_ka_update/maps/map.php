	<style>
		.anychart-credits-text{display:none;}
		.anychart-credits-logo{display:none;}
		@media (max-width: 200px) {    #container { display: none; } }
	</style>
	<div style="width: 100%; height: calc(100vh - 131px);" id="container" class="200-none">
	
</div>
	<script>
		<?php
		if(!isset($location))$location="'./'";
			function MapValue($Query){
							$conn = new mysqli("localhost", "pillar5", "spotLight@5", "sgbv");
							$ThisValue=0;
							$result = $conn->query($Query);
							if ($result->num_rows > 0) {
								// output data of each row
								while($row = $result->fetch_assoc()) {
									$ThisValue= $row["value"];
									if($ThisValue=="")$ThisValue=0;
								}
							}
							return $ThisValue;
							$conn->close();
						}
			function Mapcases($ThisDistrict){
				$Mapcases=MapValue("select count(*) as value from sgbv.gbv_cases2 where a4_district ='$ThisDistrict'");
				return $Mapcases;
			}
			function color($ColorDistrict){
				if(isset($_GET["d"]))if($_GET["d"]==$ColorDistrict)echo"'fill':'yellow'";
			}
		?>
		
		anychart.onDocumentReady(function() {
		var data = [ {'id': 'MW.MZ','name':'Mzimba', 'value': <?php echo Mapcases('Mzimba');?>,<?php color("Mzimba");?>},{'id': 'MW.NA','name':'Nkhatabay', 'value': <?php echo Mapcases('Nkhatabay');?>,<?php color("Nkhatabay");?>},{'id': 'MW.MA','name':'Machinga', 'value': <?php echo Mapcases('Machinga');?>,<?php color("Machinga");?>},{'id': 'MW.DO','name':'Dowa', 'value': <?php echo Mapcases('Dowa');?>,<?php color("Dowa");?>},{'id': 'MW.NI','name':'Ntchisi', 'value': <?php echo Mapcases('Ntchisi');?>,<?php color("Ntchisi");?>},{'id': 'MW.NS','name':'Nsanje', 'value': <?php echo Mapcases('Nsanje');?>,<?php color("Nsanje");?>}, 
  		  ];
      	// set the map chart
      	var map = anychart.map();
      	// set the global geodata
      	map.geoData('anychart.maps.malawi');
      	// set the map title
      	//map.title( 'SpotLight');
		
		// set the marker series
		//var series2 = map.marker(anychart.data.set(data));
		var series = map.choropleth(data);
		//series.color('#1e88e5');
		map.legend(false);
		series
            .tooltip()
            .useHtml(true)
            .titleFormat('{%name}')
            .format(function () {
              var amount =
                '<span style="color: #d9d9d9;">' +
                this.getData('name')+' Incidences';
              {
                amount =
                  '<span style="color: #d9d9d9;">' +
                  '<strong><span style="color: #fff;">' +
                  this.value +
                  ' </span></strong>Cases ' +
                  '</span><br/>Click for more.';
              }
              return amount;
            });
		
		// disable labels to not show latitude and longitude for each point
		map.labels(true);
		
		// onclick function for points - redirecting client (based on baseLink variable)
          map.listen('pointClick', function (e) {
            location=<?php echo $location;?>+data[e.pointIndex].name;
			window.open(location);
          });
		
		// set the containter
		map.container('container');
		// draw the map
		map.draw();
		
		});</script>
