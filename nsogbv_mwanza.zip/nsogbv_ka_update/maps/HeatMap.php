<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Map</title>
	<script src="anychart-core.min.js"></script>
    <script src="anychart-map.min.js"></script>
    <script src="proj4.js"></script>
	<script src="malawi.js"></script>
	<style>
		.anychart-credits-text{display:none;}
	</style>
</head>

<body>
	<div style="width: 100%; height: 95vh;" id="container">
	
</div>
	<script>
		<?php
			function Value($Query){
							$conn = new mysqli("localhost", "root", "", "spotlight");
							$ThisValue=0;
							$result = $conn->query($Query);
							if ($result->num_rows > 0) {
								// output data of each row
								while($row = $result->fetch_assoc()) {
									$ThisValue= $row["value"];
									if($ThisValue=="")$ThisValue=0;
								}
							}
							return $ThisValue;
							$conn->close();
						}
			function cases($ThisDistrict){
				$QuarterID=Value('SELECT QuarterID as value FROM `quarter` GROUP BY Year ORDER BY Year DESC LIMIT 1');
				$cases=Value("SELECT Sum(RapeCaseRecorded+DefilementCasesRecorded+SexualHarassmentCasesRecorded+EconomicViolenceCasesRecorded) as value FROM `courttbl` where District=\"$ThisDistrict\" and QuarterID=$QuarterID");
				return $cases;
			}
		?>
		anychart.onDocumentReady(function() {
    	var scale = anychart.scales.ordinalColor([
		  {less: 10},
		  {from: 10, to: 30},
		  {greater: 30}
		  ]);
		  scale.colors(['#ffebe6', '#ff5c33', '#cc2900']);
		var data = [{'id': 'MW.MZ', 'value': <?php echo cases('Mzimba');?>},{'id': 'MW.NA', 'value': <?php echo cases('Nkhatabay');?>},{'id': 'MW.MA', 'value': <?php echo cases('Machinga');?>},{'id': 'MW.DO', 'value': <?php echo cases('Dowa');?>},{'id': 'MW.NI', 'value': <?php echo cases('Ntchisi');?>},{'id': 'MW.NS', 'value': <?php echo cases('Nsanje');?>}, 
  		  ];
      	// set the map chart
      	var map = anychart.map();
      	// set the global geodata
      	map.geoData('anychart.maps.malawi');
      	// set the map title
      	//map.title( 'SpotLight');
		
		// set the marker series
		//var series2 = map.marker(anychart.data.set(data));
		var series = map.choropleth(data);
		series.colorScale(scale);
		map.legend(true);
		map.legend().itemsSourceMode('categories');
  
		// disable labels to not show latitude and longitude for each point
		//map.labels(true);
		// set the containter
		map.container('container');
		// draw the map
		map.draw();
		
		});</script>
  		
	
</body>
</html>
