<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Map </title>
	<script src="../js/anychart-core.min.js"></script>
	<script src="../js/anychart-map.min.js"></script>
	<script src="../js/malawi.js"></script>
	<style>
		.anychart-credits-text{display:none;}
	</style>
</head>

<body>
	<div style="width: 100%; height: 95vh;" id="container">
	
</div>
	<script>
		<?php
			$location="localhost'";
			$url="h'";
			if(isset($_GET['location']))$location="".$_GET['location']."'";
			if(isset($_GET['loc']))$url=$_GET['loc'];
			function Value($Query){
							$conn = new mysqli("localhost", "root", "", "spotlight");
							$ThisValue=0;
							$result = $conn->query($Query);
							if ($result->num_rows > 0) {
								// output data of each row
								while($row = $result->fetch_assoc()) {
									$ThisValue= $row["value"];
									if($ThisValue=="")$ThisValue=0;
								}
							}
							return $ThisValue;
							$conn->close();
						}
			function cases($ThisDistrict){
				$cases=Value("select count(*) as value from sgbv.gbv_cases2 where a4_district ='$ThisDistrict'");
				return $cases;
			}
			function color($ColorDistrict){
				if(isset($_GET["$ColorDistrict"]))echo"'fill':'yellow'";
			}
		?>
		
		anychart.onDocumentReady(function() {
		var data = [ {'id': 'MW.MZ','name':'Mzimba', 'value': <?php echo cases('Mzimba');?>,<?php color("Mzimba");?>},{'id': 'MW.NA','name':'Nkhatabay', 'value': <?php echo cases('Nkhatabay');?>,<?php color("Nkhatabay");?>},{'id': 'MW.MA','name':'Machinga', 'value': <?php echo cases('Machinga');?>,<?php color("Machinga");?>},{'id': 'MW.DO','name':'Dowa', 'value': <?php echo cases('Dowa');?>,<?php color("Dowa");?>},{'id': 'MW.NI','name':'Ntchisi', 'value': <?php echo cases('Ntchisi');?>,<?php color("Ntchisi");?>},{'id': 'MW.NS','name':'Nsanje', 'value': <?php echo cases('Nsanje');?>,<?php color("Nsanje");?>}, 
  		  ];
      	// set the map chart
      	var map = anychart.map();
      	// set the global geodata
      	map.geoData('anychart.maps.malawi');
      	// set the map title
      	//map.title( 'SpotLight');
		
		// set the marker series
		//var series2 = map.marker(anychart.data.set(data));
		var series = map.choropleth(data);
		//series.color('#1e88e5');
		series
            .tooltip()
            .useHtml(true)
            .titleFormat('{%name}')
            .format(function () {
              var amount =
                '<span style="color: #d9d9d9;">' +
                this.getData('name')+' Incidences';
              {
                amount =
                  '<span style="color: #d9d9d9;">' +
                  '<strong><span style="color: #fff;">' +
                  this.value +
                  ' </span></strong>Cases ' +
                  '</span><br/>Click to see more.';
              }
              return amount;
            });
			
		map.legend(false);
		
		// disable labels to not show latitude and longitude for each point
		map.labels(true);
		
		
		// set the containter
		map.container('container');
		// draw the map
		map.draw();
		
		});</script>
  		
	
</body>
</html>
