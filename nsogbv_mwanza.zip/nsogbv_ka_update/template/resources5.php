	<link href="../../../../assets/libs/chartist/dist/chartist.min.css" rel="stylesheet">
    <link href="../../../../dist/js/pages/chartist/chartist-init.css" rel="stylesheet">
    <link href="../../../../assets/libs/chartist-plugin-tooltips/dist/chartist-plugin-tooltip.css" rel="stylesheet">
    <link href="../../../../assets/libs/c3/c3.min.css" rel="stylesheet">
	<link href="../../../../css/w3.css" rel="stylesheet">
	<link rel="stylesheet" href="../../../mystyles.css">
    <!-- Custom CSS -->
    <link href="../../../../dist/css/style.min.css" rel="stylesheet">
	<script src="../../../../dist/apexcharts/dist/apexcharts.js"></script>
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	 <style>
		.fixed-footer{
			position:fixed;
			bottom:0;
			width:100%;
			height:60px;
			text-align: center;
			//padding: 3px;
			background-color: #E5E5E5;
			color: white;
		}
		.theme{
				color: aliceblue;
			}
		.anychart-credits-text{
			display:none;
		}.card-body {
			overflow-x: hidden;
		}.Piechart {
			overflow-x: hidden;
		}

		.Piechart div {
		  margin:auto;
		} 
		.card-title {
			white-space: nowrap;
		}
	</style>
	<script src="../../../../assets/libs/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="../../../../assets/libs/popper.js/dist/umd/popper.min.js"></script>
    <script src="../../../../assets/libs/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- apps -->
    <script src="../../../../dist/js/app.min.js"></script>
    <script src="../../../../dist/js/app.init.js"></script>
    <script src="../../../../dist/js/app-style-switcher.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="../../../../assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
    <script src="../../../../assets/extra-libs/sparkline/sparkline.js"></script>
    <!--Wave Effects -->
    <script src="../../../../dist/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="../../../../dist/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="../../../../dist/js/custom.min.js"></script>
    <!--This page JavaScript -->
    <!-- chartist chart -->
    <script src="../../../../assets/libs/chartist/dist/chartist.min.js"></script>
    <script src="../../../../assets/libs/chartist-plugin-tooltips/dist/chartist-plugin-tooltip.min.js"></script>
    <!--c3 JavaScript -->
    <script src="../../../../assets/libs/d3/dist/d3.min.js"></script>
    <script src="../../../../assets/libs/c3/c3.min.js"></script>
    <!-- Chart JS -->
    <script src="../../../../dist/js/pages/dashboards/dashboard1.js"></script>
	<script src="../../../../js/W3.js"></script>
	
	<script src="../../../../js/anychart-core.min.js"></script>
	<script src="../../../../js/anychart-map.min.js"></script>
	<script src="../../../../js/malawi.js"></script>