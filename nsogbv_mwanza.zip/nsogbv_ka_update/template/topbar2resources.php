<!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <header class="topbar">
            <nav class="navbar top-navbar navbar-expand-md navbar-dark">
                <div class="navbar-header"  style="height: 70px;">
                    <!-- This is for the sidebar toggle which is visible on mobile only -->
                    <a class="nav-toggler waves-effect waves-light d-block d-md-none" href="javascript:void(0)"><i class="ti-menu ti-close"></i></a>
					<a class="navbar-brand" href="../">
                        <!-- Logo icon -->
                        <b class="logo-icon">
                        </b>
                        <!--End Logo icon -->
						
                        <!-- Logo text -->
                        <span class="logo-text">
						<h2 style="color:aliceblue;line-height: 70px;">SGBV DASHBOARD</h2>
                        </span>
                    </a>
                    <!-- ============================================================== -->
                    <!-- End Logo -->
                    <!-- ============================================================== -->
                    <!-- ============================================================== -->
                    <!-- Toggle which is visible on mobile only -->
                    <!-- ============================================================== -->
                    <a class="topbartoggler d-block d-md-none waves-effect waves-light" href="javascript:void(0)"  data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><i class="ti-more"></i></a>
                </div>
                <!-- ============================================================== -->
                <!-- End Logo -->
                <!-- ============================================================== -->
                <div class="navbar-collapse collapse" id="navbarSupportedContent" style="height: 70px;">
                    <!-- ============================================================== -->
                    <!-- toggle and nav items -->
                    <!-- ============================================================== -->
                    <style>
						.My-nav-link {
							line-height: 70px;
							height: 70px;
							padding: 0 .40rem;
							font-size: 17px;
							cursor:pointer;
						}
                    </style>
					<ul class="navbar-nav mr-auto float-left">
                        <li class="nav-item"> 
							<a class="nav-link sidebartoggler d-none d-md-block waves-effect waves-dark" href="javascript:void(0)"><i class="ti-menu"></i></a> 
						</li>
						<li class="nav-item">
							<div class="dropdown">
								  <b type="button" class=" dropdown-toggle My-nav-link theme" data-toggle="dropdown">
									Incidences
								  </b>
								  <div class="dropdown-menu w3-center"><br>
									<a href="../survivor"><b>Survivor</b></a><hr>
									<a href="../Perpetrator/"><b>Perpetrator</b></a><hr>
									<a href="../srhr/"><b>SRHR</b></a><hr>
									<a href="../gbvfreq/"><b>GBV Freq</b></a>
								  </div>
								</div>
						</li>
						<!--<li class="nav-item">
							<div class="dropdown">
								  <b type="button" class=" dropdown-toggle My-nav-link theme" data-toggle="dropdown">
									Institutions
								  </b>
								  <div class="dropdown-menu w3-center"><br>
									<a href="../Courts"><b class="">Courts</b></a><hr>
									<a href="../Hospitals"><b class="">Health Centers</b></a><hr>
								  </div>
							</div>
						</li>-->


                       <li class="nav-item">
							<div class="dropdown">
								  <b type="button" class=" dropdown-toggle My-nav-link theme" data-toggle="dropdown">
								 Report
								  </b>
								  <div class="dropdown-menu w3-center uk-padding">
									<form action = "../search/index.php" method="POST" >
										<label>From</label><input class="uk-input" type="date" name="from" size="50" max=<?php echo date('Y-m-d');?> >
										<label>To: </label><input class="uk-input" size="30" type="date" name="to" value=<?php echo date('Y-m-d');?>  max=<?php echo date('Y-m-d');?>>
										<br>
										<br>
										<input type="submit" class="uk-button uk-button-primary" value="Generate" name="submit" /> 
									</form> 
									<!--<hr>-->
									<!--<a href="indicators" class="btn btn-primary" disabled>Advanced</a>-->
								  </div>
								</div>
						</li>
						

						<li class="nav-item">
							<div class="dropdown">
								  <b type="button" class=" dropdown-toggle My-nav-link theme" data-toggle="dropdown">
									More
								  </b>
								  <div class="dropdown-menu w3-center"><br>
									<a href="../resources/"><b>Resources</b></a><hr>
									<a href="../About Us/"><b>About Us</b></a><hr>
									<a href="../Contact Us/"><b>Contact Us</b></a>
								  </div>
							</div>
						</li>
                    </ul>
                    <ul class="navbar-nav float-right">
                        <li class="nav-item dropdown">
                            <a href = "../manage/" title="Enter Administrative Data" aria-haspopup="true" aria-expanded="false" ><b class="My-nav-link theme">Admin</b></a>
						</li>   						 	
                    </ul>
					
                </div>
				
            </nav>
			
        </header>
        <!-- ============================================================== -->
        <!-- End Topbar header -->
        <!-- ============================================================== -->