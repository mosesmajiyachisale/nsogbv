<aside class="customizer">
        <a href="javascript:void(0)" class="service-panel-toggle"><i class="fa fa-spin fa-cog"></i></a>
        
                        <!-- Logo BG -->
						<form method="post" target="#output_frame">
							<div class="w3-col s12 w3-center" style="height:70px;background-color: #1e88e5;"> 
								<h4 class="w3-center" style="color:aliceblue;line-height: 70px;">Create Report</h4>
							</div>
							<div class="w3-col s12" style="margin-top:50px"> 
								<div class="dropdown w3-col s12">
								  <button type="button" class="btn btn-primary dropdown-toggle w3-col s12" data-toggle="dropdown">
									period
								  </button>
								  <div class="dropdown-menu col-md-10 border" style="margin-left:8.3%;">
											<table>
												<tr>
													<td>From</td><td></b><input type="date" name="from" size="50" max=<?php echo date('Y-m-d');?> ></td>
												</tr>
												<tr>
													<td>To</td><td><input size="30" type="date" name="to"  max=<?php echo date('Y-m-d');?>></td>
												</tr>
											</table>
								  </div>
								</div>
							</div>
							<div class="w3-col s12" style="margin-top:50px"> 
								<div class="dropdown w3-col s12">
								  <button type="button" class="btn btn-primary dropdown-toggle w3-col s12" data-toggle="dropdown">
									District
								  </button>
								  <div class="dropdown-menu col-md-10 border" style="margin-left:8.3%;">
									<input class="w3-input" placeholder="Filter..."  oninput="w3.filterHTML('#FilterDistrict', 'li', this.value)">
										<ul class="w3-ul " id="FilterDistrict">
											<?php 
												$SpotlightDistricts=Districts();
												foreach($SpotlightDistricts as $ThisDistrict)
												{
													echo "<li><input name='$ThisDistrict District' class=\"w3-check\" type=\"checkbox\"> ".$ThisDistrict."</li>";
												}
											?>
										</ul>
								  </div>
								</div>
							</div>
							<div class="w3-col s12" style="margin-top:50px"> 
								<div class="dropdown w3-col s12">
								  <button type="button" class="btn btn-primary dropdown-toggle w3-col s12" data-toggle="dropdown">
									Indicator
								  </button>
								  <div class="dropdown-menu col-md-10 border" style="margin-left:8.3%;">
									<input class="w3-input" placeholder="Filter..."  oninput="w3.filterHTML('#FilterIndicator', 'li', this.value)">
										<ul class="w3-ul " id="FilterIndicator">
											<?php 
												$Indicators=Indicators();
												foreach($Indicators as $ThisIndicator)
												{
													echo "<li><input name='$ThisIndicator' value='$ThisIndicator'  class=\"w3-check\" type=\"checkbox\"> ".$ThisIndicator."</li>";
												}
											?>
										</ul>
								  </div>
								</div>
							</div>
							<div class="w3-col s12" style="margin-top:50px">
								<button class="w3-button w3-green w3-round-xxlarge w3-center w3-col s6" style="margin-left:25%;"><i class="fas fa-search"></i> Search</button>
							</div>
						</form>
    </aside>