		<!-- ============================================================== -->
        <!-- Left Sidebar-->
        <!-- ============================================================== -->
        <aside class="left-sidebar" style="overflow:hidden;">
            <!-- Map-->
            <div class="sidebar-item" style="width: 100%;transition: 1s ease-in;overflow:hidden;">
				<div class="sidebar-footer " style="width: 240px;float: left;text-align:center;border:0px;position: relative;">
						<?php $location="'../?d='";include "../../../maps/map.php";?>
					</div> 
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
            <!-- Bottom points-->
            <div class="sidebar-footer" style="position: relative;background-color: #082844;height: 61px;">
                <!-- item-->
                <a  class="link" ><i class="mdi mdi-map" style="color:aliceblue;"></i></a>
                <!-- item-->
                <a  class="link"><i class="mdi" style="color:aliceblue;">Districts</i></a>
                <!-- item-->
                <a  class="link"><i class="mdi mdi-map" style="color:aliceblue;"></i></a>
            </div>
            <!-- End Bottom points-->
        </aside>
        <!-- ============================================================== -->
        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
        <!-- ============================================================== -->