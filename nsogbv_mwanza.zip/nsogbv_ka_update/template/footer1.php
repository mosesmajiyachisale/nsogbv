<div class="fixed-footer" style="background-color:#082844;">
		
	<div class="w3-col s9" color = "blue">
	
		<br><center><b>Copyright &copy; National Statistical Office</b>	<img src="../imagez/un.png" alt="un" width="50" height="40" style="float: right; margin-right: 8px;">  <img src="../imagez/coat_of_arms.png" alt="coat" width="33" height="50" style="float: right; margin-right: 8px;"> </center>
		<center><b>Supported by UNDP</b></center>
	
	</div> 
	
</div>
<!--<button class="w3-button" style="background: #082844;color:aliceblue;position:fixed;bottom:10px;right:1px;" onclick="printDiv('MyTable')"><i class="fa fa-print" style="color:;"></i></button>-->
<div class="image-container">
     <!--   <img src="../imagez/un.png" alt="un"><img src="../imagez/coat_of_arms.png" alt="Image 2"> -->
</div>

<script>
function printDiv(divID) {
										//Get the HTML of div
										var divElements = document.getElementById("page_data").innerHTML;
										//Get the HTML of whole page
										var oldPage = document.body.innerHTML;
										//Reset the page's HTML with div's HTML only
										document.body.innerHTML = 
										  "<html><head><title></title></head><body>" + 
										  divElements + "</body>";
										//Print Page
										window.print();
										//Restore orignal HTML
										
										document.body.innerHTML = oldPage;window. location. reload();
										

									}
</script>