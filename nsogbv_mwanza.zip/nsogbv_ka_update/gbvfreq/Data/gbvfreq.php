<!DOCTYPE html>

	<script src="../dist/apexcharts/dist/apexcharts.js"></script>
<html lang="en">
  <head>

 
 

  </head>

  <body>
     <div id="chartfreq" class="Piechart"></div>

    <script>
      
        var options = {
          series: [
		  
		  <?php
$query  = "select * from (select (CASE
 WHEN  a15 = 1  THEN 'Yes, 1 time'   
 WHEN  a15 = 2  THEN 'Yes, 2 times'
 WHEN  a15 = 3  THEN 'Yes, 3 times'
  WHEN  a15 = 4  THEN 'Yes, 4 times or more'
WHEN  a15 = 5  THEN 'Never happened'
 END) freq, count(*) total
from sgbv.gbv_cases2  group by freq) as temp4 where freq is not null";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"$total,"; 
}

?>  	  
		  ],
          chart: {
          width: 350,
          type: 'pie',
        },
		legend: {
              position: 'bottom',
            },
        labels: [
		
		
		
		<?php
$query  = "select * from (select (CASE
 WHEN  a15 = 1  THEN 'Yes, 1 time'   
 WHEN  a15 = 2  THEN 'Yes, 2 times'
 WHEN  a15 = 3  THEN 'Yes, 3 times'
  WHEN  a15 = 4  THEN 'Yes, 4 times or more'
WHEN  a15 = 5  THEN 'Never happened'
 END) freq, count(*) total
from sgbv.gbv_cases2  group by freq) as temp4 where freq is not null";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);



echo"'$freq',"; 
}

?>
		
		],
        responsive: [{
          breakpoint: 380,
          options: {
            chart: {
              width: 380
            },
            legend: {
              position: 'bottom'
            }
          }
        }],
        dataLabels: {
          formatter(val, opts) {
            const name = opts.w.globals.labels[opts.seriesIndex]
            return [name, val.toFixed(1) + '%']
          }
        },
        legend: {
          show: false
        },
        plotOptions: {
          pie: {
            dataLabels: {
              offset: -15
            }
          }
		}
        };

        var chart = new ApexCharts(document.querySelector("#chartfreq"), options);
        chart.render();
      
      
    </script>

    
  </body>
</html>