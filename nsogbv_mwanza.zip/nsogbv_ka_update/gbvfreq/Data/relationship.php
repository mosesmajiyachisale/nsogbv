

	<script src="../dist/apexcharts/dist/apexcharts.js"></script>



<!----end--->

  
     <div id="chartabrel"></div>

    <script>
      
        var options = {
          series: [{name:'Cases',
          data: [  
		  <?php
$query  = "
select (case when a14 = 1 then 'Spouse'
           when a14  = 2 then 'Father'
          when a14  = 3 then 'Other'
		 when a14  = 4 then 'Neigbour'
          when a14  = 5 then 'Stranger'
          else 'Unknown'
End) relationship, count(*) total
 from sgbv.gbv_cases2 group by relationship";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"$total,"; 
}

?>  
		  
		  ]
        }],
          chart: {
          type: 'bar',
          height: 350
        },
        plotOptions: {
          bar: {
            horizontal: true,
          }
        },
        dataLabels: {
          enabled: true
        },
        xaxis: {
          categories: [
		  
		  
		 
			
			
			
			<?php
$query  = "
select (case when a14 = 1 then 'Spouse'
           when a14  = 2 then 'Father'
          when a14  = 3 then 'Other'
		 when a14  = 4 then 'Neigbour'
          when a14  = 5 then 'Stranger'
          else 'Unknown'
End) relationship, count(*) total
 from sgbv.gbv_cases2 group by relationship";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"'$relationship',"; 
}

?>  
			
			
          ],
        }
        };

        var chart = new ApexCharts(document.querySelector("#chartabrel"), options);
        chart.render();
      
      
    </script>


    
  </body>
</html>



