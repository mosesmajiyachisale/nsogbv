
  <body>
     <div id="chartvillagemhgmz" class="Piechart"></div>

    <script>
      
        var options = {
          series: [
		  
		  <?php
$query  = "SELECT  CASE 
        WHEN f1 = 1 THEN 'Yes' 
        WHEN f1 = 2 THEN 'No'
        ELSE 'Unknown'
        END resolve, count(*) total
        FROM sgbv.searcher  group by  resolve";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"$total,"; 
}

?>  	  
		  ],
          chart: {
          width: 350,
          type: 'pie',
        },
		legend: {
              position: 'bottom',
            },
        labels: [
		
		
		
		<?php
$query  = "SELECT  CASE 
        WHEN f1 = 1 THEN 'Yes' 
        WHEN f1 = 2 THEN 'No'
        ELSE 'Unknown'
        END resolve, count(*) total
        FROM sgbv.searcher  group by  resolve";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);



echo"'$resolve',"; 
}

?>
		
		],
        responsive: [{
          breakpoint: 1600,
          options: {
            chart: {
              width: 240
            },
            legend: {
              position: 'bottom'
            }
          }
        }],
        dataLabels: {
          formatter(val, opts) {
            const name = opts.w.globals.labels[opts.seriesIndex]
            return [name, val.toFixed(1) + '%']
          }
        },
        legend: {
          show: false
        },
        plotOptions: {
          pie: {
            dataLabels: {
              offset: -15
            }
          }
		}
        };

        var chart = new ApexCharts(document.querySelector("#chartvillagemhgmz"), options);
        chart.render();
      
      
    </script>

    
  </body>
</html>