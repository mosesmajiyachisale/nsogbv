
     <div id="chartabreasonmhgmz"></div>

    <script>
       
        var options = {
          series: [{name:'cases',
          data: [  
		  <?php
$query  = "
select * from (select (CASE
 WHEN  a12 = 1  THEN 'Had perpetrator threats '   
 WHEN  a12 = 2  THEN 'Family threats '
 WHEN  a12 = 3  THEN 'Fear of loss of place/family belonging'
  WHEN  a12 = 4  THEN 'Did not report late '
WHEN  a12 = 5  THEN 'Other'
 END) freq, count(*) total
from sgbv.searcher  group by  freq) as temp4 where freq is not null";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"$total,"; 
}

?>  
		  
		  ]
        }],
          chart: {
          type: 'bar',
          height: 350
        },
        plotOptions: {
          bar: {
            horizontal: false,
          }
        },
        dataLabels: {
          enabled:true
        },
        xaxis: {
          categories: [
		  
		  
		 
			
			
			
			<?php
$query  = "select * from (select (CASE
 WHEN  a12 = 1  THEN 'Had perpetrator threats '   
 WHEN  a12 = 2  THEN 'Family threats '
 WHEN  a12 = 3  THEN 'Fear of loss of place/family belonging'
  WHEN  a12 = 4  THEN 'Did not report late '
WHEN  a12 = 5  THEN 'Other'
 END) freq, count(*) total
from sgbv.searcher  group by  freq) as temp4 where freq is not null";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"'$freq',"; 
}

?>  
			
			
          ],
        }
        };

        var chart = new ApexCharts(document.querySelector("#chartabreasonmhgmz"), options);
        chart.render();
    </script>
  </body>
</html>



