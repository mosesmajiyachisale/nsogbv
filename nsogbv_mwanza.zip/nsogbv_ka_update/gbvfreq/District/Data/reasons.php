

<?php $District=$_GET["d"];?>
	<script src="../../dist/apexcharts/dist/apexcharts.js"></script>



<!----end--->

  
     <div id="chartabreasonmhgmz"></div>

    <script>
       
        var options = {
          series: [{name:'Cases',
          data: [  
		  <?php
$query  = "
select * from (select A4_DISTRICT, (CASE
 WHEN  a12 = 1  THEN 'Had perpetrator threats '   
 WHEN  a12 = 2  THEN 'Family threats '
 WHEN  a12 = 3  THEN 'Fear of loss of place/family belonging'
  WHEN  a12 = 4  THEN 'Did not report late '
WHEN  a12 = 5  THEN 'Other'
 END) freq, count(*) total
from sgbv.gbv_cases2  group by A4_DISTRICT, freq) as temp4 where A4_DISTRICT='$District' and freq is not null";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"$total,"; 
}

?>  
		  
		  ]
        }],
          chart: {
          type: 'bar',
          height: 350
        },
        plotOptions: {
          bar: {
            horizontal: false,
          }
        },
        dataLabels: {
          enabled: false
        },
        xaxis: {
          categories: [
		  
		  
		 
			
			
			
			<?php
$query  = "select * from (select A4_DISTRICT, (CASE
 WHEN  a12 = 1  THEN 'Had perpetrator threats '   
 WHEN  a12 = 2  THEN 'Family threats '
 WHEN  a12 = 3  THEN 'Fear of loss of place/family belonging'
  WHEN  a12 = 4  THEN 'Did not report late '
WHEN  a12 = 5  THEN 'Other'
 END) freq, count(*) total
from sgbv.gbv_cases2  group by A4_DISTRICT, freq) as temp4 where A4_DISTRICT='$District' and freq is not null";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"'$freq',"; 
}

?>  
			
			
          ],
        }
        };

        var chart = new ApexCharts(document.querySelector("#chartabreasonmhgmz"), options);
        chart.render();
    </script>
  </body>
</html>



