<?php
	include("Data/value.php");
    require("Data/graph_data.php")
?>

<!-- ============================================================== -->
<!-- Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<div class="row page-titles">
    <div class="col-md-7 align-self-center">
        <h3 class="text-themecolor mb-0">Health Center SGBV Dashboard</h3>
        <ol class="breadcrumb mb-0">
            <li class="breadcrumb-item"><a href="../">Home</a></li>
            <li class="breadcrumb-item active">Health Centers</li>
        </ol>
    </div>
    <div class="col-md-5 align-self-center d-none d-md-block">
        <div class="d-flex mt-2 justify-content-end">
            <div class="d-flex mr-3 ml-2">
                <div class="chart-text mr-2">
                    <!-- <h6 class="mb-0"><small>HARMFUL PRACTICES</small></h6>-->
                    <h4 class="mt-0 text-info">
                        <?php //echo value("SELECT SUM(GBVCasesTreated) as Value FROM `hospitalinfo`");?>
                </div>
            </div>
            <div class="d-flex ml-2">
                <div class="chart-text mr-2">
                    <h6 class="mb-0"><small>NATIONAL SGBV CASES</small></h6>
                    <h4 class="mt-0 text-primary"><?php echo $allCases; ?>
                    </h4>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ============================================================== -->
<!-- End Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- Container fluid  -->
<!-- ============================================================== -->
<div class="container-fluid">
    <!-- Row -->
    <div class="row">
        <!-- Column --
                    <div class="col-lg-6 col-md-12">
                        <div class="card">
                            <div class="card-body">
                                    <div class="col-12">
                                            <div>
                                                <h3 class="card-title">SGBV Cases</h3>
                                           
                                            </div>
                                            <?php //include("Data/Cases_Per_District.php");?>
                                    </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <h3 class="card-title">Health Centers <a href="#" onclick= "document.getElementById('links').style.display='block'" class="ti-menu"></a></h3>
                                 <div class="col-12">   
                                        <?php //include("Data/Hospitals_District.php");?> 
                                        <?php //include("Data/District_Hospitals_Links.php");?>
                                </div>
                            </div>
                        </div>
                    </div>-->
    </div>
    <!-- Row -->
    <div class="row">
        <!-- Column -->
        <div class="col-md-6 col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="col-12">
                        <div>
                            <h3 class="card-title">Demographics</h3>
                            <!--   <h6 class="card-subtitle">Pie Chart</h6> -->
                        </div>
                        <div class="row" style="padding-bottom:2%">
                            <div class="col-md-3">
                                <div id="genderStats"></div>
                            </div>
                            <div class="col-md-3">
                                <div id="maritalStatus"></div>
                            </div>
                            <div class="col-md-3">
                                <div id="occurrence"></div>
                            </div>
                            <div class="col-md-3">
                                <div id="abuseType"></div>
                            </div>


                        </div>
                        <br />
                        <div class="row">
                            <div class="col-md-6">
                                <div id="occupation"></div>
                            </div>
                            <div class="col-md-6">
                                <div id="referral"></div>
                            </div>
                            <div class="col-md-6">
                                <div id="districtStats"></div>
                            </div>
                            <div class="col-md-6">
                                <div id="relationStats"></div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <!-- Column -->
        <div class="col-md-6 col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="col-12">
                        <div>
                            <h3 class="card-title">Test Results</h3>
                            <!--   <h6 class="card-subtitle">Pie Chart</h6> -->
                        </div>
                        <?php include("Data/Late_Access.php");?>
                    </div>
                </div>
            </div>
        </div>
        <!--
                    <div class="col-md-6 col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <h3 class="card-title">Fresh Samples</h3>
                                 <div class="col-12">   
                                        <?php // include("Data/Fresh_Samples.php");?> 
                                </div>
                            </div>
                        </div>
                    </div>-->
    </div>

    <div class="row" style="width: 100%">
        <div class="col-md-6 col-md-12">
            <div class="card">
                <div class="card-body">
                    <!--   <div class="d-flex flex-wrap"> -->
                    <div>
                        <h3 class="card-title">Medical Service Access Rate </h3>
                        <!--  <h6 class="card-subtitle">Overview of Newsletter Campaign</h6> -->
                    </div>
                    <div class="ml-auto align-self-center">
                        <?php include("Data/Medical_Service_Access_Rate.php"); ?>
                    </div>
                    <!--   </div> -->
                    <!--   <div class="campaign ct-charts"></div> -->

                </div>
            </div>
        </div>

        <div class="col-md-8">
            <div class="card">
                <div class="card-body">

                    <div>
                        <h3 class="card-title">Cases by Traditional Authority</h3>

                    </div>
                    <div class="ml-auto align-self-center">
                        <div id="taCode"></div>
                    </div>

                </div>
            </div>
        </div>
        <div class="col-md-8">
            
        </div>
    </div>


</div>

<br />
</div>


<script>
var options = {
    series: [<?php echo  tests('a5','1', $con).",". tests('a5','2', $con);?>],
    chart: {
        width: 300,
        title: "Gender",
        type: 'pie'
    },
    labels: {
        display: false
    },
    labels: ['Male', 'Female'],
    legend: {
        position: 'bottom'
    },
    title: {
        text: "Gender",
        align: 'center',
        margin: 20,
        style: {
            fontSize: '14px',
            fontWeight: 'bold',
            color: 'grey'
        },
    }
};
var chart = new ApexCharts(document.querySelector("#genderStats"), options);
chart.render();



var options = {
    series: [{
        data: [
            <?php echo  tests('a7','103', $con).",". tests('a7','105', $con).",". tests('a7','203', $con).",". tests('a7','204', $con).",". tests('a7','302', $con).",". tests('a7','311', $con);?>
        ],
        name: 'Cases'
    }],

    chart: {
        type: 'bar',
        height: 300
    },

    plotOptions: {
        bar: {
            horizontal: false,
        }
    },
    dataLabels: {
        enabled: false
    },
    xaxis: {
        categories: ["Nkhata Bay", "Mzimba", "Ntchisi", "Dowa", "Machinga", "Nsanje"],
    },
    title: {
        text: "District Stats",
        align: 'center',
        margin: 20,
        style: {
            fontSize: '14px',
            fontWeight: 'bold',
            color: 'grey'
        },
    }
};

var chart = new ApexCharts(document.querySelector("#districtStats"), options);
chart.render();


var options = {
    series: [{
        data: [
            <?php echo  tests('a10','1', $con).",". tests('a10','2', $con).",". tests('a10','3', $con).",". tests('a10','4', $con).",". tests('a10','5', $con).",". tests('a10','6', $con);?>
        ],
        name: 'Cases'
    }],

    chart: {
        type: 'bar',
        height: 300
    },

    plotOptions: {
        bar: {
            horizontal: false,
        }
    },
    dataLabels: {
        enabled: false
    },
    xaxis: {
        categories: ["Spouse", "Uncle", "Father", "Neighbor", "Stranger", "Other"],
    },
    title: {
        text: "Relation with Perpetrator",
        align: 'center',
        margin: 20,
        style: {
            fontSize: '14px',
            fontWeight: 'bold',
            color: 'grey'
        },
    }
};

var chart = new ApexCharts(document.querySelector("#relationStats"), options);
chart.render();

var options = {
    series: [
        <?php echo  tests('a12','1', $con).",". tests('a12','2', $con).",". tests('a12','4', $con).",". tests('a12','5', $con);?>
    ],
    chart: {
        width: 300,
        title: "Marital Status",
        type: 'donut'
    },
    labels: {
        display: false
    },
    labels: ['Never Married', 'Married', 'Divorced/Separated', 'Widow/Widower'],
    legend: {
        position: 'bottom'
    },
    title: {
        text: "Marital Status",
        align: 'center',
        margin: 20,
        style: {
            fontSize: '14px',
            fontWeight: 'bold',
            color: 'grey'
        },
    }
};
var chart = new ApexCharts(document.querySelector("#maritalStatus"), options);
chart.render();


var options = {
    series: [
        <?php echo  tests('a13','1', $con).",". tests('a13','2', $con);?>
    ],
    chart: {
        width: 300,
        title: "First Occurrence? ",
        type: 'pie'
    },
    labels: {
        display: false
    },
    labels: ['Yes', 'No'],
    legend: {
        position: 'bottom'
    },
    title: {
        text: "First Occurrence?",
        align: 'center',
        margin: 20,
        style: {
            fontSize: '14px',
            fontWeight: 'bold',
            color: 'grey'
        },
    }
};
var chart = new ApexCharts(document.querySelector("#occurrence"), options);
chart.render();


var options = {
    series: [{
        data: [
            <?php echo  tests('a17','1', $con).",". tests('a17','2', $con).",". tests('a17','3', $con).",". tests('a17','4', $con).",". tests('a17','5', $con).",". tests('a17','6', $con);?>
        ],
        name: 'Cases'
    }],

    chart: {
        type: 'bar',
        height: 300
    },

    plotOptions: {
        bar: {
            horizontal: false,
        }
    },
    dataLabels: {
        enabled: false
    },
    xaxis: {
        categories: ["Employer", "Self employed", "Public service", "Private service", "unpaid family worker",
            "Student"
        ],
    },
    title: {
        text: "Victim Occupation Status",
        align: 'center',
        margin: 20,
        style: {
            fontSize: '14px',
            fontWeight: 'bold',
            color: 'grey'
        },
    }
};
var chart = new ApexCharts(document.querySelector("#occupation"), options);
chart.render();

var options = {
    series: [{
        data: [
            <?php echo  tests('b1','1', $con).",". tests('b1','2', $con).",". tests('b1','3', $con).",". tests('b1','4', $con).",". tests('b1','5', $con).",". tests('b1','6', $con);?>
        ],
        name: 'Cases'
    }],

    chart: {
        type: 'bar',
        height: 300
    },

    plotOptions: {
        bar: {
            horizontal: false,
        }
    },
    dataLabels: {
        enabled: false
    },
    xaxis: {
        categories: ["Police", "School", "Self", "Health Facility", "Community", "Other"],
    },
    title: {
        text: "Victim Referred from",
        align: 'center',
        margin: 20,
        style: {
            fontSize: '14px',
            fontWeight: 'bold',
            color: 'grey'
        },
    }
};
var chart = new ApexCharts(document.querySelector("#referral"), options);
chart.render();



var options = {
    series: [{
        data: [
            <?php echo  tests('b2','1', $con).",". tests('b2','2', $con).",". tests('b2','3', $con).",". tests('b2','4', $con).",". tests('b2','5', $con);?>
        ],
        name: 'Cases'
    }],

    chart: {
        type: 'bar',
        height: 300
    },

    plotOptions: {
        bar: {
            horizontal: false,
        }
    },
    dataLabels: {
        enabled: false
    },
    xaxis: {
        categories: ["Sexual Abuse", "Physical Assault", "Psychological", "Harmful Practices", "Other"],
    },
    title: {
        text: "Type of Abuse",
        align: 'center',
        margin: 20,
        style: {
            fontSize: '14px',
            fontWeight: 'bold',
            color: 'grey'
        },
    }
};
var chart = new ApexCharts(document.querySelector("#abuseType"), options);
chart.render();


var options = {
    series: [{
        data: [
            <?php echo  tests('a8','10301', $con).",". tests('a8','10302', $con).",". tests('a8','10303', $con).",". tests('a8','10304', $con).",
            ". tests('a8','10305', $con).",".tests('a8','10306', $con).",". tests('a8','10307', $con).",". tests('a8','10308', $con).",
            ". tests('a8','10309', $con).",". tests('a8','10310', $con).",". tests('a8','10311', $con).",". tests('a8','10312', $con).",". tests('a8','10501', $con).",
            ". tests('a8','10502', $con).",". tests('a8','10503', $con).",". tests('a8','10504', $con).",". tests('a8','10505', $con).",". tests('a8','10506', $con).",". tests('a8','10507', $con).",". tests('a8','10508', $con) ;?>
        ],
    }],
    chart: {
        type: 'bar',
        height: 550
    },
    plotOptions: {
        bar: {
            borderRadius: 4,
            horizontal: true,
        }
    },
    dataLabels: {
        enabled: false
    },
    xaxis: {
        categories: ['TA KABUNDULI', 'TA FUKAMAPIRI', 'TA MALENGA MZOMA', 'TA MALANDA', 'TA ZILAKOMA',
            'TA MANKHAMBIRA', 'TA FUKAMALAZA','TA MKUMBIRA ', 'TA MMBWANA', 'STA NYALUWANGA', 'TA TIMBIRI', 'TA MMBELWA', 'TA MTWALO', 'TA KAMPINGO SIBANDE',
            'TA JARAVIKUBA MUNHTALI', 'TA CHINDI','TA MZIKUBOLA ', 'TA MABULABO', 'STA KHOSOLO GWAZA GERE'
        ],
    }
};

var chart = new ApexCharts(document.querySelector("#taCode"), options);
chart.render();
</script>