<script>
//Medical Service Access Rate
<?PHP
//$check = mysqli_query($con,"")
$pep_yes = tests('d1', '1', $con);
$pep_no = tests('d1', '2', $con);
$pep_dec = tests('d1', '3', $con);
//--------------------------------
$et_yes = tests('d2', '1', $con);
$et_no = tests('d2', '2', $con);
$et_dec = tests('d2', '3', $con);
//--------------------------------
$ct_yes = tests('d3', '1', $con);
$ct_no = tests('d3', '2', $con);
$ct_dec = tests('d3', '3', $con);
//--------------------------------
$st_yes = tests('d4', '1', $con);
$st_no = tests('d4', '2', $con);
$st_dec = tests('d4', '3', $con);
//--------------------------------
?> 
</script>

<div class="row">
	<div class="col-md-8">

	<div id="Access_Rate"></div>
	</div>
	<div class="col-md-4">
	<div id="counsel"> </div>
	</div>
</div>



<script>
var options = {
    series: [{
        data: [<?php echo $pep_yes.",".$et_yes.",".$ct_yes.",".$st_yes;?>],
        name: 'Accessed'
    }, {
        data: [<?php echo $pep_no.",".$et_no.",".$ct_no.",".$st_no;?>],
        name: 'Not Accessed'
    }, {
        data: [<?php echo $pep_dec.",".$et_dec.",".$ct_dec.",".$st_dec;?>],
        name: 'Declined'
    }],

    chart: {
        type: 'bar',
        height: 350
    },

    plotOptions: {
        bar: {
            horizontal: false,
        }
    },
    dataLabels: {
        enabled: false
    },
    xaxis: {
        categories: ["PEP Treatment", ["Emergency", "Treatment"],
            ["Family", "Planning"], "STI Treatment"
        ],
    }
};

var chart = new ApexCharts(document.querySelector("#Access_Rate"), options);
chart.render();

var options = {
        series: [<?php echo  tests('d5','1', $con).",". tests('d5','2', $con);?>],
        chart: {
            width: 300,
            title: "Counseling done?",
            type: 'pie'
        },
        labels: {
            display: false
        },
        labels: ['Yes', 'No'],
        legend: {
            position: 'bottom'
        },
        title: {
            text: "Counseling done?",
            align: 'center',
            margin: 20,
            style: {
                fontSize: '14px',
                fontWeight: 'bold',
                color: 'grey'
            },
        }
    };
	var chart = new ApexCharts(document.querySelector("#counsel"), options);
chart.render();
</script>