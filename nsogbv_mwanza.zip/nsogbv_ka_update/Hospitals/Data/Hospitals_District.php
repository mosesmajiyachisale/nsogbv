<html>
<body >
<div id="Most_Hospitals"></div>			
<?PHP
	
	function NameofHospitals(){
		$Query="SELECT NameofHospital , GBVCasesTreated from hospitalinfo WHERE NameofHospital IN (SELECT DISTINCT NameofHospital FROM hospitalinfo) GROUP BY NameofHospital ORDER BY GBVCasesTreated DESC";
		$conn = new mysqli("localhost", "undpAdmin", "Malawi128","spotlight");
		$result = $conn->query($Query);
		$count=0;
		if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			$NameofHospital=$row["NameofHospital"];
			echo "'$NameofHospital',";
			$count++;
			if($count>=10)break;
		}
		}
	}
	function GBVCasesTreated(){
		$Query="SELECT NameofHospital , GBVCasesTreated from hospitalinfo WHERE NameofHospital IN (SELECT DISTINCT NameofHospital FROM hospitalinfo) GROUP BY NameofHospital ORDER BY GBVCasesTreated DESC";
		$conn = new mysqli("localhost", "undpAdmin", "Malawi128","spotlight");
		$result = $conn->query($Query);

		$count=0;
		if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			$GBVCasesTreated=$row["GBVCasesTreated"];
			echo "'$GBVCasesTreated',";
			$count++;
			if($count>=10)break;
		}
		}
	}
			?>
    <script>
      
        var options = {
          series: [{name:"Cases Treated",
          data: [<?php GBVCasesTreated();?>]
					}],
					  chart: {
					  type: 'bar',
					  height: 300
					},
					fill: {
			  colors: ['#7ddc1f', '#E91E63', '#9C27B0']
			},
        plotOptions: {
          bar: {
            horizontal: true,
          }
        },
        dataLabels: {
          enabled: false
        },
        xaxis: {
          categories: [<?php NameofHospitals();?>],
        }
        };

        var chart = new ApexCharts(document.querySelector("#Most_Hospitals"), options);
        chart.render();
      
      
    </script>
</body>
</html>
