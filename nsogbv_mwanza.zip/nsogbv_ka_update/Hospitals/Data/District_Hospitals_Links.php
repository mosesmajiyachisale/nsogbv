<?PHP
	
	function HospitalCases(){
		$Query="SELECT NameofHospital,NameofDistrict,SUM(GBVCasesTreated) as Cases from hospitalinfo WHERE NameofHospital IN (SELECT DISTINCT NameofHospital FROM hospitalinfo) GROUP BY NameofHospital order by Cases desc";
		$conn = new mysqli("localhost", "undpAdmin", "Malawi128","spotlight");
		$result = $conn->query($Query);

		if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			$Cases=$row["Cases"];
			$Hospital=$row["NameofHospital"];
			$District=$row["NameofDistrict"];
			echo "<tr>";
			echo "<td><a href='District/Hospital/?d=$District&h=$Hospital'>$Hospital</a></td>";
			echo "<td>$District</td>";
			echo "<td>$Cases</td>";
			echo "</tr>";
			
		}
		}
	}
			?>
					<!-- The Modal -->
					<div id="links" class="w3-modal">
					  <div class="w3-modal-content" style="height:70vh">
						<div class="w3-container">
						  <span onclick="document.getElementById('links').style.display='none'"
						  class="w3-button w3-display-topright">&times;</span>
						  <h1>Hospitals </h1>
						  <table class="w3-table-all  w3-animate-zoom">
							<tbody>
							<tr>
								<th class="">Hospital</th><th class="">District</th><th class=" w3-left">Cases Treated</th>
							</tr></tbody>
							<?php HospitalCases();?>
						   </table>
						</div>
					  </div>
					</div>