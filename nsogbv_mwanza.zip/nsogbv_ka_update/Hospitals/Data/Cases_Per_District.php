<?php 
function Cases(){
	$HospitalDistricts=Districts();
	$hospitalcases=0;
	foreach($HospitalDistricts as $ThisDistrict)
		{
			$Cases=Value("SELECT sum(`GBVCasesTreated`) as Value FROM `hospitalinfo` where NameofDistrict='$ThisDistrict';");
			echo $Cases.",";
					}
}
function District(){
	$HospitalDistricts=Districts();
	foreach($HospitalDistricts as $ThisDistrict)
	{
		echo "'".$ThisDistrict."',";
	}
}
?>

<div id="HospitalCases">
</div>
<script>
      
        var options = {
          series: [{name:'Cases Treated',
          data: [<?php Cases();?>]
					}],
					  chart: {
					  type: 'bar',
					  height: 300
					},
					fill: {
			  colors: ['#00b359']
			},
        plotOptions: {
          bar: {
            horizontal: false,
          }
        },
        dataLabels: {
          enabled: false
        },
        xaxis: {
          categories: [<?php District();?>],
        }
        };

        var chart = new ApexCharts(document.querySelector("#HospitalCases"), options);
        chart.render();
 </script>
