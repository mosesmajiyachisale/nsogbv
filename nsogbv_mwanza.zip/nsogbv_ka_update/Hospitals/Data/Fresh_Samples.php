<style>
#Medical {}

#Medical div {
    margin: auto;
}

#Forensic {}

#Forensic div {
    margin: auto;
}
</style>

<div class="row">
    <div id="pep" class="col s6"> </div>
    <div id="et" class="col s6"> </div>
    <div id="ct" class="col s6"> </div>
    <div id="st" class="col s6"> </div>
    <div id="cd" class="col s6"> </div>

</div>
<script src="dist/apexcharts/dist/apexcharts.js"></script>
<script>
//recorded Cout cases per district
var options = {
    series: [<?php echo  tests('d1','1', $con).",". tests('d1','2', $con).",".tests('d1','3', $con);?>],
    chart: {
        width: 250,
        type: 'donut',
    },
    labels: ['Yes', 'No','Declined'],
    legend: {
        position: 'bottom'
    },
    title: {
        text: "PEP Treatment",
        align: 'center',
        margin: 20,
        style: {
            fontSize: '14px',
            fontWeight: 'bold',
            color: 'grey'
        }
    }
};
var chart = new ApexCharts(document.querySelector("#pep"), options);
chart.render();


var options = {
    series: [<?php echo  tests('d2','1', $con).",". tests('d2','2', $con).",".tests('d2','3', $con);?>],
    chart: {
        width: 250,
        type: 'donut'
    },
    labels: {
        display: false
    },
    labels: ['Yes', 'No','Declined'],
    legend: {
        position: 'bottom'
    },
    title: {
        text: "Emergency Treatment",
        align: 'center',
        margin: 20,
        style: {
            fontSize: '14px',
            fontWeight: 'bold',
            color: 'grey'
        }
    }
};
var chart = new ApexCharts(document.querySelector("#et"), options);
chart.render();
</script>