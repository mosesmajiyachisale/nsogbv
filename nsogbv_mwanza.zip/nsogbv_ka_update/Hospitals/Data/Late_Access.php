<html>
<div>
    <style>
    #Prophylaxis_treatment {}

    #Prophylaxis_treatment div {
        margin: auto;
    }

    #Emergency_Contraception {}

    #Emergency_Contraception div {
        margin: auto;
    }
    </style>

    <div class="row">
        <div id="preg" class="col s6 ">
        </div>
        <div id="hiv" class="col s6">
        </div>
        <div id="vdrl" class="col s6 ">
        </div>
        <div id="sti" class="col s6">
        </div>
    </div>
    



    
    <script>
    //Late Access

    var options = {
        series: [<?php echo  tests('c1','1', $con).",". tests('c1','2', $con).",".tests('c1','3', $con).",". tests('c1','4', $con);?>],
        chart: {
            width: 300,
            type: 'donut',
        },
        labels: ['Positive', 'Negative', 'Not done', 'Not applicable'],
        legend: {
            position: 'bottom'
        },
        title: {
            text: "Pregancy test resukts",
            align: 'center',
            margin: 20,
            style: {
                fontSize: '14px',
                fontWeight: 'bold',
                color: 'grey'
            }
        }
    };
    var chart = new ApexCharts(document.querySelector("#preg"), options);
    chart.render();

    var options = {
        series: [<?php echo  tests('c2','1', $con).",". tests('c2','2', $con).",".tests('c2','3', $con).",". tests('c2','4', $con).",". tests('c2','5', $con);?>],
        chart: {
            width: 300,
            title: "HIV Test results",
            type: 'donut'
        },
        labels: {
            display: false
        },
        labels: ['Positive', 'Negative', 'Not done', 'Inconclusive','Not applicable'],
        legend: {
            position: 'bottom'
        },
        title: {
            text: "HIV Test results",
            align: 'center',
            margin: 20,
            style: {
                fontSize: '14px',
                fontWeight: 'bold',
                color: 'grey'
            },
        }
    };
    var chart = new ApexCharts(document.querySelector("#hiv"), options);
    chart.render();
	
	
	var options = {
        series: [<?php echo  tests('c3','1', $con).",". tests('c3','2', $con).",".tests('c3','3', $con).",". tests('c3','4', $con);?>],
        chart: {
            width: 300,
            title: "VDRL test results",
            type: 'donut'
        },
        labels: {
            display: false
        },
        labels: ['Positive', 'Negative', 'Not done', 'Inconclusive','Not applicable'],
        legend: {
            position: 'bottom'
        },
        title: {
            text: "VDRL test results",
            align: 'center',
            margin: 20,
            style: {
                fontSize: '14px',
                fontWeight: 'bold',
                color: 'grey'
            },
        }
    };
    var chart = new ApexCharts(document.querySelector("#vdrl"), options);
    chart.render();
	
	
	var options = {
        series: [<?php echo  tests('c4','1', $con).",". tests('c4','2', $con);?>],
        chart: {
            width: 300,
            title: "VDRL test done?",
            type: 'pie'
        },
        labels: {
            display: false
        },
        labels: ['Yes', 'No'],
        legend: {
            position: 'bottom'
        },
        title: {
            text: "VDRL test done?",
            align: 'center',
            margin: 20,
            style: {
                fontSize: '14px',
                fontWeight: 'bold',
                color: 'grey'
            },
        }
    };
    var chart = new ApexCharts(document.querySelector("#sti"), options);
    chart.render();
	
    </script>
    </body>

</html>