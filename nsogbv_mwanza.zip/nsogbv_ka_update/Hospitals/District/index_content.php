<?php
	include("../Data/value.php");
    $District=$_GET['d'];
    require("Data/graph_data.php");

    
    if($District=="Mzimba"){
        $dist = 103;
        //case type by TA
        /*
        $dist_data =  "TA Chindi, TA Jaravikuba Munthali,TA Khosolo Gwaza Jere, TA MMbelwa, TA Mabulabo, TA Mpherembe, TA Mtwalo, TA Mzikubola, TA,Mzukuzuku";
        $sa = tests('b2','1', $dist,$con).",". tests('b2','2', $dist,$con).",". tests('b2','3', $dist,$con).",". tests('b2','4', $dist,$con).",". tests('b2','5', $dist,$con);
        $pa=
        $Psy=
        $hp=
        $ot=*/
        
    }else if($District=="Nkhatabay"){
        $dist = 105;
    }
    else if($District=="Ntchisi"){
        $dist = 203;
    }else if($District=="Dowa"){
        $dist = 204;
    }
    else if($District=="Machinga"){
        $dist = 302;
    }
    else if($District=="Nsanje"){
        $dist = 311;
    }
    
    
    
?>
<!-- ============================================================== -->
<!-- Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<div class="row page-titles">
    <div class="col-md-7 align-self-center">
        <h3 class="text-themecolor mb-0">Health Center SGBV Dashboard <?php echo $_GET["d"];?></h3>
        <ol class="breadcrumb mb-0">
            <li class="breadcrumb-item"><a href="../../">Home</a></li>
            <li class="breadcrumb-item active"><a href="../">Health Centers</a></li>
            <li class="breadcrumb-item active"><?php echo $_GET["d"];?></li>
        </ol>
    </div>
    <div class="col-md-5 align-self-center d-none d-md-block">
        <div class="d-flex mt-2 justify-content-end">
            <div class="d-flex mr-3 ml-2">
                <div class="chart-text mr-2">
                    <h6 class="mb-0"><small>CASES TREATED</small></h6>
                    <h4 class="mt-0 text-info">
                        <?php $District=$_GET['d'];echo value("SELECT  SUM(`GBVCasesTreated`) as Value FROM `hospitalinfo` WHERE `NameofDistrict`='$District'");?>
                </div>
            </div>
            <div class="d-flex ml-2">
                <div class="chart-text mr-2">
                    <h6 class="mb-0"><small>DISTRICT SGBV CASES</small></h6>
                    <h4 class="mt-0 text-primary" id=""><?php echo $allCases;?></h4>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ============================================================== -->
<!-- End Bread crumb and right sidebar toggle -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- Container fluid  -->
<!-- ============================================================== -->
<div class="container-fluid">
    <!-- Row -->
    <!-- Row -->
    <div class="row">
        <!-- Column -->
        <div class="col-md-6 col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="col-12">
                        <div>
                            <h3 class="card-title">Demographics <?php echo $dist; ?></h3>
                            <!--   <h6 class="card-subtitle">Pie Chart</h6> -->
                            <?php echo  tests('a5','1', $dist,$dist,$con).",". tests('a5','2',$dist,$dist,$con);?>
                        </div>
                        <div class="row" style="padding-bottom:2%">
                            <div class="col-md-3">
                                <div id="genderStats"></div>
                            </div>
                            <div class="col-md-3">
                                <div id="maritalStatus"></div>
                            </div>
                            <div class="col-md-3">
                                <div id="occurrence"></div>
                            </div>
                            <div class="col-md-3">
                                <div id="abuseType"></div>
                            </div>


                        </div>
                        <br />
                        <div class="row">
                            <div class="col-md-6">
                                <div id="occupation"></div>
                            </div>
                            <div class="col-md-6">
                                <div id="relationStats"></div>
                            </div>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Column -->
        <div class="col-md-6 col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="col-12">
                        <div>
                            <h3 class="card-title">Referrals</h3>
                            <!--   <h6 class="card-subtitle">Pie Chart</h6> -->
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div id="referral"></div>
                            </div>
                            <div class="col-md-6">
                                <div id="referredTo"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <div class="row">
        <!-- Column -->
        <div class="col-md-6 col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="col-12">
                        <div>
                            <h3 class="card-title">Test Results</h3>
                            <!--   <h6 class="card-subtitle">Pie Chart</h6> -->
                        </div>
                        <div class="row">
        <div id="preg" class="col s6 ">
        </div>
        <div id="hiv" class="col s6">
        </div>
        <div id="vdrl" class="col s6 ">
        </div>
        <div id="sti" class="col s6">
        </div>
    </div>
                    </div>
                </div>
            </div>
        </div>
        <!--
                    <div class="col-md-6 col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <h3 class="card-title">Fresh Samples</h3>
                                 <div class="col-12">   
                                        <?php // include("Data/Fresh_Samples.php");?> 
                                </div>
                            </div>
                        </div>
                    </div>-->
    </div>




</div>



<script>
var options = {
    series: [<?php echo  tests('a5','1', $dist,$con).",". tests('a5','2',$dist,$con);?>],
    chart: {
        width: 300,
        title: "Gender",
        type: 'pie'
    },
    labels: {
        display: false
    },
    labels: ['Male', 'Female'],
    legend: {
        position: 'bottom'
    },
    title: {
        text: "Gender",
        align: 'center',
        margin: 20,
        style: {
            fontSize: '14px',
            fontWeight: 'bold',
            color: 'grey'
        },
    }
};
var chart = new ApexCharts(document.querySelector("#genderStats"), options);
chart.render();



var options = {
    series: [{
        data: [
            <?php echo  tests('a7','103', $dist,$con).",". tests('a7','105', $dist,$con).",". tests('a7','203', $dist,$con).",". tests('a7','204', $dist,$con).",". tests('a7','302', $dist,$con).",". tests('a7','311', $dist,$con);?>
        ],
        name: 'Cases'
    }],

    chart: {
        type: 'bar',
        height: 300
    },

    plotOptions: {
        bar: {
            horizontal: false,
        }
    },
    dataLabels: {
        enabled: false
    },
    xaxis: {
        categories: ["Nkhata Bay", "Mzimba", "Ntchisi", "Dowa", "Machinga", "Nsanje"],
    },
    title: {
        text: "District Stats",
        align: 'center',
        margin: 20,
        style: {
            fontSize: '14px',
            fontWeight: 'bold',
            color: 'grey'
        },
    }
};

var chart = new ApexCharts(document.querySelector("#districtStats"), options);
chart.render();


var options = {
    series: [{
        data: [
            <?php echo  tests('a10','1', $dist,$con).",". tests('a10','2', $dist,$con).",". tests('a10','3', $dist,$con).",". tests('a10','4', $dist,$con).",". tests('a10','5', $dist,$con).",". tests('a10','6', $dist,$con);?>
        ],
        name: 'Cases'
    }],

    chart: {
        type: 'bar',
        height: 300
    },

    plotOptions: {
        bar: {
            horizontal: false,
        }
    },
    dataLabels: {
        enabled: false
    },
    xaxis: {
        categories: ["Spouse", "Uncle", "Father", "Neighbor", "Stranger", "Other"],
    },
    title: {
        text: "Relation with Perpetrator",
        align: 'center',
        margin: 20,
        style: {
            fontSize: '14px',
            fontWeight: 'bold',
            color: 'grey'
        },
    }
};

var chart = new ApexCharts(document.querySelector("#relationStats"), options);
chart.render();

var options = {
    series: [
        <?php echo  tests('a12','1', $dist,$con).",". tests('a12','2', $dist,$con).",". tests('a12','4', $dist,$con).",". tests('a12','5', $dist,$con);?>
    ],
    chart: {
        width: 300,
        title: "Marital Status",
        type: 'donut'
    },
    labels: {
        display: false
    },
    labels: ['Never Married', 'Married', 'Divorced/Separated', 'Widow/Widower'],
    legend: {
        position: 'bottom'
    },
    title: {
        text: "Marital Status",
        align: 'center',
        margin: 20,
        style: {
            fontSize: '14px',
            fontWeight: 'bold',
            color: 'grey'
        },
    }
};
var chart = new ApexCharts(document.querySelector("#maritalStatus"), options);
chart.render();


var options = {
    series: [
        <?php echo  tests('a13','1', $dist,$con).",". tests('a13','2', $dist,$con);?>
    ],
    chart: {
        width: 300,
        title: "First Occurrence? ",
        type: 'pie'
    },
    labels: {
        display: false
    },
    labels: ['Yes', 'No'],
    legend: {
        position: 'bottom'
    },
    title: {
        text: "First Occurrence?",
        align: 'center',
        margin: 20,
        style: {
            fontSize: '14px',
            fontWeight: 'bold',
            color: 'grey'
        },
    }
};
var chart = new ApexCharts(document.querySelector("#occurrence"), options);
chart.render();


var options = {
    series: [{
        data: [
            <?php echo  tests('a17','1', $dist,$con).",". tests('a17','2', $dist,$con).",". tests('a17','3', $dist,$con).",". tests('a17','4', $dist,$con).",". tests('a17','5', $dist,$con).",". tests('a17','6', $dist,$con);?>
        ],
        name: 'Cases'
    }],

    chart: {
        type: 'bar',
        height: 300
    },

    plotOptions: {
        bar: {
            horizontal: false,
        }
    },
    dataLabels: {
        enabled: false
    },
    xaxis: {
        categories: ["Employer", "Self employed", "Public service", "Private service", "unpaid family worker",
            "Student"
        ],
    },
    title: {
        text: "Victim Occupation Status",
        align: 'center',
        margin: 20,
        style: {
            fontSize: '14px',
            fontWeight: 'bold',
            color: 'grey'
        },
    }
};
var chart = new ApexCharts(document.querySelector("#occupation"), options);
chart.render();

var options = {
    series: [{
        data: [
            <?php echo  tests('b1','1', $dist,$con).",". tests('b1','2', $dist,$con).",". tests('b1','3', $dist,$con).",". tests('b1','4', $dist,$con).",". tests('b1','5', $dist,$con).",". tests('b1','6', $dist,$con);?>
        ],
        name: 'Cases'
    }],

    chart: {
        type: 'bar',
        height: 300
    },

    plotOptions: {
        bar: {
            horizontal: false,
        }
    },
    dataLabels: {
        enabled: false
    },
    xaxis: {
        categories: ["Police", "School", "Self", "Health Facility", "Community", "Other"],
    },
    title: {
        text: "Victim Referred from",
        align: 'center',
        margin: 20,
        style: {
            fontSize: '14px',
            fontWeight: 'bold',
            color: 'grey'
        },
    }
};
var chart = new ApexCharts(document.querySelector("#referral"), options);
chart.render();

var options = {
    series: [{
        data: [
            <?php echo  tests('e1','1', $dist,$con).",". tests('e1','2', $dist,$con).",". tests('e1','3', $dist,$con).",". tests('e1','4', $dist,$con);?>
        ],
        name: 'Cases'
    }],

    chart: {
        type: 'bar',
        height: 300
    },

    plotOptions: {
        bar: {
            horizontal: false,
        }
    },
    dataLabels: {
        enabled: false
    },
    xaxis: {
        categories: ["Police", "Court", "Social Welfare", "Other"],
    },
    title: {
        text: "Victim Referred to",
        align: 'center',
        margin: 20,
        style: {
            fontSize: '14px',
            fontWeight: 'bold',
            color: 'grey'
        },
    }
};
var chart = new ApexCharts(document.querySelector("#referredTo"), options);
chart.render();

var options = {
    series: [{
        data: [
            <?php echo  tests('b2','1', $dist,$con).",". tests('b2','2', $dist,$con).",". tests('b2','3', $dist,$con).",". tests('b2','4', $dist,$con).",". tests('b2','5', $dist,$con);?>
        ],
        name: 'Cases'
    }],

    chart: {
        type: 'bar',
        height: 300
    },

    plotOptions: {
        bar: {
            horizontal: false,
        }
    },
    dataLabels: {
        enabled: false
    },
    xaxis: {
        categories: ["Sexual Abuse", "Physical Assault", "Psychological", "Harmful Practices", "Other"],
    },
    title: {
        text: "Type of Abuse",
        align: 'center',
        margin: 20,
        style: {
            fontSize: '14px',
            fontWeight: 'bold',
            color: 'grey'
        },
    }
};
var chart = new ApexCharts(document.querySelector("#abuseType"), options);
chart.render();


var options = {
    series: [{
        data: [
            <?php echo  tests('a8','10301', $dist,$con).",". tests('a8','10302', $dist,$con).",". tests('a8','10303', $dist,$con).",". tests('a8','10304', $dist,$con).",
            ". tests('a8','10305', $dist,$con).",".tests('a8','10306', $dist,$con).",". tests('a8','10307', $dist,$con).",". tests('a8','10308', $dist,$con).",
            ". tests('a8','10309', $dist,$con).",". tests('a8','10310', $dist,$con).",". tests('a8','10311', $dist,$con).",". tests('a8','10312', $dist,$con).",". tests('a8','10501', $dist,$con).",
            ". tests('a8','10502', $dist,$con).",". tests('a8','10503', $dist,$con).",". tests('a8','10504', $dist,$con).",". tests('a8','10505', $dist,$con).",". tests('a8','10506', $dist,$con).",". tests('a8','10507', $dist,$con).",". tests('a8','10508', $dist,$con) ;?>
        ],
    }],
    chart: {
        type: 'bar',
        height: 550
    },
    plotOptions: {
        bar: {
            borderRadius: 4,
            horizontal: true,
        }
    },
    dataLabels: {
        enabled: false
    },
    xaxis: {
        categories: ['TA KABUNDULI', 'TA FUKAMAPIRI', 'TA MALENGA MZOMA', 'TA MALANDA', 'TA ZILAKOMA',
            'TA MANKHAMBIRA', 'TA FUKAMALAZA', 'TA MKUMBIRA ', 'TA MMBWANA', 'STA NYALUWANGA', 'TA TIMBIRI',
            'TA MMBELWA', 'TA MTWALO', 'TA KAMPINGO SIBANDE',
            'TA JARAVIKUBA MUNHTALI', 'TA CHINDI', 'TA MZIKUBOLA ', 'TA MABULABO', 'STA KHOSOLO GWAZA GERE'
        ],
    }
};

var chart = new ApexCharts(document.querySelector("#taCode"), options);
chart.render();

//Test results


var options = {
        series: [<?php echo  tests('c1','1', $dist,$con).",". tests('c1','2', $dist,$con).",".tests('c1','3', $dist,$con).",". tests('c1','4', $dist,$con);?>],
        chart: {
            width: 300,
            type: 'donut',
        },
        labels: ['Positive', 'Negative', 'Not done', 'Not applicable'],
        legend: {
            position: 'bottom'
        },
        title: {
            text: "Pregancy test resukts",
            align: 'center',
            margin: 20,
            style: {
                fontSize: '14px',
                fontWeight: 'bold',
                color: 'grey'
            }
        }
    };
    var chart = new ApexCharts(document.querySelector("#preg"), options);
    chart.render();

    var options = {
        series: [<?php echo  tests('c2','1', $dist,$con).",". tests('c2','2', $dist,$con).",".tests('c2','3', $dist,$con).",". tests('c2','4', $dist,$con).",". tests('c2','5', $dist,$con);?>],
        chart: {
            width: 300,
            title: "HIV Test results",
            type: 'donut'
        },
        labels: {
            display: false
        },
        labels: ['Positive', 'Negative', 'Not done', 'Inconclusive','Not applicable'],
        legend: {
            position: 'bottom'
        },
        title: {
            text: "HIV Test results",
            align: 'center',
            margin: 20,
            style: {
                fontSize: '14px',
                fontWeight: 'bold',
                color: 'grey'
            },
        }
    };
    var chart = new ApexCharts(document.querySelector("#hiv"), options);
    chart.render();
	
	
	var options = {
        series: [<?php echo  tests('c3','1', $dist,$con).",". tests('c3','2', $dist,$con).",".tests('c3','3', $dist,$con).",". tests('c3','4', $dist,$con);?>],
        chart: {
            width: 300,
            title: "VDRL test results",
            type: 'donut'
        },
        labels: {
            display: false
        },
        labels: ['Positive', 'Negative', 'Not done', 'Inconclusive','Not applicable'],
        legend: {
            position: 'bottom'
        },
        title: {
            text: "VDRL test results",
            align: 'center',
            margin: 20,
            style: {
                fontSize: '14px',
                fontWeight: 'bold',
                color: 'grey'
            },
        }
    };
    var chart = new ApexCharts(document.querySelector("#vdrl"), options);
    chart.render();
	
	
	var options = {
        series: [<?php echo  tests('c4','1', $dist,$con).",". tests('c4','2', $dist,$con);?>],
        chart: {
            width: 300,
            title: "VDRL test done?",
            type: 'pie'
        },
        labels: {
            display: false
        },
        labels: ['Yes', 'No'],
        legend: {
            position: 'bottom'
        },
        title: {
            text: "VDRL test done?",
            align: 'center',
            margin: 20,
            style: {
                fontSize: '14px',
                fontWeight: 'bold',
                color: 'grey'
            },
        }
    };
    var chart = new ApexCharts(document.querySelector("#sti"), options);
    chart.render();
    
    
    
    //ta 
    var options = {
          series: [{
          name: 'Marine Sprite',
          data: [44, 55, 41, 37, 22, 43, 21]
        }, {
          name: 'Striking Calf',
          data: [53, 32, 33, 52, 13, 43, 32]
        }, {
          name: 'Tank Picture',
          data: [12, 17, 11, 9, 15, 11, 20]
        }, {
          name: 'Bucket Slope',
          data: [9, 7, 5, 8, 6, 9, 4]
        }, {
          name: 'Reborn Kid',
          data: [25, 12, 19, 32, 25, 24, 10]
        }],
          chart: {
          type: 'bar',
          height: 350,
          stacked: true,
        },
        plotOptions: {
          bar: {
            horizontal: true,
            dataLabels: {
              total: {
                enabled: true,
                offsetX: 0,
                style: {
                  fontSize: '13px',
                  fontWeight: 900
                }
              }
            }
          },
        },
        stroke: {
          width: 1,
          colors: ['#fff']
        },
        title: {
          text: 'Fiction Books Sales'
        },
        xaxis: {
          categories: [2008, 2009, 2010, 2011, 2012, 2013, 2014],
          labels: {
            formatter: function (val) {
              return val + "K"
            }
          }
        },
        yaxis: {
          title: {
            text: undefined
          },
        },
        tooltip: {
          y: {
            formatter: function (val) {
              return val + "K"
            }
          }
        },
        fill: {
          opacity: 1
        },
        legend: {
          position: 'top',
          horizontalAlign: 'left',
          offsetX: 40
        }
        };

        var chart = new ApexCharts(document.querySelector("#chart"), options);
        chart.render();
    
    
</script>


<!--
<div class="row">
                    
                    <div class="col-lg-6 col-md-12">
                        <div class="card">
                            <div class="card-body">
                                    <div class="col-12">
                                            <div>
                                                <h3 class="card-title">
												Cases Per Health Center
												<a href="#" onclick= "document.getElementById('links').style.display='block'" class="ti-menu"></a>
												</h3>
                                            
                                            </div>
                                            <?php // include("Data/District_Hospitals.php");?>
                                            <?php //include("Data/District_Hospitals_Links.php");?>
                                    </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <h3 class="card-title">Medical Service Access Rate</h3>
                                 <div class="col-12">   
                                        <?php //include("Data/District_Medical_Service_Access_Rate.php");?> 
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
				<div class="row">
                  
                    <div class="col-lg-6 col-md-12">
                        <div class="card">
                            <div class="card-body">
                                    <div class="col-12">
                                            <div>
                                                <h3 class="card-title">Late Access</h3>
                                             
                                            </div>
                                            <?php //include("Data/District_Late_Access.php");?>
                                    </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <h3 class="card-title">Fresh Samples</h3>
                                 <div class="col-12">   
                                        <?php // include("Data/District_Fresh_Samples.php");?> 
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12 col-md-12">
                        <div class="card">
                            <div class="card-body">
                             
                                    <div>
                                        <h3 class="card-title">Cases Treated Over Time </h3>
                                     
                                    </div>
                                    <div class="ml-auto align-self-center">
                                        <?php //include("Data/District_Timeline.php"); ?>
                                    </div>
                

                            </div>
                        </div>
                    </div>
					
</div>-->