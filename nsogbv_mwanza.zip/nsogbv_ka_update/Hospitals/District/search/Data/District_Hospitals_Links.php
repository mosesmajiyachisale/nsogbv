<?PHP
	
	function HospitalCases(){
		$District=$_GET["d"];
		$Query="SELECT NameofHospital,SUM(GBVCasesTreated) as Cases from searcher2 WHERE NameofHospital IN (SELECT DISTINCT NameofHospital FROM searcher2 WHERE NameofDistrict='$District') GROUP BY NameofHospital";
		$conn = new mysqli("localhost", "undpAdmin", "Malawi128","spotlight");
		$result = $conn->query($Query);

		if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			$Cases=$row["Cases"];
			$to="";$from="";
			if(isset($_POST["from"]))$from=$_POST['from'];
			if(isset($_POST["to"]))$to=$_POST['to'];
			$Hospital=$row["NameofHospital"];
			echo "<tr>";
			echo "<td><a href='../Hospital/search/?d=$District&h=$Hospital&from=$from&to=$to'>$Hospital</a></td>";
			echo "<td>$Cases</td>";
			echo "</tr>";
			
		}
		}
	}
			?>
					<!-- The Modal -->
					<div id="links" class="w3-modal">
					  <div class="w3-modal-content" style="height:70vh">
						<div class="w3-container">
						  <span onclick="document.getElementById('links').style.display='none'"
						  class="w3-button w3-display-topright">&times;</span>
						  <h1>Hospitals </h1>
						  <table class="w3-table-all  w3-animate-zoom">
							<tbody>
							<tr>
								<th class="">Hospital</th><th class=" w3-left">Cases</th>
							</tr></tbody>
							<?php HospitalCases();?>
						   </table>
						</div>
					  </div>
					</div>