<html>
<body >
<div id="District_Hospitals">
</div>
			
			
<?PHP
	
	function DistrictHospitals(){
		$District=$_GET["d"];
		$Query="SELECT NameofHospital,SUM(GBVCasesTreated) as Cases from searcher2 WHERE NameofHospital IN (SELECT DISTINCT NameofHospital FROM searcher2 WHERE NameofDistrict='$District') GROUP BY NameofHospital";
		$conn = new mysqli("localhost", "undpAdmin", "Malawi128","spotlight");
		$result = $conn->query($Query);

		if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			$NameofHospital=$row["NameofHospital"];
			echo "'$NameofHospital',";
			
		}
		}
	}
	function Cases(){
		$District=$_GET["d"];
		$Query="SELECT NameofHospital,SUM(GBVCasesTreated) as Cases from searcher2 WHERE NameofHospital IN (SELECT DISTINCT NameofHospital FROM searcher2 WHERE NameofDistrict='$District') GROUP BY NameofHospital";
		$conn = new mysqli("localhost", "undpAdmin", "Malawi128","spotlight");
		$result = $conn->query($Query);

		if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			$Cases=$row["Cases"];
			echo "'$Cases',";
			
		}
		}
	}
			?>
<script>
      
        var options = {
          series: [{name:"Cases Treated",
          data: [<?php Cases();?>]
					}],
					  chart: {
					  type: 'bar',
					  height: 300
					},
					fill: {
			  colors: ['#00b359']
			},
        plotOptions: {
          bar: {
            horizontal: true,
          }
        },
        dataLabels: {
          enabled: false
        },
        xaxis: {
          categories: [<?php DistrictHospitals();?>],
        }
        };

        var chart = new ApexCharts(document.querySelector("#District_Hospitals"), options);
        chart.render();
      
      
    </script>
