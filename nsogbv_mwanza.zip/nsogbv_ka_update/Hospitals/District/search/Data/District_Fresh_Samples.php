<?php 
					
					function FreshSamplesValue($ThisQuery){
							$District=$_GET["d"];
							$conn = new mysqli("localhost", "undpAdmin", "Malawi128","spotlight");
							$ThisValue=0;
							$result = $conn->query($ThisQuery);
							if ($result->num_rows > 0) {
								// output data of each row
								while($row = $result->fetch_assoc()) {
									$ThisValue= $row["Value"];
									if($ThisValue=="")$ThisValue=0;
								}
							}
							$conn->close();
							return $ThisValue;
						}
						$Forensic=FreshSamplesValue("SELECT SUM(ProphylaxisTreatmentForHIVAIDSSTILateAccess) as Value FROM `searcher2` WHERE NameofDistrict='$District'");
						$Medical=FreshSamplesValue("SELECT SUM(EmergencyContraceptiveLateAccess) as Value FROM `searcher2` WHERE NameofDistrict='$District'");
						$Total=LateAccessValue("SELECT SUM(GBVCasesTreated) as Value FROM `searcher2` WHERE NameofDistrict='$District'");
		?>
<html>
<body >
<div id="Medical" class="w3-col s6">
</div>
<div id="Forensic" class="w3-col s6">
</div>
<script src="dist/apexcharts/dist/apexcharts.js"></script>
<script>
//recorded Cout cases per district
        var options = {
          series: [<?php echo $Medical.",".($Total-$Medical);?>],
          chart: {
          width: 250,
          type: 'donut',
        },
        labels: ['Yes','No']
		,legend: {
              position: 'bottom'
            },
			title: {
			text: "Medical Samples",
			align: 'center',
			margin: 20,
			style: {
			  fontSize:  '14px',
			  fontWeight:  'bold',
			  color:  'grey'
			}}};
		var chart = new ApexCharts(document.querySelector("#Medical"), options);
        chart.render();
        
		
		var options = {
          series: [<?php echo $Forensic.",".($Total-$Forensic);?>],
          chart: {
          width: 250,
		  type: 'donut'
        },labels: {
              display: false
            },
        labels: ['Yes','No'],
		legend: {
              position: 'bottom'
            },
			title: {
			text: "Forensic Samples",
			align: 'center',
			margin: 20,
			style: {
			  fontSize:  '14px',
			  fontWeight:  'bold',
			  color:  'grey'
			}}};
		var chart = new ApexCharts(document.querySelector("#Forensic"), options);
        chart.render();
		document.getElementById("hospitalcases").innerHTML=<?php echo $Total;?>;
</script>
</body>
</html>
