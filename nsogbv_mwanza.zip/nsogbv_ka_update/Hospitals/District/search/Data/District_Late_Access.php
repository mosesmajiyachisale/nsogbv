<html>
<body >
<div id="Prophylaxis_treatment" class="w3-col s6">
</div>
<div id="Emergency_Contraception" class="w3-col s6">
</div>
<script src="dist/apexcharts/dist/apexcharts.js"></script>
<script>
//Late Access
        <?php 
					
					function LateAccessValue($ThisQuery){
							$conn = new mysqli("localhost", "undpAdmin", "Malawi128","spotlight");
							$ThisValue=0;
							$result = $conn->query($ThisQuery);
							if ($result->num_rows > 0) {
								// output data of each row
								while($row = $result->fetch_assoc()) {
									$ThisValue= $row["Value"];
									if($ThisValue=="")$ThisValue=0;
								}
							}
							$conn->close();
							return $ThisValue;
						}
						$District=$_GET["d"];
						$Prophylaxis=LateAccessValue("SELECT SUM(ProphylaxisTreatmentForHIVAIDSSTILateAccess) as Value FROM `searcher2` WHERE NameofDistrict='$District'");
						$EC=LateAccessValue("SELECT SUM(EmergencyContraceptiveLateAccess) as Value FROM `searcher2` WHERE NameofDistrict='$District'");
						$Total=LateAccessValue("SELECT SUM(GBVCasesTreated) as Value FROM `searcher2` WHERE NameofDistrict='$District'");
		?>
		var options = {
          series: [<?php echo $Prophylaxis.",".($Total-$Prophylaxis);?>],
          chart: {
		  width: 250,
          type: 'donut',
        },
        labels: ['Yes','No']
		,legend: {
              position: 'bottom'
            },
			title: {
			text: "Prophylaxis Treatment",
			align: 'center',
			margin: 20,
			style: {
			  fontSize:  '14px',
			  fontWeight:  'bold',
			  color:  'grey'
			}}
		};
		var chart = new ApexCharts(document.querySelector("#Prophylaxis_treatment"), options);
        chart.render();
        
		
		var options = {
          series: [<?php echo $EC.",".($Total-$EC);?>],
          chart: {
          width: 250,
		  type: 'donut'
        },labels: {
              display: false
            },
        labels: ['Yes','No'],
		legend: {
              position: 'bottom'
            },
			title: {
			text: "Emergency Contraception",
			align: 'center',
			margin: 20,
			style: {
			  fontSize:  '14px',
			  fontWeight:  'bold',
			  color:  'grey'
			},
		}};
		var chart = new ApexCharts(document.querySelector("#Emergency_Contraception"), options);
        chart.render();
</script>
</body>
</html>
