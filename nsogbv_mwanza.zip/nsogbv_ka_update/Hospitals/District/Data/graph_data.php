<?php
$host = "localhost";
$user = "pillar5";
$password = "spotLight@5";
$dbname = "sgbv";

$con = mysqli_connect($host, $user, $password, $dbname);

if (!$con) {
 die("Connection failed: " . mysqli_connect_error());
}

function tests($table, $test_result,$district,$con) {
    $escaped_table = mysqli_real_escape_string($con, $table);
    $escaped_test_result = mysqli_real_escape_string($con, $test_result);
    $query = "SELECT COUNT(*) AS count FROM hospital_data WHERE $escaped_table = '$escaped_test_result' AND a7='$district'";
    
    $q = mysqli_query($con, $query);
    if ($q) {
        $result = mysqli_fetch_assoc($q);
        return $result['count'];
    } else {
        echo mysqli_error($con);
    }
}



$result = mysqli_query($con, "SELECT count(*) as count FROM hospital_data WHERE a7='$dist'");
$row = mysqli_fetch_assoc($result);
$allCases = $row['count'];




?>



<script src="dist/apexcharts/dist/apexcharts.js"></script>

