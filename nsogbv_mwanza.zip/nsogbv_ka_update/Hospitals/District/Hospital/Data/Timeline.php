


<?php 
	$_GET["Starting_Month"]="";
	function TimelineValue2($Query){
		$Query;
		$conn = new mysqli("localhost", "undpAdmin", "Malawi128","spotlight");
		$ThisValue=1;
		$result = $conn->query($Query);

		if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			$ThisValue=$row["Value"];
		}
		}
		return $ThisValue;
	}
	function Period2(){
		$conn = new mysqli("localhost", "undpAdmin", "Malawi128","spotlight");
		$Query="SELECT date FROM `hospitalinfo` ORDER BY date asc;";
		$result = $conn->query($Query);
		$month="";
		if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			$date=$row["date"];
			
			$mydate=date("M Y", strtotime($date));
			
			if($mydate!=$month){echo "['".$mydate."'],";}
			
			$month=$mydate;
			
			if($_GET["Starting_Month"]==""){$_GET["Starting_Month"]=$mydate;}
			
			
		}
		}
	}
	function data2(){
		$District=$_GET["d"];
		$Hospital=$_GET["h"];
		$conn = new mysqli("localhost", "undpAdmin", "Malawi128","spotlight");
		$Query="SELECT date FROM `hospitalinfo` group by date ORDER BY date asc;";
		$result = $conn->query($Query);
		$month_value=0;
		$month=$_GET["Starting_Month"];
		
		if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			$date=$row["date"];
			$Value=TimelineValue2("SELECT SUM(GBVCasesTreated) as Value FROM `hospitalinfo` WHERE `date`='$date' AND (NameofDistrict='$District' AND NameofHospital='$Hospital')");
			
			$thisMonth=date("M Y", strtotime($date));
			
			
			if($month!=$thisMonth){
				echo "$month_value,";
				$month_value=0;
			}
			$month=$thisMonth;
			$month_value=$month_value+$Value;
		}echo "$month_value,";
		}
	}
 ?>
<!----end--->

  
     <div id="DistrictTimeline"></div>

    <script>
      
        var options = {
          xaxis: {
          categories: [<?php Period2();?>]},series: [{name:"Cases Treated",data: [<?php data2();?>]
        }],
          chart: {
          type: 'line',
          height: 300
        },
        plotOptions: {
          bar: {
            horizontal: false,
			
          }
        },
        dataLabels: {
          enabled: true
        }
        };

        var chart = new ApexCharts(document.querySelector("#DistrictTimeline"), options);
        chart.render();
      
      
    </script>






