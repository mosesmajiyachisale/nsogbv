<script>
//Medical Service Access Rate
			<?PHP
				
				function AccessRateCases($Service){
					$Cases=0;
					$District=$_GET["d"];
					$Hospital=$_GET["h"];
					$Query="SELECT SUM($Service) as Cases from searcher2 WHERE NameofDistrict='$District' AND NameofHospital='$Hospital'";
					$conn = new mysqli("localhost", "undpAdmin", "Malawi128","spotlight");
					$result = $conn->query($Query);

					if ($result->num_rows > 0) {
					while($row = $result->fetch_assoc()) {
						$Cases=$row["Cases"];
						
					}
					}
					return $Cases;
				}?>
</script>
<div id="Access_Rate">
</div>
<script>
      
        var options = {
			series: [{
				data: [<?php echo AccessRateCases("HivPepAccesed");?>,<?php echo AccessRateCases("ProphylaxisTreatmentAccesed");?>,<?php echo AccessRateCases("EmergencyContraceptionAccesed");?>,<?php echo AccessRateCases("FamilyPlanningAccesed");?>],
				name: 'Accessed'
					},{
				data: [<?php echo AccessRateCases("HivPepDeclined");?>,<?php echo AccessRateCases("ProphylaxisTreatmentDeclined");?>,<?php echo AccessRateCases("EmergencyContraceptionDeclined");?>,<?php echo AccessRateCases("FamilyPlanningDeclined");?>],
				name: 'Declined'
					}],
			chart: {
					  type: 'bar',
					  height: 300
					},
			
			plotOptions: {
				bar: {
					horizontal: false,
				}
			},
			dataLabels: {
				enabled: false
			},
			xaxis: {
				categories: ["HIV pep","STI pep","EC",["Family","Planning"]],
			}
        };

        var chart = new ApexCharts(document.querySelector("#Access_Rate"), options);
        chart.render();
      
      
    </script>
