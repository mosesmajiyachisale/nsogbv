
<?php
	include("Data/value.php");
?>

            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="row page-titles">
                <div class="col-md-7 align-self-center">
                    <h3 class="text-themecolor mb-0">Health Center SGBV Dashboard</h3>
                    <ol class="breadcrumb mb-0">
                        <li class="breadcrumb-item"><a href="../../">Home</a></li>
                        <li class="breadcrumb-item active"><a href="../">Health Centers</a></li>
                        <li class="breadcrumb-item"><b class=" "><?php echo date('d M Y',strtotime($from))." To ".date('d M Y',strtotime($to));?></b></li>
                    </ol>
                </div>
                <div class="col-md-5 align-self-center d-none d-md-block">
                    <div class="d-flex mt-2 justify-content-end">
                        <div class="d-flex mr-3 ml-2">
                            <div class="chart-text mr-2">
                                <h6 class="mb-0"><small>CASES TREATED</small></h6>
                                <h4 class="mt-0 text-info"><?php echo value("SELECT SUM(GBVCasesTreated) as Value FROM `searcher2`");?></div>
                        </div>
                        <div class="d-flex ml-2">
                            <div class="chart-text mr-2">
                                <h6 class="mb-0"><small>NATIONAL SGBV CASES</small></h6>
                                <h4 class="mt-0 text-primary" ><?php echo value("select count(*) as Value from sgbv.searcher");?></h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- Row -->
                <div class="row">
                    <!-- Column -->
                    <div class="col-lg-6 col-md-12">
                        <div class="card">
                            <div class="card-body">
                                    <div class="col-12">
                                            <div>
                                                <h3 class="card-title">SGBV Cases</h3>
                                             <!--   <h6 class="card-subtitle">Pie Chart</h6> -->
                                            </div>
                                            <?php include("Data/Cases_Per_District.php");?>
                                    </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <h3 class="card-title">Health Centers</h3>
                                 <div class="col-12">   
                                        <?php include("Data/Hospitals_District.php");?> 
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Row -->
                <div class="row">
                    <!-- Column -->
                    <div class="col-lg-6 col-md-12">
                        <div class="card">
                            <div class="card-body">
                                    <div class="col-12">
                                            <div>
                                                <h3 class="card-title">Late Access</h3>
                                             <!--   <h6 class="card-subtitle">Pie Chart</h6> -->
                                            </div>
                                            <?php include("Data/Late_Access.php");?>
                                    </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <h3 class="card-title">Fresh Samples</h3>
                                 <div class="col-12">   
                                        <?php include("Data/Fresh_Samples.php");?> 
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-6 col-md-12">
                        <div class="card">
                            <div class="card-body">
                             <!--   <div class="d-flex flex-wrap"> -->
                                    <div>
                                        <h3 class="card-title">Medical Service Access Rate </h3>
                                      <!--  <h6 class="card-subtitle">Overview of Newsletter Campaign</h6> -->
                                    </div>
                                    <div class="ml-auto align-self-center">
                                        <?php include("Data/Medical_Service_Access_Rate.php"); ?>
                                    </div>
                             <!--   </div> -->
                             <!--   <div class="campaign ct-charts"></div> -->

                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12">
                        <div class="card">
                            <div class="card-body">
                             <!--   <div class="d-flex flex-wrap"> -->
                                    <div>
                                        <h3 class="card-title">Cases Treated Over Time </h3>
                                      <!--  <h6 class="card-subtitle">Overview of Newsletter Campaign</h6> -->
                                    </div>
                                    <div class="ml-auto align-self-center">
                                        <?php include("Data/Timeline.php"); ?>
                                    </div>
                             <!--   </div> -->
                             <!--   <div class="campaign ct-charts"></div> -->

                            </div>
                        </div>
                    </div>
                </div>
            </div>
           