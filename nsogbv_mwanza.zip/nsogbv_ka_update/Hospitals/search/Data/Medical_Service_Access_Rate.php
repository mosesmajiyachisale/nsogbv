<script>
//Medical Service Access Rate
			<?PHP
								$FPA=0;
								$FPD=0;
								$ECA=0;
								$ECD=0;
								$HPA=0;
								$HPD=0;
								$SPA=0;
								$SPD=0;
								$highest=0;
								$HospitalDistricts=Districts();
								foreach($HospitalDistricts as $ThisDistrict)
									{
										$FPA= Value("SELECT sum(`FamilyPlanningAccesed`) as Value FROM `searcher2`;");
										$FPD= Value("SELECT sum(`FamilyPlanningDeclined`) as Value FROM `searcher2`;");
										$ECA= Value("SELECT sum(`EmergencyContraceptionAccesed`) as Value FROM `searcher2`;");
										$ECD= Value("SELECT sum(`EmergencyContraceptionDeclined`) as Value FROM `searcher2`;");
										$HPA= Value("SELECT sum(`HivPepAccesed`) as Value FROM `searcher2`;");
										$HPD= Value("SELECT sum(`HivPepDeclined`) as Value FROM `searcher2`;");
										$SPA= Value("SELECT sum(`ProphylaxisTreatmentAccesed`) as Value FROM `searcher2`;");
										$SPD= Value("SELECT sum(`ProphylaxisTreatmentDeclined`) as Value FROM `searcher2`");
									}
							?>
</script>
<div id="Access_Rate">
</div>
<script>
      
        var options = {
			series: [{
				data: [<?php echo $FPA.",".$ECA.",".$HPA.",".$SPA;?>],
				name: 'Accessed'
					},{
				data: [<?php echo $FPD.",".$ECD.",".$HPD.",".$SPD;?>],
				name: 'Declined'
					}],
			chart: {
					  type: 'bar',
					  height: 350
					},
			
			plotOptions: {
				bar: {
					horizontal: false,
				}
			},
			dataLabels: {
				enabled: false
			},
			xaxis: {
				categories: ["HIV pep","STI pep","EC",["Family","Planning"]],
			}
        };

        var chart = new ApexCharts(document.querySelector("#Access_Rate"), options);
        chart.render();
      
      
    </script>
