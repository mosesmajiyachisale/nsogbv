<?php 
$conn = new mysqli("localhost", "undpAdmin", "Malawi128","spotlight");
		$d='';
		if (isset($_POST['submit'])){
			$from=date('Y-m-d',strtotime($_POST['from']));
			$to=date('Y-m-d',strtotime($_POST['to']));

		//MySQLi Object-oriented
		$oquery1=$conn->query("DROP TABLE IF EXISTS searcher2");
		$oquery=$conn->query("CREATE TABLE searcher2 as select hospitalinfo.* from hospitalinfo where date between '$from' and '$to'");
		$query1=$conn->query("DROP TABLE IF EXISTS sgbv.me2");
		$query=$conn->query("create table sgbv.me2 as select sgbv.gbv_cases2.*,  str_to_date(concat(f5_year,'-',f5_month,'-',f5_day), '%Y-%m-%d') F5_DATEE from sgbv.gbv_cases2");
		$nquery1=$conn->query("DROP TABLE IF EXISTS sgbv.searcher");
		$nquery=$conn->query("CREATE TABLE sgbv.searcher as select sgbv.me2.*, F5_DATEE F5_DATEEe from sgbv.me2 where F5_DATEE between '$from' and '$to'");

	}
function Value($ThisQuery){
	$conn = new mysqli("localhost", "undpAdmin", "Malawi128","spotlight");
	$ThisValue=0;
	$result = $conn->query($ThisQuery);
	if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
			$ThisValue= $row["Value"];
			if($ThisValue=="")$ThisValue=0;
		}
	}
	$conn->close();
	return $ThisValue;
}

function Districts(){
	$conn = new mysqli("localhost", "undpAdmin", "Malawi128","spotlight");
	$Districts;
	$DisrtictNumber=1;
	$sql2="SELECT NameofDistrict FROM `searcher2`  GROUP BY NameofDistrict";
	$result2 = $conn->query($sql2);
	if ($result2->num_rows > 0) {
		// output data of each row
		while($row2 = $result2->fetch_assoc()) {
			$Districts[$DisrtictNumber]=$row2["NameofDistrict"];
			$DisrtictNumber++;
		}
	}
	$conn->close();
	return $Districts;
}
function Hospitals(){
	
	$conn = new mysqli("localhost", "undpAdmin", "Malawi128","spotlight");
	$Query="SELECT NameofHospital from searcher2 WHERE NameofHospital IN (SELECT DISTINCT NameofHospital FROM searcher2) GROUP BY NameofHospital ORDER BY GBVCasesTreated DESC";
	$conn = new mysqli("localhost", "root", "", "spotlight");
	$result = $conn->query($Query);
	$Hospitals;
	$Hospitalnumber=0;
	
	if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			$NameofHospital[$Hospitalnumber]=$row["NameofHospital"];
			$Hospitalnumber++;
			
		}
	}
	return $Hospitals;
	}
?>