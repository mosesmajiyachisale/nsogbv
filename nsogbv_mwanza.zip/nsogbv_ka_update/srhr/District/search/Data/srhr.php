<?php $District=$_GET['d'];?>
     <div id="chartabmzz"></div>

    <script>
      
        var options = {
          series: [{name:'cases',
          data: [  
		  <?php
$query  = "SELECT * from 
(SELECT a4_district, (CASE WHEN c1 = 1 THEN 'Child abuse '  else 0 END) srhr, count(*) total FROM sgbv.searcher where c1  = 1 and a4_district = '$District'
union
SELECT a4_district, (CASE WHEN c2 = 1 THEN 'Child neglect'  END) srhr, count(*) total FROM sgbv.searcher where c2 = 1 and a4_district = '$District'
union
SELECT a4_district, (CASE WHEN c3 = 1 THEN 'Forced to have children'  END) srhr,  count(*) total FROM sgbv.searcher where c3 = 1 and a4_district = '$District'
union
SELECT a4_district, (CASE WHEN  c4 = 1 THEN 'Forced to abort'  END) srhr, count(*) total FROM sgbv.searcher where c4 = 1 and a4_district = '$District'
union
SELECT a4_district, (CASE WHEN  c5 = 1 THEN 'Infected with STIs/HIV deliberately'  END) srhr, count(*) total FROM sgbv.searcher where c5 = 1 and a4_district = '$District'
union
SELECT a4_district, (CASE WHEN  c6 = 1 THEN 'Refused to use family planning methods'  END) srhr, count(*) total FROM sgbv.searcher where c6  = 1 and a4_district = '$District'
union
SELECT a4_district, (CASE WHEN  c7 = 1 THEN 'Refused conjugal rights'  END) srhr, count(*) total FROM sgbv.searcher where c7 = 1 and a4_district = '$District'

)as temp2 where a4_district = '$District' and srhr is not null";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"$total,"; 
}

?>  
		  
		  ]
        }],
          chart: {
          type: 'bar',
          height: 350,
		   
        },
		
        plotOptions: {
          bar: {
            horizontal: true,
			responsive: true,
          }
        },
        dataLabels: {
          enabled: false
        },
        xaxis: {
          categories: [
		  
			<?php
$query  = "SELECT * from 
(SELECT a4_district, (CASE WHEN c1 = 1 THEN 'Child abuse '  else 0 END) srhr, count(*) total FROM sgbv.searcher where c1  = 1 and a4_district = '$District'
union
SELECT a4_district, (CASE WHEN c2 = 1 THEN 'Child neglect'  END) srhr, count(*) total FROM sgbv.searcher where c2 = 1 and a4_district = '$District'
union
SELECT a4_district, (CASE WHEN c3 = 1 THEN 'Forced to have children'  END) srhr,  count(*) total FROM sgbv.searcher where c3 = 1 and a4_district = '$District'
union
SELECT a4_district, (CASE WHEN  c4 = 1 THEN 'Forced to abort'  END) srhr, count(*) total FROM sgbv.searcher where c4 = 1 and a4_district = '$District'
union
SELECT a4_district, (CASE WHEN  c5 = 1 THEN 'Infected with STIs/HIV deliberately'  END) srhr, count(*) total FROM sgbv.searcher where c5 = 1 and a4_district = '$District'
union
SELECT a4_district, (CASE WHEN  c6 = 1 THEN 'Refused to use family planning methods'  END) srhr, count(*) total FROM sgbv.searcher where c6  = 1 and a4_district = '$District'
union
SELECT a4_district, (CASE WHEN  c7 = 1 THEN 'Refused conjugal rights'  END) srhr, count(*) total FROM sgbv.searcher where c7 = 1 and a4_district = '$District'

)as temp2 where a4_district = '$District' and srhr is not null";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"'$srhr',"; 
}

?>  
			
			
          ],
        }
        };

        var chart = new ApexCharts(document.querySelector("#chartabmzz"), options);
        chart.render();
      
      
    </script>


    
  </body>
</html>



