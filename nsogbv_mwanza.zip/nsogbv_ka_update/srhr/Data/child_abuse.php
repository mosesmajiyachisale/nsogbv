<!DOCTYPE html>

	<script src="../dist/apexcharts/dist/apexcharts.js"></script>
<html lang="en">
  <head>

 
 

  </head>

  <body>
     <div id="chartchild" class="Piechart"></div>

    <script>
      
        var options = {
          series: [
		  
		  <?php
$query  = "select case when a2_sex = 1 then 'Male'
			when a2_sex = 2 then 'Female'
	end
sex , count(c1) total from sgbv.gbv_cases2 where c1=1 group by a2_sex";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);
echo"$total,"; 
}

?>  	  
		  ],
          chart: {
          width: 350,
          type: 'donut',
        },
		legend: {
              position: 'bottom',
            },
        labels: [
		
		
		
		<?php
$query  = "select case when a2_sex = 1 then 'Male'
			when a2_sex = 2 then 'Female'
	end
sex , count(c1) total from sgbv.gbv_cases2 where c1=1 group by a2_sex";

$results = mysqli_query($link, $query);
$nrows = mysqli_num_rows($results);
$row = mysqli_num_rows($results);

for ($i=0;$i<$nrows;$i++)

{
$n = $i + 1;
$row = mysqli_fetch_array($results);
extract($row);



echo"'$sex',"; 
}

?>
		
		],
        responsive: [{
          breakpoint: 1600,
          options: {
            chart: {
              width: 300
            },
            legend: {
              position: 'bottom'
            }
          }
        }],
        dataLabels: {
          formatter(val, opts) {
            const name = opts.w.globals.labels[opts.seriesIndex]
            return [name, val.toFixed(1) + '%']
          }
        },
        legend: {
          show: false
        },
        plotOptions: {
          pie: {
            dataLabels: {
              offset: -0
            }
          }
		}
        };

        var chart = new ApexCharts(document.querySelector("#chartchild"), options);
        chart.render();
      
      
    </script>

    
  </body>
</html>