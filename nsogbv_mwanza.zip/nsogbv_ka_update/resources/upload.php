<?php
$conn = mysqli_connect("localhost", "undpAdmin", "Malawi128","sgbv");

// fetch files
$sql = "select name, created from files";
$result = mysqli_query($conn, $sql);
?>

<?php
//check if form is submitted
if (isset($_POST['submit']))
{
    $name = $_FILES['file1']['name'];

    //upload file
    if($name != '')
    {
        $ext = pathinfo($name, PATHINFO_EXTENSION);
        $allowed = ['pdf', 'txt', 'doc', 'docx', 'png', 'jpg', 'jpeg',  'gif'];
    
        //check if file type is valid
        if (in_array($ext, $allowed))
        {
            // get last record id
            $sql = 'select max(id) as id from files';
            $result = mysqli_query($conn, $sql);
            if (count($result) > 0)
            {
                $row = mysqli_fetch_array($result);
                $name = ($row['id']+1) . '-' . $name;
            }
            else
                $name = '1' . '-' . $name;

            //set target directory
            $path = 'uploads/';
                
            $created = @date('Y-m-d H:i:s');
            move_uploaded_file($_FILES['file1']['tmp_name'],($path . $name));
            
            // insert file details into database
            $sql = "INSERT INTO files(name, created) VALUES('$name', '$created')";
            mysqli_query($conn, $sql);
            header("Location: index.php?st=success");
        }
        else
        {
            header("Location: index.php?st=error");
        }
    }
    else
        header("Location: index.php");
}
?>