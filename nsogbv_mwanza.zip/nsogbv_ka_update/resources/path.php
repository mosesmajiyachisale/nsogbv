<a href="../home_Courts.php"><label class="dropbtn">Court</label></a>
<a href="../home_Courts.php"><label class="dropbtn">Hospital</label></a>