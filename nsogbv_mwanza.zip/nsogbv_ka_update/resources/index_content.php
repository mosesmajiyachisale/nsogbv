<?php
$conn = mysqli_connect("localhost", "undpAdmin", "Malawi128","sgbv");

// fetch files
$sql = "select name, created from files";
$result = mysqli_query($conn, $sql);
?>
<?php
	function Value($ThisQuery){
							$conn = new mysqli("localhost", "undpAdmin", "Malawi128","spotlight");
							$ThisValue=0;
							$result = $conn->query($ThisQuery);
							if ($result->num_rows > 0) {
								// output data of each row
								while($row = $result->fetch_assoc()) {
									$ThisValue= $row["Value"];
									if($ThisValue=="")$ThisValue=0;
								}
							}
							return $ThisValue;
						}
?>
<!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="row page-titles">
                <div class="col-md-7 align-self-center">
                    <h3 class="text-themecolor mb-0">Resources</h3>
                    <ol class="breadcrumb mb-0">
                        <li class="breadcrumb-item"><a href="../">Home</a></li>
                        <li class="breadcrumb-item active">Resources</li>
                    </ol>
                </div>
				
				<div class="col-md-5 align-self-center d-none d-md-block">
                    <div class="d-flex mt-2 justify-content-end">
                        <div class="d-flex ml-2">
                            <div class="chart-text mr-2">
                                <h6 class="mb-0"><small>TOTAL SGBV CASES</small></h6>
                                <h4 class="mt-0 text-primary" ><?php echo value("select count(*) as Value from sgbv.gbv_cases2");?></h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->

<div class="container">
    
    <div class="row">
        <div class="col-md-8 offset-md-2 card">
            <table class="table table-striped table-hover">
                <thead>
                    <tr height="50px">
                        <th>#</th>
                        <th>File Name</th>
                        <th>View</th>
                        <th>Download</th>
						 <th>Date_Created</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                $i = 1;
                while($row = mysqli_fetch_array($result)) { ?>
                <tr >
                    <td><?php echo $i++; ?></td>
                    <td><?php echo $row['name']; ?></td>
                    <td><a href="uploads/<?php echo $row['name']; ?>" target="_blank">View</a></td>
                    <td><a href="uploads/<?php echo $row['name']; ?>" download>Download</td>
										<td ><?php echo $row['created']; ?></td>
                <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
			
