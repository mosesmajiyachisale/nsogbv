<?php 
	if((!isset($_POST["from"])&!isset($_POST["to"]))||($_POST["from"]==$_POST["to"])){
		$to=date("Y-m-d");
		$from=date("Y-01-01");
	}else{
		$from=date('Y-m-d',strtotime($_POST['from']));
		$to=date('Y-m-d',strtotime($_POST['to']));
	}
	{
			$conn = new mysqli("localhost", "undpAdmin", "Malawi128","spotlight");
			$cquery1=$conn->query("DROP TABLE IF EXISTS searcher");
			$cquery=$conn->query("CREATE TABLE searcher as select courttbl.* from courttbl where date between '$from' and '$to'");
			
			$hquery1=$conn->query("DROP TABLE IF EXISTS searcher2");
			$hquery=$conn->query("CREATE TABLE searcher2 as select hospitalinfo.* from hospitalinfo where date between '$from' and '$to'");
			
			$query1=$conn->query("DROP TABLE IF EXISTS sgbv.me2");
			$query=$conn->query("create table sgbv.me2 as select sgbv.gbv_cases2.*,  str_to_date(concat(f5_year,'-',f5_month,'-',f5_day), '%Y-%m-%d') F5_DATEE from sgbv.gbv_cases2");
			
			$nquery1=$conn->query("DROP TABLE IF EXISTS sgbv.searcher");
			$nquery=$conn->query("CREATE TABLE sgbv.searcher as select sgbv.me2.*, F5_DATEE F5_DATEEe from sgbv.me2 where F5_DATEE between '$from' and '$to'");
	}
	
	function Indicators(){
		$conn = new mysqli("localhost", "undpAdmin", "Malawi128","spotlight");
		$Indicators;
		$IndicatorNumber=1;
		$Query="SELECT * FROM `indicators`";
		$result2 = $conn->query($Query);
		if ($result2->num_rows > 0) {
			// output data of each row
			while($row2 = $result2->fetch_assoc()) {
				$Indicators[$IndicatorNumber]=$row2["Name"];
				$IndicatorNumber++;
			}
		}
		$conn->close();
		return $Indicators;
	}
	
	function Hospitals(){
	
		$conn = new mysqli("localhost", "undpAdmin", "Malawi128","spotlight");
		$Query="SELECT NameofHospital from hospitalinfo WHERE NameofHospital IN (SELECT DISTINCT NameofHospital FROM hospitalinfo) GROUP BY NameofHospital ORDER BY GBVCasesTreated DESC";
		$conn = new mysqli("localhost", "root", "", "spotlight");
		$result = $conn->query($Query);
		$Hospitals;
		$Hospitalnumber=0;
		
		if ($result->num_rows > 0) {
			while($row = $result->fetch_assoc()) {
				$NameofHospital[$Hospitalnumber]=$row["NameofHospital"];
				$Hospitalnumber++;
				
			}
		}
		$conn->close();
		return $Hospitals;
	}
	
	function Value($ThisQuery){
		$conn = new mysqli("localhost", "undpAdmin", "Malawi128","spotlight");
		$ThisValue=0;
		$result = $conn->query($ThisQuery);
		if ($result->num_rows > 0) {
			// output data of each row
			while($row = $result->fetch_assoc()) {
				$ThisValue= $row["Value"];
				if($ThisValue=="")$ThisValue=0;
			}
		}
		$conn->close();
		return $ThisValue;
	}

	function Districts(){
		$conn = new mysqli("localhost", "undpAdmin", "Malawi128","spotlight");
		$Districts;
		$DisrtictNumber=1;
		$sql2="SELECT District as District FROM `courttbl` UNION SELECT NameofDistrict as District from hospitalinfo UNION SELECT a4_district as District FROM sgbv.`gbv_cases2` GROUP BY District";
		$result2 = $conn->query($sql2);
		if ($result2->num_rows > 0) {
			// output data of each row
			while($row2 = $result2->fetch_assoc()) {
				$Districts[$DisrtictNumber]=$row2["District"];
				$DisrtictNumber++;
			}
		}
		$conn->close();
		return $Districts;
	}
	
	
	

?>