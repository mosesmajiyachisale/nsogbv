<?php
					$conn = new mysqli("localhost", "undpAdmin", "Malawi128","spotlight");
					$d='';
					
					function Value($ThisQuery){
							$conn = new mysqli("localhost", "root", "", "spotlight");
							$ThisValue=0;
							$result = $conn->query($ThisQuery);
							if ($result->num_rows > 0) {
								// output data of each row
								while($row = $result->fetch_assoc()) {
									$ThisValue= $row["Value"];
									if($ThisValue=="")$ThisValue=0;
								}
							}
							return $ThisValue;
						}
						$PeriodID;
						if(!isset($_GET["PeriodID"])){
							$PeriodID=Value('SELECT PeriodID as Value FROM `period` GROUP BY Year ORDER BY Year DESC LIMIT 1');
						}else{$PeriodID=$_GET["PeriodID"];}
					$sql = "SELECT * FROM `courttbl`";
					$result = $conn->query($sql);
					$CourtsData;
					
					$Districts;
					$DisrtictNumber=1;
					$sql2="SELECT District FROM `courttbl`  GROUP BY District";
					$result2 = $conn->query($sql2);
					if ($result2->num_rows > 0) {
						// output data of each row
						while($row2 = $result2->fetch_assoc()) {
							$Districts[$DisrtictNumber]=$row2["District"];
							$DisrtictNumber++;
						}
					}
					
					$RecorderName=""; $Title=""; $NameofCourt=""; $District=""; $Region=""; $Date=""; $RapeCaseRecorded=""; $RapeCaseInProgress=""; $RapeCasesConcluded=""; $RapeCasesWithdrawn=""; $DefilementCasesRecorded=""; $DefilementCasesInProgress=""; $DefilementCasesConcluded=""; $DefilementCasesWithdrawn=""; $SexualHarassmentCasesRecorded=""; $SexualHarassmentCasesInProgress=""; $SexualHarassmentCasesConcluded=""; $SexualHarassmentCasesWithdrawn=""; $EconomicViolenceCasesRecorded=""; $EconomicViolenceCasesInProgress=""; $EconomicViolenceCasesConcluded=""; $EconomicViolenceCasesWithdrawn=""; $Remarks=""; $EntryTime="";  
					$reported=0;$inprogress=0;$concluded=0;$withdrawn=0;
					if ($result->num_rows > 0) {
						// output data of each row
						while($row = $result->fetch_assoc()) {
							$RecorderName=$row["RecorderName"]; 
							$Title=$row["Title"]; 
							$NameofCourt=$row["NameofCourt"];
							$District=$row["District"]; 
							$Region=$row["Region"]; 
							$Date=$row["Date"]; 
							$CourtsData[$row['District']]["RapeCaseRecorded"]=$RapeCaseRecorded=$row["RapeCaseRecorded"]; 
							IF(!isset($CourtsData[$row['District']]["RapeCases"]))$CourtsData[$row['District']]["RapeCases"]=0; 
							$CourtsData[$row['District']]["RapeCases"]+=$row["RapeCaseRecorded"]; 
							$CourtsData[$row['District']]["RapeCaseInProgress"]=$RapeCaseInProgress=$row["RapeCaseInProgress"]; 
							$CourtsData[$row['District']]["RapeCasesConcluded"]=$RapeCasesConcluded=$row["RapeCasesConcluded"]; 
							$CourtsData[$row['District']]["RapeCasesWithdrawn"]=$RapeCasesWithdrawn=$row["RapeCasesWithdrawn"];
							
							$CourtsData[$row['District']]["DefilementCasesRecorded"]=$DefilementCasesRecorded=$row["DefilementCasesRecorded"];
							IF(!isset($CourtsData[$row['District']]["DefilementCases"]))$CourtsData[$row['District']]["DefilementCases"]=0; 
							$CourtsData[$row['District']]["DefilementCases"]+=$row["DefilementCasesRecorded"];							
							$CourtsData[$row['District']]["DefilementCasesInProgress"]=$DefilementCasesInProgress=$row["DefilementCasesInProgress"]; 
							$CourtsData[$row['District']]["DefilementCasesConcluded"]=$DefilementCasesConcluded=$row["DefilementCasesConcluded"]; 
							$CourtsData[$row['District']]["DefilementCasesWithdrawn"]=$DefilementCasesWithdrawn=$row["DefilementCasesWithdrawn"];
							
							$CourtsData[$row['District']]["SexualHarassmentCasesRecorded"]=$SexualHarassmentCasesRecorded=$row["SexualHarassmentCasesRecorded"];
							IF(!isset($CourtsData[$row['District']]["SexualHarassmentCases"]))$CourtsData[$row['District']]["SexualHarassmentCases"]=0; 
							$CourtsData[$row['District']]["SexualHarassmentCases"]+=$row["SexualHarassmentCasesRecorded"];							
							$CourtsData[$row['District']]["SexualHarassmentCasesInProgress"]=$SexualHarassmentCasesInProgress=$row["SexualHarassmentCasesInProgress"]; 
							$CourtsData[$row['District']]["SexualHarassmentCasesConcluded"]=$SexualHarassmentCasesConcluded=$row["SexualHarassmentCasesConcluded"]; 
							$CourtsData[$row['District']]["SexualHarassmentCasesWithdrawn"]=$SexualHarassmentCasesWithdrawn=$row["SexualHarassmentCasesWithdrawn"];
							
							$CourtsData[$row['District']]["EconomicViolenceCasesRecorded"]=$EconomicViolenceCasesRecorded=$row["EconomicViolenceCasesRecorded"];
							IF(!isset($CourtsData[$row['District']]["EconomicViolenceCases"]))$CourtsData[$row['District']]["EconomicViolenceCases"]=0; 
							$CourtsData[$row['District']]["EconomicViolenceCases"]+=$row["EconomicViolenceCasesRecorded"];
							$CourtsData[$row['District']]["EconomicViolenceCasesInProgress"]=$EconomicViolenceCasesInProgress=$row["EconomicViolenceCasesInProgress"]; 
							$CourtsData[$row['District']]["EconomicViolenceCasesConcluded"]=$EconomicViolenceCasesConcluded=$row["EconomicViolenceCasesConcluded"]; 
							$CourtsData[$row['District']]["EconomicViolenceCasesWidrawn"]=$EconomicViolenceCasesWithdrawn=$row["EconomicViolenceCasesWidrawn"];
							
							$Remarks=$row["Remarks"]; $EntryTime=$row["EntryTime"]; 
							//$Entryperiod=$row[""];
							
							IF(!isset($CourtsData[$row['District']]["reported"]))$CourtsData[$row['District']]["reported"]=0;
							$CourtsData[$row['District']]["reported"]+=$reported=$RapeCaseRecorded+$DefilementCasesRecorded+$SexualHarassmentCasesRecorded+$EconomicViolenceCasesRecorded;
							
							IF(!isset($CourtsData[$row['District']]["inprogress"]))$CourtsData[$row['District']]["inprogress"]=0;
							$CourtsData[$row['District']]["inprogress"]+=$inprogress=$RapeCaseInProgress+$DefilementCasesInProgress+$SexualHarassmentCasesInProgress+$EconomicViolenceCasesInProgress;
							
							IF(!isset($CourtsData[$row['District']]["concluded"]))$CourtsData[$row['District']]["concluded"]=0;
							$CourtsData[$row['District']]["concluded"]+=$concluded=$RapeCasesConcluded+$DefilementCasesConcluded+$SexualHarassmentCasesConcluded+$EconomicViolenceCasesConcluded;
							
							IF(!isset($CourtsData[$row['District']]["withdrawn"]))$CourtsData[$row['District']]["withdrawn"]=0;
							$CourtsData[$row['District']]["withdrawn"]+=$withdrawn=$RapeCasesWithdrawn+$DefilementCasesWithdrawn+$SexualHarassmentCasesWithdrawn+$EconomicViolenceCasesWithdrawn;
						}
					} else {
						echo "0 results";
					}
					$conn->close();
				?>