

<?php 
	$Months=["December",'November','October','September','August','July','June','May','April','March','February','January'];
	function TimelineValue($Query){
		$Query;
		$conn = new mysqli("localhost", "undpAdmin", "Malawi128","spotlight");
		$ThisValue=0;
		$result = $conn->query($Query);

		if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			$ThisValue=$row["Value"];
		}
		}
		return $ThisValue;
	}
	function Period(){
		$conn = new mysqli("localhost", "undpAdmin", "Malawi128","spotlight");
		$Query="SELECT * FROM `period` ORDER BY PeriodID ASC;";
		$result = $conn->query($Query);

		if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			$month=$row["Month"];
			$year=$row["Year"];
			echo "['$month','$year'],";
		}
		}
	}
	function data(){
		$conn = new mysqli("localhost", "undpAdmin", "Malawi128","spotlight");
		$Query="SELECT * FROM `period` ORDER BY PeriodID ASC;";
		$result = $conn->query($Query);

		if ($result->num_rows > 0) {
		while($row = $result->fetch_assoc()) {
			$PeriodID=$row["PeriodID"];
			$Value=TimelineValue("SELECT SUM(RapeCaseRecorded+DefilementCasesRecorded+SexualHarassmentCasesRecorded+EconomicViolenceCasesRecorded) as Value FROM `courttbl` WHERE `PeriodID`=$PeriodID");
			echo "$Value,";
		}
		}
	}
 ?>
	<script src="dist/apexcharts/dist/apexcharts.js"></script>
<!----end--->

  
     <div id="CourtsTimeline"></div>

    <script>
      
        var options = {
          xaxis: {
          categories: [<?php Period();?>]},series: [{name:"Cases", data: [<?php data();?>]
        }],
          chart: {
          type: 'line',
          height: 285
        },
        plotOptions: {
          bar: {
            horizontal: false,
			
          }
        },
        dataLabels: {
          enabled: true
        }
        };

        var chart = new ApexCharts(document.querySelector("#CourtsTimeline"), options);
        chart.render();
      
      
    </script>


    
  </body>
</html>



