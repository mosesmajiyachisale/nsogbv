<?php 
						//check if district is selected
						$DistrictSelected=false;
						$SpotlightDistricts=Districts();
						foreach($SpotlightDistricts as $ThisDistrict)
						{
							if(isset($_POST[$ThisDistrict."_District"]))$DistrictSelected=true;
						}
						if(!$DistrictSelected){
							foreach($SpotlightDistricts as $ThisDistrict){
								$_POST[$ThisDistrict."_District"]=$ThisDistrict."_District";
							}
						}
						
						//check if indicator is selected
						$IndicatorSelected=false;
						$Indicators=Indicators();
						foreach($Indicators as $ThisIndicator)
						{
							if(isset($_POST[$ThisIndicator]))$IndicatorSelected=true;
						}
						if(!$IndicatorSelected){
							$_POST["Survivors"]="Survivors";
							$_POST["Courts"]="Courts";
							$_POST["Hospitals"]='Hospitals';
						}
						
						//creating series
						$indicatorName="";
						$indicatorValue="";
						$IndicatorData;
						{
								foreach($SpotlightDistricts as $ThisDistrict){
									//check if district is selected else choose all districts
									if(isset($_POST[$ThisDistrict."_District"])){
										foreach($Indicators as $ThisIndicator){
											if(isset($_POST[$ThisIndicator])){
												$indicator=0;
												if(isset($_POST["Survivors"])){
													if(!isset($indicatorData[0])){
														$indicatorData[0]["name"]="Survivors";
														$indicatorData[0]["Data"]="";
													}
													if($_POST[$ThisIndicator]===$_POST["Survivors"]){
														$indicator = Value("select count(*) as Value from sgbv.searcher where A4_DISTRICT ='$ThisDistrict'");
														 $indicatorData[0]["Data"]=$indicatorData[0]["Data"]."'$indicator',";
													}
												}
												if(isset($_POST["Courts"])){
													if(!isset($indicatorData[4])){
														$indicatorData[4]["name"]="Courts";
														$indicatorData[4]["Data"]="";
													}
													if($_POST[$ThisIndicator]===$_POST["Courts"]){
														$indicator = Value("SELECT Sum(RapeCaseRecorded+DefilementCasesRecorded+SexualHarassmentCasesRecorded+EconomicViolenceCasesRecorded) as Value FROM `searcher` where District=\"$ThisDistrict\"");
														 $indicatorData[4]["Data"]=$indicatorData[4]["Data"]."'$indicator',";
													}
												}
												if(isset($_POST["Hospitals"])){
													if(!isset($indicatorData[5])){
														$indicatorData[5]["name"]="Hospitals";
														$indicatorData[5]["Data"]="";
													}
													if($_POST[$ThisIndicator]===$_POST["Hospitals"]){
														$indicator = Value("SELECT Sum(GBVCasesTreated) as Value FROM `searcher2` where NameofDistrict=\"$ThisDistrict\"");
														 $indicatorData[5]["Data"]=$indicatorData[5]["Data"]."'$indicator',";
													}
												}
											}
										}
										$indicatorName =$indicatorName . "['".$ThisDistrict."'],";
									}
									
								}
							}
						
					?>