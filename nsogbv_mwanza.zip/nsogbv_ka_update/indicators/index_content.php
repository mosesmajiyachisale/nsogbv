<?php include("../dbconnect.php"); ?>
<?php
	include("Data/value.php");
	include("Data/graph.php");

?>
            <div class="row page-titles">
                <div class="col-md-8 align-self-center">
                    <h3 class="text-themecolor mb-0">SGBV Dashboard</h3>
                    <ol class="breadcrumb mb-0">
                        <li class="breadcrumb-item"><a href="../">Home</a></li>
                        <li class="breadcrumb-item active"><a href="../">Dashboard</a></li>
                        <li class="breadcrumb-item active">Indicators (<?php echo date('d M Y',strtotime($from))." To ".date('d M Y',strtotime($to));?>)</li>
                    </ol>
                </div>  
               </div>  
					<div  class="col-md-10 offset-md-1 card" id='MyTable'>
					
					<div id="indicators"></div>
					</div>				
<script>
									function printDiv(divID) {
										//Get the HTML of div
										var divElements = document.getElementById(divID).innerHTML;
										//Get the HTML of whole page
										var oldPage = document.body.innerHTML;
										//Reset the page's HTML with div's HTML only
										document.body.innerHTML = 
										  "<html><head><title></title></head><body>" + 
										  divElements + "</body>";
										//Print Page
										window.print();
										//Restore orignal HTML
										document.body.innerHTML = oldPage;

									}
								</script>
<script>
      
        var options = {
          series: [<?php 
		  foreach($indicatorData as $ThisIndicatorData){
			echo "{name: '".$ThisIndicatorData["name"]."',data: [".$ThisIndicatorData["Data"]."]},";
		  }
		  echo ""
		  ?>]
		  
		  ,
			chart: {
				type: 'bar',
				height: 500
			},
        plotOptions: {
          bar: {
            horizontal: false,
          }
        },
        dataLabels: {
          enabled: false
        },
        xaxis: {
          categories: [<?php echo $indicatorName;?>],
        }
        };

        var chart = new ApexCharts(document.querySelector("#indicators"), options);
        chart.render();
      
      
    </script>								
					